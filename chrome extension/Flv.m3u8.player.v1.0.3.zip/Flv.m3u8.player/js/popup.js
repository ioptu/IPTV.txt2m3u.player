document.addEventListener("DOMContentLoaded", function() {
    const videoUrlInput = document.getElementById("videoUrl");
    const playBtn = document.getElementById("playBtn");
    const settingsBtn = document.getElementById("settingsBtn");
    // 尝试自动填充上次播放的URL
    // chrome.storage.local.get(['lastVideoUrl'], function(result) {
    //     if (result.lastVideoUrl) {
    //         videoUrlInput.value = result.lastVideoUrl;
    //     }
    // });
    // 监听输入框的粘贴事件（自动播放链接）
    videoUrlInput.addEventListener('paste', function(e) {
        setTimeout(() => {
            const text = videoUrlInput.value.trim();
            if (text && (text.includes('.flv') || text.includes('.m3u8') || text.includes('.m3u'))) {
                playVideo(text);
            }
        }, 100);
    });
    // 监听输入框的回车键
    videoUrlInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const url = videoUrlInput.value.trim();
            if (url) {
                playVideo(url);
            }
        }
    });
    playBtn.addEventListener("click", function() {
        const url = videoUrlInput.value.trim();
        if (url) {
            playVideo(url);
        } else {
            alert("请输入有效的视频链接");
        }
    });
    function playVideo(url) {
        // 保存URL到storage
        // chrome.storage.local.set({ lastVideoUrl: url });
        chrome.tabs.create({
            url: chrome.runtime.getURL("player.html") + "?url=" + encodeURIComponent(url)
        });
    }
    settingsBtn.addEventListener("click", function() {
        chrome.tabs.create({
            url: chrome.runtime.getURL("settings.html")
        });
    });
    // 从 manifest.json 读取版本号并显示
    const versionElement = document.querySelector('.version');
    if (versionElement) {
        try {
            const manifest = chrome.runtime.getManifest();
            if (manifest && manifest.version) {
                versionElement.textContent = `${manifest.version}`;
            } else {
                versionElement.textContent = "0.1"; // 默认值
            }
        } catch (error) {
            console.warn('无法读取manifest版本号:', error);
            versionElement.textContent = "0.1"; // 默认值
        }
    }
});