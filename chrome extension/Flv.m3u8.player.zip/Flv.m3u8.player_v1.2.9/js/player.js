// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", function() {
    // 默认配置（使用毫秒）
    const DEFAULT_CONFIG = {
        LOAD_TIMEOUT_MS: 10000, // 10秒
        STALL_TIMEOUT_MS: 10000, // 10秒
        MAX_RETRY_ROUNDS: 1, // 1轮
        SEARCH_DEBOUNCE_MS: 300, // 300毫秒
        PLAYLIST_REFRESH_INTERVAL: 1000 * 60 * 30, // 30分钟
        AUTO_REFRESH_ENABLED: true, // 启用自动刷新频道列表
        BLACKLIST_URL: chrome.runtime.getURL('blacklist.txt'), // 黑名单文件URL
        EPG_ENABLED: false, // 默认关闭EPG
        EPG_URL: '', // 默认EPG URL
        RULES: [], //Headers设置 示例：[{ pattern: '*.abc.com', headers: { Auth: 'xxx', Referer: 'xxx' } },...]
        MARQUEE_SPEED: 100, // 跑马灯速度 (像素/秒)
        MARQUEE_COLOR: '#ffd700', // 跑马灯字体颜色
        MARQUEE_FONT_SIZE: '20' // 跑马灯字体大小(px)
    };
    // 实际使用的配置（会被用户设置覆盖）
    const CONFIG = { ...DEFAULT_CONFIG };
    const MIN_EPG_REFRESH_INTERVAL = 10 * 60 * 1000; // 最小EPG刷新间隔: 10分钟
    const state = {
        player: null,
        isPlaying: false,
        videoUrl: "",
        baseUrl: "",
        currentPlaylist: [],
        originalPlaylistUrl: "",
        currentPlaylistIndex: -1,
        isM3UPlaylist: false,
        streamInfo: {
            resolution: "未知",
            type: "未知",
            codec: "未知",
            bitrate: "未知",
            bandwidthEstimate: 0
        },
        loadRequestId: 0,
        timers: {
            load: null,
            stall: null,
            controls: null,
            hidePlaylist: null,
            searchDebounce: null,
            refreshPlaylist: null,
            epgRefresh: null // 新增: EPG刷新定时器
        },
        currentChannelInfo: {
            title: "",
            originalIndex: -1,
            urls: []
        },
        blacklist: [], // 黑名单关键词数组
        isBlacklistLoaded: false, // 黑名单是否已加载
        epgData: {}, // EPG数据: {channelId: [{start, stop, title}]}
        channelMap: {}, // name.lower -> id
        epgExpiryTime: 0, // EPG到期时间戳
        lastEpgRefreshTime: 0, // 上次EPG刷新时间戳
        isMarqueeActive: false, // 新增: 跑马灯是否活跃标志
        isLoudnessEnabled: false, // 新增: 响度均衡是否开启
        audioContext: null, // 新增: Web Audio Context
        sourceNode: null, // 新增: Audio Source Node
        dynamicsCompressor: null, // 新增: 动态压缩器节点
        // 新增：AI字幕翻译开关
        isSubtitleTranslationEnabled: false
    };
    const UI = {
        videoPlayer: document.getElementById("videoPlayer"),
        videoInfo: document.getElementById("videoInfo"),
        videoContainer: document.querySelector(".video-container"),
        controls: document.getElementById("controls"),
        playPauseBtn: document.getElementById("playPauseBtn"),
        backBtn: document.getElementById("backBtn"),
        prevChannelBtn: document.getElementById("prevChannelBtn"),
        nextChannelBtn: document.getElementById("nextChannelBtn"),
        volumeBtn: document.getElementById("volumeBtn"),
        fullscreenBtn: document.getElementById("fullscreenBtn"),
        playlistBtn: document.getElementById("playlistBtn"),
        closePlaylistBtn: document.getElementById("closePlaylistBtn"),
        clearSearchBtn: document.getElementById("clearSearchBtn"),
        infoBtn: null,
        progress: document.getElementById("progress"),
        progressBar: document.getElementById("progressBar"),
        timeDisplay: document.getElementById("time"),
        volumeSlider: document.getElementById("volumeSlider"),
        volumeProgress: document.getElementById("volumeProgress"),
        volumeContainer: document.querySelector(".volume-container"),
        playlistContainer: document.getElementById("playlist-container"),
        playlistItems: document.getElementById("playlist-items"),
        playlistSearchInput: document.getElementById("playlist-search-input"),
        loading: document.getElementById("loading"),
        errorMessage: document.getElementById("errorMessage"),
        infoPanel: null,
        switchSourceBtn: null,
        epgBtn: null,
        // 新增：进阶设置相关
        advancedBtn: null,
        advancedPanel: null,
        loudnessBtn: null,
        subDisplay: document.getElementById('subtitle-display')
    };
    let epgPopup = null;
    let playerContainer = null;
    // ==================== 新增：AI 字幕翻译相关 ====================
    let detector = null;
    let translatorCache = new Map();
    let modelStatusShown = false;
    let globalDetectedLang = null;          // 全局缓存的源语言，null 表示尚未确定
    let detectionCount = 0;                 // 已检测的字幕条数计数器
    const MAX_DETECTIONS = 10;              // 最多检测前 10 条
    const CONFIDENCE_THRESHOLD = 0.80;      // 置信度达到 80% 就锁定语言
    let translatorSupported = false;        // 全局标志：浏览器是否真正支持 Translator API
    // 一次性检测 Translator 是否真正可用
    async function checkTranslatorSupport() {
        if (!('Translator' in self)) {
            console.log("[AI Subtitle] 浏览器不支持 Translator API");
            translatorSupported = false;
            return;
        }
        try {
            // 方案1：最严格模式，同时传 source 和 target（推荐先试这个）
            let availability = await Translator.availability({
                sourceLanguage: 'en',      // 用英语作为测试源
                targetLanguage: 'zh'
            });
            console.log("[AI Subtitle] availability (en→zh) 测试成功:", availability);
            translatorSupported = true;
            return;
        } catch (err1) {
            console.warn("[AI Subtitle] availability (en→zh) 失败:", err1.message);
            try {
                // 方案2：只传 targetLanguage（部分版本接受）
                let availability = await Translator.availability({
                    targetLanguage: 'zh'
                });
                console.log("[AI Subtitle] availability (only zh) 测试成功:", availability);
                translatorSupported = true;
                return;
            } catch (err2) {
                console.warn("[AI Subtitle] availability (only zh) 失败:", err2.message);
                try {
                    // 方案3：无参调用（极少数版本）
                    let availability = await Translator.availability();
                    console.log("[AI Subtitle] availability (无参) 测试成功:", availability);
                    translatorSupported = true;
                    return;
                } catch (err3) {
                    console.warn("[AI Subtitle] availability (无参) 失败:", err3.message);
                    translatorSupported = false;
                }
            }
        }
        console.log("[AI Subtitle] 最终结论：Translator API 不可用");
        translatorSupported = false;
    }
    function showModelLoadingMessage(show = true, message = "") {
        if (show) {
            showNotification(message || "正在准备 AI 字幕翻译模型（首次使用需下载，约 100-300MB）...", "info", 5000);
            modelStatusShown = true;
        } else {
            modelStatusShown = false;
        }
    }
    async function getLanguageDetector() {
        if (detector) return detector;
        if (!('LanguageDetector' in self)) return null;
        try {
            const availability = await LanguageDetector.availability();
            if (availability === 'unavailable') return null;
            if ((availability === 'downloading' || availability === 'downloadable') && !modelStatusShown) {
                showModelLoadingMessage(true, "正在尝试下载语言检测模型...");
            }
            detector = await LanguageDetector.create();
            showModelLoadingMessage(false);
            return detector;
        } catch (err) {
            console.warn("[AI Subtitle] LanguageDetector 创建失败", err);
            return null;
        }
    }
    /**
     * 综合语言检测函数：返回统一的 { detectedLanguage, confidence } 对象
     * 模拟原生 LanguageDetector 的输出格式，确保 player.js 的锁定机制正常工作
     */
    async function getDetectedResult(track, text) {
        // 0. 清理文本，去除 HTML 标签以提高检测准确度
        const plainText = text.replace(/<[^>]+>/g, '').trim();
        if (plainText.length < 2) return null;
        // --- 方案 1: TextTrack 元数据 (最高优先级) ---
        // 如果视频流本身定义了语言，这是最可靠的，直接给予 1.0 置信度
        if (track && track.language && track.language !== 'und' && track.language !== '') {
            const lang = track.language.split('-')[0].toLowerCase();
            console.log(`[AI Subtitle] 采用轨道元数据: ${lang} (Confidence: 1.0)`);
            return { detectedLanguage: lang, confidence: 1.0 };
        }
        // --- 方案 2: 原生 AI LanguageDetector (次高优先级) ---
        /*if ('LanguageDetector' in self) {
            try {
                // 注意：这里需要考虑你之前提到的 Model not available 异常
                const availability = await LanguageDetector.availability();
                if (availability === 'available') {
                    const detectorInstance = await LanguageDetector.create();
                    const results = await detectorInstance.detect(plainText);
                    if (results && results.length > 0) {
                        console.log(`[AI Subtitle] 采用原生 AI 检测: ${results[0].detectedLanguage} (${results[0].confidence.toFixed(4)})`);
                        return results[0]; // 直接返回原生对象 {detectedLanguage, confidence}
                    }
                }
            } catch (err) {
                console.warn("[AI Subtitle] 原生 AI 检测器不可用，尝试备选方案...");
            }
        }*/
        // --- 方案 3: chrome.i18n.detectLanguage (中等优先级) ---
        // 无需下载模型，系统内置，非常稳定
        if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.detectLanguage) {
            try {
                const result = await new Promise(resolve => {
                    chrome.i18n.detectLanguage(plainText, resolve);
                });
                if (result && result.languages.length > 0) {
                    const top = result.languages[0];
                    // 模拟置信度逻辑：
                    // 如果结果列表中只有一个语言，或者第一个语言占比很高，给予 0.9
                    // 否则给予 0.7 (不足以触发锁定，但足以尝试翻译)
                    const mockConfidence = (result.languages.length === 1 || top.percentage > 85) ? 0.9 : 0.7;
                    console.log(`[AI Subtitle] 采用 i18n 检测: ${top.language} (Mock Confidence: ${mockConfidence})`);
                    return { detectedLanguage: top.language, confidence: mockConfidence };
                }
            } catch (err) {
                console.error("[AI Subtitle] i18n 检测异常:", err);
            }
        }
        // --- 方案 4: 正则表达式兜底 (最低优先级) ---
        // 针对中日韩字符的硬匹配
        let langByRegex = 'en'; // 默认英文
        let regexConfidence = 0.5; // 默认较低置信度
        if (/[\u4e00-\u9fa5]/.test(plainText)) {
            langByRegex = 'zh';
            regexConfidence = 0.9; // 汉字特征明显，置信度设高
        } else if (/[\u3040-\u30ff]/.test(plainText)) {
            langByRegex = 'ja';
            regexConfidence = 0.9; // 假名特征明显
        } else if (/[\uac00-\ud7af]/.test(plainText)) {
            langByRegex = 'ko';
            regexConfidence = 0.9;
        }
        console.log(`[AI Subtitle] 采用正则检测: ${langByRegex} (Mock Confidence: ${regexConfidence})`);
        return { detectedLanguage: langByRegex, confidence: regexConfidence };
    }
    async function getTranslatorForSource(sourceLang = 'en') {
        if (translatorCache.has(sourceLang)) {
            return translatorCache.get(sourceLang);
        }
        if (!('Translator' in self)) {
            console.warn("[AI Subtitle] Translator API 不存在");
            return null;
        }
        try {
            let availability;
            try {
                availability = await Translator.availability({
                    sourceLanguage: sourceLang,
                    targetLanguage: 'zh'
                });
                console.log(`[AI Subtitle] availability (${sourceLang}→zh) 返回:`, availability);
            } catch (e) {
                console.warn(`[AI Subtitle] availability (${sourceLang}→zh) 失败:`, e.message);
                try {
                    availability = await Translator.availability({
                        targetLanguage: 'zh'
                    });
                } catch (e2) {
                    console.warn("[AI Subtitle] availability (only zh) 失败:", e2.message);
                    availability = await Translator.availability();
                }
            }
            if (availability === 'unavailable') {
                console.warn("[AI Subtitle] 翻译模型不可用");
                return null;
            }
            if (availability === 'downloading' || availability === 'downloadable') {
                if (!modelStatusShown) {
                    showModelLoadingMessage(true, `正在下载 ${sourceLang} → 中文 翻译模型...`);
                    modelStatusShown = true;
                }
                await new Promise(r => setTimeout(r, 4000));
            }
            const newTranslator = await Translator.create({
                sourceLanguage: sourceLang,
                targetLanguage: 'zh'
            });
            translatorCache.set(sourceLang, newTranslator);
            console.log(`[AI Subtitle] 创建并缓存 translator: ${sourceLang} → zh`);
            showModelLoadingMessage(false);
            return newTranslator;
        } catch (err) {
            console.error(`[AI Subtitle] 创建 ${sourceLang} → zh translator 失败:`, err);
            return null;
        }
    }
    // ==================== 键盘事件处理函数（已新增 T 键） ====================
    function handleKeyDown(e) {
        // 如果频道列表可见，优先处理频道列表相关快捷键
        if (!UI.playlistContainer.classList.contains("hidden")) {
            // PageDown键：关闭频道列表
            if (e.code === 'PageDown' || e.key === 'PageDown' || e.keyCode === 34) {
                e.preventDefault();
                closePlaylist();
                return;
            }
            // 回车键：播放当前选中的项目
            if ((e.code === 'Enter' || e.key === 'Enter' || e.keyCode === 13)) {
                e.preventDefault();
                playSelectedSearchResult();
                // 不移除焦点，保持频道列表控制状态
                return;
            }
            // 上下箭头：在搜索结果中导航
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                hideEpgPopup(); // 隐藏旧的
                navigateSearchResults(e.code === 'ArrowUp' ? -1 : 1);
                const selected = UI.playlistItems.querySelector('.selected');
                if (selected) {
                    const index = parseInt(selected.dataset.index);
                    const item = state.currentPlaylist[index];
                    showEpgPopup(selected, item);
                }
                return;
            }
            // 搜索框特殊处理
            if (e.target === UI.playlistSearchInput) {
                // 允许在搜索框中正常输入
                return;
            }
            // 其他按键在频道列表可见时不处理全局快捷键
            // 防止上下箭头变成音量调节
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                return;
            }
            // 左右箭头：在频道列表打开时不处理，保持静默
            if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
                e.preventDefault();
                return;
            }
        }
        // 全局快捷键处理（仅当频道列表不可见时）
        // PageUp 键：调出频道列表并定位搜索框
        if (e.code === 'PageUp' || e.key === 'PageUp') {
            e.preventDefault(); // 防止浏览器搜索功能
            focusPlaylistSearch();
            showKeyFeedback('搜索频道列表');
        }
        // 空格键：播放/暂停
        else if (e.code === 'Space' || e.key === ' ' || e.keyCode === 32) {
            e.preventDefault(); // 防止空格键滚动页面
            togglePlayPause();
            // 显示控制栏反馈
            showControls();
            // 短暂显示一个视觉反馈
            showKeyFeedback('空格键: ' + (UI.videoPlayer.paused ? '播放' : '暂停'));
        }
        // 上箭头键：增加音量（仅当频道列表不可见时）
        else if (e.code === 'ArrowUp') {
            e.preventDefault();
            const result = adjustVolumeByArrow(0.05); // 每次增加5%
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最大值: 100%`);
            }
        }
        // 下箭头键：减少音量（仅当频道列表不可见时）
        else if (e.code === 'ArrowDown') {
            e.preventDefault();
            const result = adjustVolumeByArrow(-0.05); // 每次减少5%
            if (result.changed) {
                showKeyFeedback(`音量: ${result.newVolume}%`);
                showControls();
            } else {
                showKeyFeedback(`音量已达最小值: 0%`);
            }
        }
        // 左箭头键：快退5秒（仅当频道列表不可见时）
        else if (e.code === 'ArrowLeft') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.max(0, UI.videoPlayer.currentTime - 5);
                showKeyFeedback('快退: 5秒');
                showControls();
            }
        }
        // 右箭头键：快进5秒（仅当频道列表不可见时）
        else if (e.code === 'ArrowRight') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.min(UI.videoPlayer.duration, UI.videoPlayer.currentTime + 5);
                showKeyFeedback('快进: 5秒');
                showControls();
            }
        }
        // F键：全屏切换
        else if (e.code === 'KeyF' || e.key === 'f') {
            e.preventDefault();
            toggleFullscreen();
            showKeyFeedback('全屏切换');
            showControls();
        }
        // M键：静音切换
        else if (e.code === 'KeyM' || e.key === 'm') {
            e.preventDefault();
            toggleMute();
            showKeyFeedback('静音: ' + (UI.videoPlayer.muted ? '关闭' : '开启'));
            showControls();
        }
        // P键：频道列表切换
        else if (e.code === 'KeyP' || e.key === 'p') {
            e.preventDefault();
            togglePlaylistUI();
            showKeyFeedback('频道列表');
            showControls();
        }
        // 左方括号键：上一个频道
        else if (e.code === 'BracketLeft' || e.key === '[') {
            e.preventDefault();
            switchToPrevChannel();
            //showKeyFeedback('上一个频道');
            showControls();
        }
        // 右方括号键：下一个频道
        else if (e.code === 'BracketRight' || e.key === ']') {
            e.preventDefault();
            switchToNextChannel();
            //showKeyFeedback('下一个频道');
            showControls();
        }
        // S键：手动换源
        else if (e.code === 'KeyS' || e.key === 's') {
            e.preventDefault();
            manualSwitchToNextSource();
            showKeyFeedback('手动换源');
            showControls();
        }
        // I键：显示/隐藏信息面板
        else if (e.code === 'KeyI' || e.key === 'i') {
            e.preventDefault();
            toggleVideoInfo();
            showKeyFeedback('信息面板');
            showControls();
        }
        // E键：显示EPG跑马灯
        else if (e.code === 'KeyE' || e.key === 'e') {
            e.preventDefault();
            showEpgMarquee();
            showKeyFeedback('节目信息');
            showControls();
        }
        // L键：响度均衡切换
        else if (e.code === 'KeyL' || e.key === 'l') {
            e.preventDefault();
            toggleLoudnessEqualizer();
            showKeyFeedback('响度均衡: ' + (state.isLoudnessEnabled ? '开启' : '关闭'));
            showControls();
        }
        // ==================== 新增：T 键开关 AI 字幕翻译 ====================
        else if (e.code === 'KeyT' || e.key.toLowerCase() === 't') {
            if (e.ctrlKey || e.altKey || e.metaKey) return;
            e.preventDefault();
            state.isSubtitleTranslationEnabled = !state.isSubtitleTranslationEnabled;
            /*if (state.isSubtitleTranslationEnabled) {
                getLanguageDetector(); // 立即触发，此时处于手势有效期内
            }*/
            const msg = state.isSubtitleTranslationEnabled 
                ? "AI 字幕翻译已开启" 
                : "AI 字幕翻译已关闭";
            showKeyFeedback(msg);
            showNotification(msg, "info", 1800);
        }
    }
    // 新增：关闭频道列表
    function closePlaylist() {
        // 直接关闭频道列表，不通过 togglePlaylistUI 递归
        // 如果当前焦点在频道列表内，强制让它失焦
        if (document.activeElement && document.activeElement.closest('#playlist-container')) {
            document.activeElement.blur();
        }
        UI.playlistContainer.classList.add("hidden");
        UI.playlistSearchInput.blur();
        UI.playlistSearchInput.style.border = "";
        UI.playlistSearchInput.style.boxShadow = "";
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
        hideEpgPopup(); // 关闭EPG弹出框
        showKeyFeedback('关闭列表');
        showControls();
    }
    // 新增：在搜索结果中导航
    function navigateSearchResults(direction) {
        console.log("[NAV START] navigateSearchResults 被调用，direction =", direction);
        // 防护：确保 UI.playlistItems 已初始化
        if (!UI.playlistItems) {
            console.error("[NAV ERROR] UI.playlistItems 未初始化！无法继续导航");
            return;
        }
        const searchTerm = UI.playlistSearchInput.value;
        console.log("[NAV] 当前搜索词：", searchTerm || "(空)");
        // 获取所有可见的 playlist-item
        const filteredItems = Array.from(UI.playlistItems.children)
            .filter(item => item.style.display !== 'none');
        console.log("[NAV] 过滤后可见频道数量：", filteredItems.length);
        if (filteredItems.length === 0) {
            console.log("[NAV] 无可见项，返回");
            return;
        }
        // ────────────── 优先查找 .active（当前播放频道） ──────────────
        let preferredStartIndex = -1;
        // 先找 .active（视觉最可靠）
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].classList.contains('active')) {
                preferredStartIndex = i;
                console.log("[NAV] 从 .active 找到起点，位置：", i, "data-index:", filteredItems[i].dataset.index);
                break;
            }
        }
        // 如果没找到 .active，再用 state.currentPlaylistIndex 匹配
        if (preferredStartIndex === -1 && state.currentPlaylistIndex >= 0) {
            console.log("[NAV] 未找到 .active，使用 state.currentPlaylistIndex =", state.currentPlaylistIndex);
            for (let i = 0; i < filteredItems.length; i++) {
                const itemGlobalIndex = parseInt(filteredItems[i].dataset.index);
                if (itemGlobalIndex === state.currentPlaylistIndex) {
                    preferredStartIndex = i;
                    console.log("[NAV] 从 state.currentPlaylistIndex 匹配到位置：", i);
                    break;
                }
            }
        }
        if (preferredStartIndex === -1) {
            console.log("[NAV] 警告：当前播放频道不在过滤结果中，将从头/尾开始");
        } else {
            console.log("[NAV] preferredStartIndex 最终值：", preferredStartIndex);
        }
        // ────────────── 查找当前 .selected ──────────────
        let currentSelectedIndex = -1;
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].classList.contains('selected')) {
                currentSelectedIndex = i;
                console.log("[NAV] 找到已有 .selected，位置：", i);
                break;
            }
        }
        // ────────────── 决定新选中位置 ──────────────
        let newIndex;
        if (currentSelectedIndex !== -1) {
            // 有 .selected → 正常移动（后续按键）
            newIndex = currentSelectedIndex + direction;
            console.log("[NAV] 从已有 selected 移动，新位置：", newIndex);
        } else {
            // 第一次导航 → 优先选中当前播放频道（.active 或 state）
            if (preferredStartIndex !== -1) {
                newIndex = preferredStartIndex;
                console.log("[NAV] 第一次导航，选中当前播放频道 (preferredStartIndex)：", newIndex);
            } else {
                // 没有当前播放 → fallback 到头或尾
                newIndex = direction > 0 ? 0 : filteredItems.length - 1;
                console.log("[NAV] 无当前播放频道，fallback 到：", newIndex);
            }
        }
        // 环绕处理
        if (newIndex < 0) newIndex = filteredItems.length - 1;
        if (newIndex >= filteredItems.length) newIndex = 0;
        console.log("[NAV] 最终选中索引：", newIndex);
        // 移除所有旧 .selected
        filteredItems.forEach(item => item.classList.remove('selected'));
        // 添加新 .selected
        filteredItems[newIndex].classList.add('selected');
        // 滚动到选中项
        filteredItems[newIndex].scrollIntoView({
			//behavior: 'smooth',
            behavior: 'instant',
            block: 'center'
        });
        // 反馈
        const itemText = filteredItems[newIndex].textContent.trim();
        showKeyFeedback(`选中: ${itemText}`);
        maintainPlaylistFocus();
        console.log("[NAV END] 导航完成");
    }
    // 新增：保持频道列表焦点状态
    function maintainPlaylistFocus() {
        // 如果频道列表可见但焦点不在任何可输入元素上，给频道列表一个虚拟焦点
        if (!UI.playlistContainer.classList.contains("hidden") &&
            document.activeElement !== UI.playlistSearchInput &&
            !document.activeElement.classList.contains('playlist-item')) {
            // 可以给频道列表容器添加一个焦点状态样式
            UI.playlistContainer.classList.add('has-focus');
            // 或者给选中的频道列表项添加焦点
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.focus();
            }
        }
    }
    // 新增：播放选中的搜索结果
    function playSelectedSearchResult() {
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            const index = parseInt(selectedItem.dataset.index);
            if (!isNaN(index)) {
                // 播放选中的项目
                playPlaylistItem(index);
                // 播放后保持选中状态，以便继续使用上下箭头导航
                setTimeout(() => {
                    maintainPlaylistFocus();
                }, 100);
            }
        } else {
            // 如果没有选中项，提示用户
            showKeyFeedback('请先用上下箭头选择一个频道');
        }
    }
    // 新增：聚焦到频道列表搜索框
    function focusPlaylistSearch() {
        // 首先确保频道列表是可见的
        if (UI.playlistContainer.classList.contains("hidden")) {
            togglePlaylistUI(true);
        }
        // 等待一小段时间确保DOM已更新
        setTimeout(() => {
            // 聚焦到搜索框
            UI.playlistSearchInput.focus();
            // 选中所有文本以便直接输入
            UI.playlistSearchInput.select();
            // 添加一个聚焦样式
            UI.playlistSearchInput.style.border = "2px solid #4dabf7";
            UI.playlistSearchInput.style.boxShadow = "0 0 0 3px rgba(77, 171, 247, 0.3)";
            // 清除任何现有的选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, 50);
    }
    // 新增：高亮显示搜索框
    function highlightSearchBox() {
        // 移除现有的高亮元素
        const existingHighlight = document.querySelector('.search-highlight');
        if (existingHighlight) {
            existingHighlight.remove();
        }
        // 创建高亮元素
        const highlight = document.createElement('div');
        highlight.className = 'search-highlight';
        highlight.innerHTML = '✨ 搜索框已激活，输入关键词搜索频道';
        // 定位在搜索框旁边
        const rect = UI.playlistSearchInput.getBoundingClientRect();
        highlight.style.cssText = `
            position: fixed;
            top: ${rect.top - 40}px;
            left: ${rect.left}px;
            background: linear-gradient(135deg, #4dabf7, #339af0);
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: bold;
            z-index: 2000;
            pointer-events: none;
            opacity: 1;
            transition: opacity 0.3s ease;
            box-shadow: 0 4px 12px rgba(77, 171, 247, 0.4);
        `;
        // 添加一个箭头指向搜索框
        highlight.innerHTML += `
            <div style="position: absolute; bottom: -8px; left: 20px; width: 0; height: 0; border-left: 8px solid transparent; border-right: 8px solid transparent; border-top: 8px solid #339af0;"></div>
        `;
        document.body.appendChild(highlight);
        // 2秒后淡出并移除
        setTimeout(() => {
            highlight.style.opacity = '0';
            setTimeout(() => {
                if (highlight.parentNode) {
                    highlight.parentNode.removeChild(highlight);
                }
            }, 300);
        }, 2000);
    }
    // 修改：使用箭头键调整音量，返回调整结果
    function adjustVolumeByArrow(delta) {
        const oldVolume = UI.videoPlayer.volume;
        let newVolume = oldVolume + delta;
        // 限制在0-1之间
        newVolume = Math.max(0, Math.min(1, newVolume));
        // 检查是否实际发生了变化
        const changed = Math.abs(newVolume - oldVolume) > 0.001;
        if (changed) {
            UI.videoPlayer.volume = newVolume;
            UI.videoPlayer.muted = (newVolume === 0); // 如果音量为0，则静音
            // 更新音量条
            UI.volumeProgress.style.width = newVolume * 100 + "%";
            updateVolumeIcon();
            // 保存音量设置
            chrome.storage.local.set({
                volume: newVolume
            });
        }
        // 返回调整结果
        return {
            changed: changed,
            oldVolume: oldVolume * 100,
            newVolume: Math.round(newVolume * 100)
        };
    }
    /**
     * 反馈提示函数
     * 采用 Web Animations API (WAAPI) 实现，解决连续触发导致的闪烁
     */
    function showKeyFeedback(message) {
        let feedback = playerContainer.querySelector('.key-feedback');
        // 1. 如果不存在则创建，避免重复编写样式字符串
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'key-feedback';
            Object.assign(feedback.style, {
                position: 'absolute',
                bottom: '100px',
                left: '50%',
                transform: 'translateX(-50%)',
                background: 'rgba(0, 100, 200, 0.9)',
                color: 'white',
                padding: '10px 20px',
                borderRadius: '25px',
                fontSize: '14px',
                fontWeight: 'bold',
                zIndex: '1001',
                pointerEvents: 'none',
                boxShadow: '0 4px 12px rgba(0, 100, 200, 0.3)',
                minWidth: '120px',
                textAlign: 'center'
            });
            playerContainer.appendChild(feedback);
        }
        // 2. 更新内容
        feedback.textContent = message;
        // 3. 核心：使用 WAAPI 处理动画
        // 如果当前有正在运行的动画，先取消它
        if (feedback.currentAnimation) {
            feedback.currentAnimation.cancel();
        }
        // 创建新动画：瞬间回到不透明，维持1秒，然后0.3秒淡出
        const animation = feedback.animate([
            { opacity: 1, transform: 'translateX(-50%) scale(1)', offset: 0 },
            { opacity: 1, transform: 'translateX(-50%) scale(1)', offset: 0.8 },
            { opacity: 0, transform: 'translateX(-50%) scale(0.95)', offset: 1 }
        ], {
            duration: 1300,
            easing: 'ease-out',
            fill: 'forwards'
        });
        feedback.currentAnimation = animation;
        animation.onfinish = () => {
            if (animation.playState === 'finished' && feedback.parentNode) {
                feedback.remove();
            }
        };
    }
    // ==================== AI 字幕渲染函数（支持翻译 + 双语显示） ====================
    const bindSubtitleEvents = () => {
        const tracks = UI.videoPlayer.textTracks;
        for (let i = 0; i < tracks.length; i++) {
            const track = tracks[i];
            // 确保不重复绑定
            track.mode = 'hidden';
            track.oncuechange = null;
            track.oncuechange = async (e) => {
                const activeCues = e.target.activeCues;
                // 1. 如果没有活动字幕，清空显示并退出
                if (!activeCues || activeCues.length === 0) {
                    UI.subDisplay.innerHTML = '';
                    return;
                }
                // 2. 如果翻译被关闭，或核心翻译 API 不可用，只显示经过清洗的原文
                if (!state.isSubtitleTranslationEnabled || !translatorSupported) {
                    let combined = [];
                    for (let cue of activeCues) {
                        let text = cleanSubtitleText(cue.text);
                        if (text) combined.push(text);
                    }
                    UI.subDisplay.innerHTML = combined.length 
                        ? `<span class="subtitle-text">${combined.join('<br>')}</span>` 
                        : '';
                    // 提示不支持的情况
                    if (state.isSubtitleTranslationEnabled && !translatorSupported) {
                        showNotification("当前浏览器不支持 AI 翻译（需 Chrome 138+ 并启用实验项）", "warning", 5000);
                        state.isSubtitleTranslationEnabled = false; 
                    }
                    return;
                }
                let combinedTextArray = [];
                // 3. 遍历当前活动字幕块
                for (let cue of activeCues) {
                    let originalText = cue.text?.trim();
                    if (!originalText) continue;
                    // 使用统一的清洗逻辑
                    let cleanedText = cleanSubtitleText(originalText);
                    if (!cleanedText) continue;
                    let displayHtml = cleanedText;
                    // 过滤无意义内容（如纯标点或过短字符）
                    const plainText = cleanedText.replace(/<[^>]+>/g, '').trim();
                    if (plainText.length < 2 || !/[^\s<>/]/.test(plainText)) {
                        combinedTextArray.push(displayHtml);
                        continue;
                    }
                    // === 核心优化：智能语言识别与锁定机制 ===
                    let currentSourceLang = globalDetectedLang || 'en'; // 默认兜底
                    // 如果全局语言未确定，且未达到最大检测次数，则触发检测
                    if (!globalDetectedLang && detectionCount < MAX_DETECTIONS) {
                        try {
                            detectionCount++;
                            console.log(`[AI Subtitle] 正在进行第 ${detectionCount} 次语言识别...`);
                            // 调用我们新设计的综合检测函数（模拟了原生置信度）
                            const result = await getDetectedResult(track, plainText);
                            if (result) {
                                const { detectedLanguage, confidence } = result;
                                console.log(`[AI Subtitle] 检测结果: ${detectedLanguage} (置信度: ${confidence.toFixed(2)})`);
                                // 只有置信度达标，才锁定为全局源语言
                                if (confidence >= CONFIDENCE_THRESHOLD || detectionCount >= MAX_DETECTIONS) {
                                    globalDetectedLang = detectedLanguage;
                                    console.log(`[AI Subtitle] 🛡️ 已锁定全局源语言为: ${globalDetectedLang}`);
                                }
                                currentSourceLang = detectedLanguage;
                            }
                        } catch (err) {
                            console.warn("[AI Subtitle] 语言识别环节异常:", err);
                        }
                    }
                    // === 翻译部分：基于识别到的语言进行翻译 ===
                    try {
                        // 根据识别出的 currentSourceLang 获取对应的翻译器实例
                        const currentTrans = await getTranslatorForSource(currentSourceLang);
                        if (currentTrans) {
                            const translated = await currentTrans.translate(cleanedText);
                            // 确保翻译结果有效且不等于原文
                            if (translated && translated.trim() !== cleanedText.replace(/<br>/g, ' ').trim()) {
                                displayHtml += `<br><span class="translated-subtitle">${translated}</span>`;
                            }
                        }
                    } catch (err) {
                        console.warn("[AI Subtitle] AI 翻译执行失败:", err);
                    }
                    combinedTextArray.push(displayHtml);
                }
                // 4. 最终渲染到 UI 
                UI.subDisplay.innerHTML = combinedTextArray.length 
                    ? `<span class="subtitle-text">${combinedTextArray.join('<br><br>')}</span>` 
                    : '';
            };
        }
    };
    /**
     * 辅助工具：清洗字幕文本，处理对话格式
     */
    function cleanSubtitleText(text) {
        if (!text) return '';
        const dialogRegex = /\n(?=\s*([-—–]|>>|[^:\n：]+\s*[:：]))/g;
        return text.trim()
            .replace(dialogRegex, '[DIALOG_BR]')
            .replace(/\n/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .replace(/\[DIALOG_BR\]/g, '<br>');
    }
    // ==================== 键盘事件处理结束 ====================
    // 新增：加载EPG数据
    async function loadEPG(nocache = false) {
        if (!CONFIG.EPG_ENABLED) return;
        try {
            state.lastEpgRefreshTime = Date.now(); // 更新上次刷新时间
            console.log('[EPG] 开始加载:', CONFIG.EPG_URL, nocache ? '(忽略缓存)' : '');
            // 修改点：根据 nocache 参数配置 fetch 选项
            const fetchOptions = nocache ? { cache: 'reload' } : {};
            const response = await fetch(CONFIG.EPG_URL, fetchOptions);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status} - ${response.statusText}`);
            }
            let text;
            // 判断是否需要解压（根据 Content-Type 或文件后缀）
            const contentType = response.headers.get('content-type') || '';
            const isGzipped = 
                contentType.includes('gzip') || 
                contentType.includes('application/gzip') ||
                CONFIG.EPG_URL.toLowerCase().endsWith('.gz');
            if (isGzipped && 'DecompressionStream' in window) {
                console.log('[EPG] 检测到 gzip 压缩，使用 DecompressionStream 解压');
                const buffer = await response.arrayBuffer();
                const decompressedStream = new Response(
                    new Blob([buffer]).stream().pipeThrough(
                        new DecompressionStream('gzip')
                    )
                );
                text = await decompressedStream.text();
            } else {
                // 普通文本或已自动解压的情况
                text = await response.text();
            }
            const parser = new DOMParser();
            const xml = parser.parseFromString(text, 'text/xml');
            // 检查解析是否成功
            if (xml.getElementsByTagName('parsererror').length > 0) {
                throw new Error('XML 解析失败，可能文件格式错误或未正确解压');
            }
            // ==================== 原有解析逻辑 ====================
            const channels = xml.getElementsByTagName('channel');
            state.channelMap = {}; // name.lower -> id (备用匹配)
            for (let ch of channels) {
                const id = ch.getAttribute('id');
                const displayName = ch.querySelector('display-name')?.textContent?.trim();
                if (displayName && id) {
                    state.channelMap[displayName.toLowerCase()] = id;
                }
            }
            const programmes = xml.getElementsByTagName('programme');
            state.epgData = {};
            for (let prog of programmes) {
                const channelId = prog.getAttribute('channel');
                if (!state.epgData[channelId]) state.epgData[channelId] = [];
                const startStr = prog.getAttribute('start');
                const stopStr = prog.getAttribute('stop');
                const start = parseEpgTime(startStr);
                const stop = parseEpgTime(stopStr);
                const titleElem = prog.querySelector('title');
                const title = titleElem?.textContent?.trim() || '未知节目';
                state.epgData[channelId].push({ start, stop, title });
            }
            // 按开始时间排序
            for (let id in state.epgData) {
                state.epgData[id].sort((a, b) => a.start - b.start);
            }
            console.log(`[EPG] 加载完成，共 ${Object.keys(state.epgData).length} 个频道节目表`);
            // 新增: 计算EPG到期时间（最晚节目结束时间）
            calculateEpgExpiry();
            // 新增: 启动到期前刷新定时器
            scheduleEpgRefresh();
        } catch (err) {
            console.error('[EPG] 加载失败:', err);
        }
    }
    // 新增：计算EPG到期时间
    function calculateEpgExpiry() {
        let maxStop = 0;
        for (let id in state.epgData) {
            const programs = state.epgData[id];
            if (programs.length > 0) {
                const lastStop = programs[programs.length - 1].stop;
                if (lastStop > maxStop) maxStop = lastStop;
            }
        }
        state.epgExpiryTime = maxStop;
        console.log(`[EPG] 计算到期时间: ${new Date(maxStop).toLocaleString()}`);
    }
    // 新增：调度EPG刷新（到期前1小时刷新）
    function scheduleEpgRefresh() {
        // 1. 清理现有定时器，确保不重叠
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            state.timers.epgRefresh = null;
        }
        // 2. 前置检查
        if (!CONFIG.EPG_ENABLED || state.epgExpiryTime <= 0) return;
        const now = Date.now();
        const timeToExpiry = state.epgExpiryTime - now;
        // 计算触发更新的目标时间点：过期前1小时 (3600000 ms)
        // 如果现在已经进入了过期前1小时，则目标延迟为 0
        const targetTriggerDelay = Math.max(timeToExpiry - 3600000, 0);
        // 设置触发器
        state.timers.epgRefresh = setTimeout(() => {
            const currentTime = Date.now();
            const timeSinceLastRefresh = currentTime - state.lastEpgRefreshTime;
            // 3. 触发时检查：是否满足最小刷新间隔
            if (timeSinceLastRefresh >= MIN_EPG_REFRESH_INTERVAL) {
                console.log('[EPG] 满足刷新条件（进入过期预警期且已过最小间隔），开始更新...');
                loadEPG(true);
            } else {
                // 4. 不满足间隔：计算还需等待多久并安排补跳
                const remainingWait = MIN_EPG_REFRESH_INTERVAL - timeSinceLastRefresh;
                console.log(`[EPG] 触发太频繁，等待最小间隔：还需 ${Math.round(remainingWait / 1000)} 秒后补刷`);
                // 覆盖当前的 timer，确保最后一次补刷能执行
                state.timers.epgRefresh = setTimeout(() => {
                    console.log('[EPG] 最小间隔已满，执行补刷...');
                    loadEPG(true);
                }, remainingWait);
            }
        }, targetTriggerDelay);
        if (targetTriggerDelay > 0) {
            console.log(`[EPG] 调度成功：将于 ${Math.round(targetTriggerDelay / 3600000 * 10) / 10} 小时后尝试触发更新`);
        } else {
            console.log('[EPG] 处于过期预警期，尝试立即触发检查');
        }
    }
    // 新增：解析EPG时间字符串到时间戳
    function parseEpgTime(timeStr) {
        if (!timeStr) return 0;
        const year = timeStr.substring(0, 4);
        const month = timeStr.substring(4, 6);
        const day = timeStr.substring(6, 8);
        const hour = timeStr.substring(8, 10);
        const min = timeStr.substring(10, 12);
        const sec = timeStr.substring(12, 14);
        const tz = timeStr.substring(14).trim() || '+0000';
        const dateStr = `${year}-${month}-${day}T${hour}:${min}:${sec}${tz.replace(' ', '')}`;
        const ts = Date.parse(dateStr);
        return isNaN(ts) ? 0 : ts;
    }
    // 新增：格式化时间戳为本地时间字符串
    function formatEpgTime(ts) {
        if (!ts) return '未知';
        const date = new Date(ts);
        return date.toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'});
    }
    /**
     * 精准清洗频道名称（修复CCTV10科教频道匹配问题）
     * @param {string} name - 原始频道名称
     * @returns {string} 清洗后的名称
     */
    function cleanName(name) {
        if (!name || typeof name !== 'string') return "";
        let cleaned = name
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/[^\w\+\-\u4e00-\u9fa5]/g, "")
            .trim();
        // 统一符号
        cleaned = cleaned.replace(/plus/g, '+');
        console.log(`[EPG调试] 清洗: "${name}" -> "${cleaned}"`);
        // ========== 特殊频道映射表 ==========
        const specialChannels = {
            // 4K/8K超高清频道
            'cctv4k': 'cctv4k',
            'cctv8k': 'cctv8k',
            'cctv4k超高清': 'cctv4k',
            'cctv8k超高清': 'cctv8k',
            'cctv-4k': 'cctv4k',
            'cctv-8k': 'cctv8k',
            // 错误名称修正
            'cctv-': 'cctv',
            'cctv_': 'cctv',
            'cctv ': 'cctv',
            // 其他特殊处理
            'cctv4k+': 'cctv4k+',
            'cctv8k+': 'cctv8k+',
            'cctv5+体育赛事': 'cctv5+',
            'cctv5+': 'cctv5+',
            'cctv4欧洲': 'cctv4欧洲',
            'cctv4美洲': 'cctv4美洲',
            '文化精品':'央视文化精品',
            'cctv文化精品':'央视文化精品'
        };
        // 先检查特殊频道映射
        if (specialChannels[cleaned]) {
            console.log(`[EPG调试] 特殊频道映射: "${cleaned}" -> "${specialChannels[cleaned]}"`);
            return specialChannels[cleaned];
        }
        // ========== 正则匹配 ==========
        // 1. 4K/8K频道（优先于数字频道）
        const hdMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(4k|8k)(\+)?$/i);
        if (hdMatch) {
            const result = hdMatch[1] + hdMatch[2] + (hdMatch[3] || '');
            console.log(`[EPG调试] 4K/8K频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 2. 带+号的数字频道
        const plusMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)\+$/i);
        if (plusMatch) {
            const result = plusMatch[1] + plusMatch[2] + '+';
            console.log(`[EPG调试] 带+号频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 3. 普通数字频道
        const numberMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)/i);
        if (numberMatch) {
            const result = numberMatch[1] + numberMatch[2];
            console.log(`[EPG调试] 数字频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 4. CCTV+中文
        if (cleaned.startsWith('cctv')) {
            const withoutCctv = cleaned.substring(4);
            if (withoutCctv && /^[\u4e00-\u9fa5]+$/.test(withoutCctv)) {
                console.log(`[EPG调试] CCTV+中文: "${cleaned}" -> "${withoutCctv}"`);
                return withoutCctv;
            }
        }
        // 5. 后缀处理
        const suffixes = [
            '超高清', '高清', '标清', 'hd', 'sd', 'fhd', 'uhd',
            '台', '频道', 'channel', 'tv'
        ];
        for (const suffix of suffixes) {
            if (cleaned.endsWith(suffix)) {
                const result = cleaned.slice(0, -suffix.length);
                console.log(`[EPG调试] 去除后缀: "${cleaned}" -> "${result}"`);
                // 如果去除后缀后是空字符串，返回原始
                if (!result) {
                    console.log(`[EPG调试] 警告: 去除后缀后为空，返回原始: "${cleaned}"`);
                    return cleaned;
                }
                return result;
            }
        }
        console.log(`[EPG调试] 最终结果: "${cleaned}"`);
        return cleaned;
    }
    // 新增：获取频道ID
    function getChannelId(item) {
        let prechId = item.attributes ? item.attributes['tvg-id'] : '';
        let chId = cleanName(prechId);
        if (!chId) {
            const nameLower = cleanName(item.title || '');
            chId = state.channelMap[nameLower] || nameLower; // 如果没有匹配，用name作为fallback
        }
        return chId;
    }
    // 新增：获取当前节目
    function getCurrentProgram(programs) {
        const now = Date.now();
        return programs.find(p => now >= p.start && now < p.stop) || null;
    }
    // 新增：获取接下来几个节目
    function getNextPrograms(programs, num = 3) {
        const now = Date.now();
        const future = programs.filter(p => p.start > now).sort((a, b) => a.start - b.start);
        return future.slice(0, num);
    }
    // 新增：显示EPG弹出框（智能自适应位置，避免被边缘挡住）
    function showEpgPopup(itemEl, item) {
        if (!CONFIG.EPG_ENABLED) return;
        // 先隐藏旧的弹出框（如果存在）
        if (epgPopup) hideEpgPopup();
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const next = getNextPrograms(programs, 10);
        if (!current && next.length === 0) return;
        // 使用全局的 playerContainer（已在 init 中赋值）
        if (!playerContainer) {
            console.warn("playerContainer 未初始化，无法显示 EPG 弹出框");
            return;
        }
        epgPopup = document.createElement('div');
        epgPopup.className = 'epg-popup';
        let html = '';
        // 第一行显示频道名称
        const channelName = item.title || "未知频道";
        html += `<div style="color: #FFFFFF; font-weight: bold; font-size: 14px; margin-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.2); padding-bottom: 4px;">${channelName}</div>`;
        // 当前节目
        if (current) {
            html += `
            <div class="epgpopup-row">
                <div class="epgpopup-info-part">
                    <span style="color: #4CAF50; font-weight: bold;">当前:</span> 
                    <span class="epg-text-info">[${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)}]</span>
                </div>
                <div class="epgpopup-title-part">${current.title}</div>
            </div>`;
        }
        // 后续节目
        next.forEach((p, i) => {            
            const hideLater = i > 0 ? 'style="visibility: hidden;"' : '';
            html += `
            <div class="epgpopup-row">
                <div class="epgpopup-info-part">
                    <span ${hideLater} style="color: #FFA500; font-weight: bold;">稍后:</span> 
                    <span class="epg-text-info">[${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)}]</span>
                </div>
                <div class="epgpopup-title-part">${p.title}</div>
            </div>`;
        });
        epgPopup.innerHTML = html;
        // 先隐藏，添加到 playerContainer 以正确计算尺寸
        epgPopup.style.visibility = 'hidden';
        playerContainer.appendChild(epgPopup);
        // 使用 requestAnimationFrame 确保布局计算准确
        requestAnimationFrame(() => {
            // 获取频道项相对于视口的 rect
            const itemRect = itemEl.getBoundingClientRect();
            // 获取 playerContainer 相对于视口的 rect
            const containerRect = playerContainer.getBoundingClientRect();
            // 获取频道列表容器相对于视口的 rect
            const playlistRect = UI.playlistContainer.getBoundingClientRect();
            // 计算相对于 playerContainer 的坐标
            const relativeTop = itemRect.top - containerRect.top;
            const playlistRelativeLeft = playlistRect.left - containerRect.left;
            // 获取弹出框自身的尺寸
            const popupRect = epgPopup.getBoundingClientRect();
            const containerHeight = playerContainer.clientHeight;
            const margin = 8; // 目标间隔 8px
            // 核心逻辑：右边缘固定在频道列表左侧 8px 处
            // left = 频道列表左边界 - 弹窗宽度 - 间隔
            let left = playlistRelativeLeft - popupRect.width - margin;
            let top = relativeTop;
            // 垂直方向智能调整（保持原有的垂直逻辑，确保不超出容器）
            const spaceBelow = containerHeight - (relativeTop + itemRect.height);
            if (spaceBelow < popupRect.height && relativeTop > popupRect.height) {
                // 下方空间不足且上方空间足够，则向上对齐
                top = relativeTop + itemRect.height - popupRect.height;
            }
            // 最终边界保护（防止弹出框超出容器顶部或底部）
            top = Math.max(10, Math.min(top, containerHeight - popupRect.height - 10));
            // 应用位置和样式
            epgPopup.style.position = 'absolute';
            epgPopup.style.right = `${containerRect.right - playlistRect.left + margin}px`;
            epgPopup.style.left = 'auto'; // 确保 left 不干扰 right 定位
            epgPopup.style.top = `${top}px`;
            epgPopup.style.visibility = 'visible';
            // 其他视觉样式（建议后续可移到 CSS 类中统一管理）
            epgPopup.style.maxHeight   = `${containerHeight * 0.75}px`;
            epgPopup.style.overflowY   = 'auto';
            epgPopup.style.maxWidth    = '340px';
            epgPopup.style.minWidth    = 'auto'; // 允许根据内容收缩
            epgPopup.style.background  = 'rgba(59,59,68,0.88)';
            epgPopup.style.color       = 'rgb(239, 239, 241)';
            epgPopup.style.padding     = '12px';
            epgPopup.style.borderRadius = '8px';
            epgPopup.style.zIndex      = '1001';
            epgPopup.style.boxShadow   = '0 6px 20px rgba(0,0,0,0.6)';
        });
    }
    // 新增：隐藏EPG弹出框
    function hideEpgPopup() {
        if (epgPopup) {
            // 确保它确实在 playerContainer 里（可选，但推荐）
            if (epgPopup.parentNode === playerContainer) {
                epgPopup.remove();
            } else if (epgPopup.parentNode) {
                // 如果不在预期位置，也强制移除
                epgPopup.parentNode.removeChild(epgPopup);
                console.warn("epgPopup 被挂载到了非预期的父节点，已强制移除");
            } else {
                // 已经不在 DOM 中，直接置空
                console.warn("epgPopup 已不在 DOM 中");
            }
            epgPopup = null;
        }
    }
    /**
     * EPG 跑马灯函数
     * 改进：消除强制重绘，使用 WAAPI 精准控制动画生命周期
     */
    function showEpgMarquee() {
        // 1. 基础拦截逻辑 (保持不变)
        if (!CONFIG.EPG_ENABLED) {
            showNotification('EPG未启用', 'warning', 2000);
            return;
        } else if (!state.isM3UPlaylist) {
            showNotification('当前不是频道列表模式', 'warning', 2000);
            return;
        }
        if (state.isMarqueeActive) return;
        // 2. 数据准备
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const nextProgs = getNextPrograms(programs, 2);
        const chName = state.currentChannelInfo?.title || item?.title || "未知频道";
        const currentTime = getCurrentTimeStr('time');
        const spacing = '\u00A0'.repeat(8); // 使用 Unicode 空格，避免 innerHTML 注入风险
        // 3. 构建 HTML 内容 
        let htmlContent = current ? `
            <span class="epg-text-normal">${currentTime}</span>
            <span class="epg-text-ch">【${chName}】</span>
            <span class="epg-text-playing">正在播放: 《${current.title}》</span> 
            <span class="epg-text-info">(${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)})</span>${spacing}` 
            : '';
        nextProgs.forEach((p, i) => {
            const className = i === 0 ? 'epg-text-next' : 'epg-text-later';
            const label = i === 0 ? '下一个' : '稍后';
            htmlContent += `<span class="${className}">${label}: 《${p.title}》</span> 
                            <span class="epg-text-info">(${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)})</span>${spacing}`;
        });
        if (!htmlContent) {
            showNotification('当前频道暂无节目信息', 2000);
            return;
        }
        // 4. 创建 DOM (一次性构建)
        const container = document.createElement('div');
        container.className = 'epg-marquee-container active'; // 初始即 active
        const content = document.createElement('span');
        content.className = 'epg-marquee-content';
        content.style.fontSize = `${CONFIG.MARQUEE_FONT_SIZE}px`;
        content.innerHTML = htmlContent;
        container.appendChild(content);
        playerContainer.appendChild(container);
        // 5. 核心：无需测量，直接动画
        // 我们让内容从容器 100% 处移动到 -100% 处
        const containerWidth = container.clientWidth;
        const contentWidth = content.offsetWidth; // 此时元素已在文档流中，读取宽度
        const speed = CONFIG.MARQUEE_SPEED || 110;
        const duration = ((containerWidth + contentWidth) / speed) * 1000;
        state.isMarqueeActive = true;
        // 6. 使用 WAAPI 执行动画
        const animation = content.animate([
            { transform: `translateX(${containerWidth}px)` },
            { transform: `translateX(-${contentWidth}px)` }
        ], {
            duration: duration,
            easing: 'linear',
            fill: 'forwards'
        });
        // 7. 动画结束后的清理逻辑 (精准且优雅)
        animation.onfinish = () => {
            // 先淡出容器
            const fadeOut = container.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 400, fill: 'forwards' });
            fadeOut.onfinish = () => {
                if (container.parentNode) container.remove();
                state.isMarqueeActive = false;
            };
        };
        //showKeyFeedback('节目信息');
    }
    /**
     * 获取当前时间/日期字符串
     * @param {string} mode - 模式: 'datetime'(默认), 'date', 'time'
     * @param {string} separator - 日期和时间之间的分隔符，默认为空格
     * @returns {string} 格式化后的字符串
     */
    function getCurrentTimeStr(mode = 'datetime', separator = ' ') {
        const d = new Date();
        // 1. 获取并格式化日期部分 (YYYY-MM-DD)
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        // 2. 获取并格式化时间部分 (HH:mm)
        const hours = String(d.getHours()).padStart(2, '0');
        const minutes = String(d.getMinutes()).padStart(2, '0');
        const timeStr = `${hours}:${minutes}`;
        // 3. 根据模式返回对应格式
        switch (mode) {
            case 'date':
                return dateStr;
            case 'time':
                return timeStr;
            case 'datetime':
            default:
                return `${dateStr}${separator}${timeStr}`;
        }
    }
    function init() {
        playerContainer = document.querySelector(".player-container");
        if (!playerContainer) {
            console.error("找不到 .player-container 元素");
            return;
        }
        checkTranslatorSupport();
        addStyles();
        createDynamicUI();
        loadVolumeSettings();
        loadSettings(); // 从 storage 加载用户设置
        loadBlacklist(); // 加载黑名单
        parseInitialUrl();
        initGlobalEvents();
        addButtonHoverEffects();
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
        }
        if (CONFIG.EPG_ENABLED && state.isM3UPlaylist) {
            loadEPG();
        }
    }
    function addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .control-btn {
                background: rgba(255,255,255,0.12);
                border: none;
                color: white;
                padding: 6px 10px;
                margin: 0 6px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 15px;
            }
            .control-btn:disabled {
                opacity: 0.4;
                cursor: not-allowed;
            }
            .advanced-panel {
                position: absolute;
                bottom: 60px;
                right: 20px;
                background: rgba(20,20,30,0.95);
                border-radius: 8px;
                padding: 12px 16px;
                min-width: 240px;
                max-width: 320px;
                box-shadow: 0 6px 24px rgba(0,0,0,0.7);
                backdrop-filter: blur(8px);
                border: 1px solid rgba(255,255,255,0.12);
                z-index: 150;
                color: white;
                font-size: 13px;
            }
            /*进阶设置面板限高*/
            .advanced-panel {
                /* 设置最大高度，防止超出容器 */
                max-height: 80%; 
                /* 核心：内容过多时显示垂直滚动条 */
                overflow-y: auto; 
                /* 避免内容紧贴边缘 */
                padding-right: 5px; 
                /* 确保面板在容器内定位正确（如果需要） */
                position: absolute;
                z-index: 100;
            }            
            /* 优化滚动条样式（可选） */
            .advanced-panel::-webkit-scrollbar {
                width: 4px;
            }
            .advanced-panel::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 2px;
            }
            .section {
                margin: 12px 0;
            }
            .section-title {
                color: #4dabf7;
                font-weight: bold;
                margin-bottom: 6px;
                font-size: 14px;
            }
            .option-item {
                padding: 6px 10px;
                cursor: pointer;
                border-radius: 4px;
                margin: 2px 0;
                transition: all 0.15s;
            }
            .option-item:hover {
                background: rgba(77,171,247,0.25);
            }
            .option-item.active {
                background: rgba(77,171,247,0.45);
                font-weight: 500;
            }
            .option-item.disabled {
                color: #777;
                cursor: not-allowed;
                pointer-events: none;
            }
            .switch-source-btn:hover {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
                transform: scale(1);
                transition: all 0.2s ease;
            }
            .switch-source-btn:active {
                transform: scale(1);
                transition: all 0.1s ease;
            }
            /* info-panel 样式 */
            /* 信息面板主容器 */
            .info-panel {
                display: none; /* 默认隐藏，由 JS 控制显示 */
                position: absolute;
                right: 350px !important;
                left: auto !important;
                bottom: 60px;
                z-index: 20;
                /* 现代玻璃拟态视觉 */
                background: rgba(59, 59, 68, 0.85) !important;
                backdrop-filter: blur(12px) saturate(160%);
                -webkit-backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                padding: 14px 18px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
                /* 网格布局核心：第一列自适应宽度，第二列填充 */
                display: grid;
                grid-template-columns: auto 1fr;
                column-gap: 8px; /* 冒号与数值之间的间距 */
                row-gap: 6px;     /* 行与行之间的间距 */
                font-size: 13px;
                line-height: 1.4;
                pointer-events: none; /* 防止面板遮挡点击 */
            }
            /* 强制覆盖 grid 行为，当 JS 设置 display: grid 时生效 */
            .info-panel[style*="display: block"],
            .info-panel[style*="display: inline-grid"] {
                display: grid !important;
            }
            /* 每一行的容器 */
            .info-row {
                display: contents; /* 关键：使子元素直接参与父级 Grid 布局 */
            }
            /* 标签组：包含文字和冒号 */
            .info-label-group {
                grid-column: 1;      /* 占据网格第一列 */
                display: flex;
                justify-content: flex-start;
                align-items: center;
                white-space: nowrap;
            }
            .info-label {
                color: #4dabf7;      /* 蓝色标签 */
                font-weight: 500;
                text-shadow: 0 0 1px rgba(0, 0, 0, 0.3); 
                letter-spacing: -0.02em;
                text-rendering: optimizeLegibility;
            }
            .info-colon {
                color: #20c997;      /* 青色冒号 */
                margin-left: 2px;    /* 紧贴标签文字 */
            }
            /* 数值对齐：占据第二列 */
            .info-value {
                grid-column: 2;      /* 占据网格第二列 */
                color: #efeff1;
                /*font-weight: 600;*/
                /*font-family: 'Consolas', 'Monaco', monospace;*/ /* 等宽字体保证数值对齐美观 */
                text-align: left;
                text-shadow: 0 0 1px rgba(0, 0, 0, 0.3); 
                letter-spacing: -0.02em;
                text-rendering: optimizeLegibility;
            }
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -10px); }
                15% { opacity: 1; transform: translate(-50%, 0); }
                85% { opacity: 1; transform: translate(-50%, 0); }
                100% { opacity: 0; transform: translate(-50%, -10px); }
            }
            .blacklist-error {
                background: linear-gradient(135deg, #ff6b6b, #c92a2a) !important;
                border: 2px solid #ff6b6b !important;
                color: white !important;
                font-weight: bold !important;
                padding: 15px !important;
                border-radius: 8px !important;
            }
            /* 新增：键盘反馈动画 */
            @keyframes keyFeedbackFlash {
                0% { transform: translateX(-50%) scale(0.9); opacity: 0; }
                15% { transform: translateX(-50%) scale(1.1); opacity: 1; }
                30% { transform: translateX(-50%) scale(1); opacity: 1; }
                85% { transform: translateX(-50%) scale(1); opacity: 1; }
                100% { transform: translateX(-50%) scale(0.9); opacity: 0; }
            }
            .key-feedback {
                animation: keyFeedbackFlash 1s ease;
            }
            /* 快捷键提示样式 */
            .shortcut-hint {
                position: absolute;
                top: 5px;
                right: 10px;
                background: rgba(0, 0, 0, 0.7);
                color: #aaa;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 11px;
                z-index: 10;
                cursor: help;
                transition: all 0.3s ease;
            }
            .shortcut-hint:hover {
                background: rgba(0, 0, 0, 0.9) !important;
                color: white;
                transform: scale(1.05);
            }
            /* 快捷键提示更新 */
            .shortcut-hint table tr td:first-child b {
                color: #4dabf7;
            }
            /* 搜索框聚焦样式 */
            .playlist-search:focus {
                border-color: #4dabf7 !important;
                box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.3) !important;
                outline: none !important;
            }
            /* 新增：搜索结果选中样式 */
            .playlist-item.selected {
				position: relative; /* 必须：作为伪元素的定位基准 */
                background: linear-gradient(180deg, #000000, #000000) !important;
                color: white !important;
                font-weight: bold !important;
                /*border-left: 4px solid #f59f00 !important;*/
				border-left: none !important; 
                outline: none !important; /* 彻底移除边框 */
                outline-offset: -2px;
            }
            .playlist-item.selected::before {
              content: "";
              position: absolute;
              left: 0;
              top: 0;
              bottom: 0;
              width: 4px; /* 侧边条宽度 */
              background: #f59f00;
              /* 可选：让侧边条稍微圆润一点 */
              border-radius: 2px 0 0 2px;
              /* 增加微弱的外发光 */
              box-shadow: 1px 0 4px rgba(0, 0, 0, 0.1);
            }	
            .playlist-item.selected:hover {
                background: linear-gradient(135deg, #339af0, #1864ab) !important;
            }
            /* 频道列表焦点状态 */
            #playlist-container:focus-within {
                border-color: #4dabf7;
            }
            .playlist-item:focus {
                outline: none !important; /* 彻底移除蓝色边框 */
                outline-offset: -2px;
            }
            /* 核心修复：确保容器有高度且允许滚动 */
            #playlist-container {
                overflow-y: auto !important; /* 强制开启垂直滚动 */
                scrollbar-width: thin;
                scrollbar-color: rgba(255, 255, 255, 0.5) transparent;
            }
            /* 音量极限状态提示 */
            @keyframes limitFlash {
                0% { transform: translateX(-50%) scale(1); }
                50% { transform: translateX(-50%) scale(1.1); background: rgba(255, 59, 48, 0.9); }
                100% { transform: translateX(-50%) scale(1); }
            }
            .volume-limit {
                animation: limitFlash 0.5s ease;
            }
            /* 新增：当前节目样式 */
            .current-program {
                display: block;
                font-size: 0.8em;
                color: #aaa;
                margin-top: 2px;
            }
            /* 新增：EPG弹出框样式 */
            .epg-popup {
                transition: opacity 0.2s ease, top 0.2s ease; /* 移除对 width 的过渡，防止跳动 */
                max-width: 340px;
                font-size: 12px;
                line-height: 1.2;
                box-sizing: border-box;
            }
            .epgpopup-row {
                display: flex;
                align-items: flex-start; /* 顶部对齐 */
                line-height: 1.2;
                margin-bottom: 5px;
                font-size: 12px; /* 根据需要调整 */
                width: 100%; /* 确保容器占满 */
            }
            .epgpopup-info-part {
                flex-shrink: 0; /* 防止时间部分被压缩 */
                margin-right: 5px;
                white-space: nowrap; /* 保证时间不换行 */
            }
            .epgpopup-title-part {
                flex: 1; /* 占据剩余空间 */
                word-break: break-all; /* 允许在长单词内换行 */
                border-bottom: 1px dashed rgba(255, 255, 255, 0.2);
                padding-bottom: 0px;
                text-shadow: 0 0 1px rgba(0, 0, 0, 0.3); 
                letter-spacing: -0.02em;
                text-rendering: optimizeLegibility;
            }
            /* 最后一个标题去掉下划线，保持清爽 */
            .epgpopup-row:last-of-type .epgpopup-title-part {
                border-bottom: none;
            }
            /* 跑马灯外层容器：负责位置和毛玻璃质感 */
            .epg-marquee-container {
                position: absolute;
                top: 15px;
                left: 50%;
                transform: translateX(-50%);
                width: 90%;
                max-width: 1200px;
                z-index: 1000;
                overflow: hidden; /* 必须保留，裁切溢出文字 */
                pointer-events: none;
                user-select: none;
                /* 胶囊风格外观 */
                background: rgba(59, 59, 68, 0.85);
                backdrop-filter: blur(12px) saturate(160%);
                -webkit-backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 50px; /* 彻底圆角化，更现代化 */
                /* 两端渐变遮罩：让文字进入和消失时产生“隐现”效果 */
                mask-image: linear-gradient(90deg, 
                    transparent 0%, 
                    black 5%, 
                    black 95%, 
                    transparent 100%
                );
                -webkit-mask-image: linear-gradient(90deg, 
                    transparent 0%, 
                    black 5%, 
                    black 95%, 
                    transparent 100%
                );
                opacity: 0;
                transition: opacity 0.4s ease;
            }
            .epg-marquee-container.active {
                opacity: 1;
            }
            /* 跑马灯内容：只负责文字样式，不负责布局占位 */
            .epg-marquee-content {
                display: inline-block;
                white-space: nowrap;
                padding: 8px 0; /* 垂直间距，通过 JS 动态计算也可以 */
                will-change: transform;
                font-weight: 500;
                color: #ffffff;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
                /* 强制重置起点坐标 */
                position: relative;
                left: 0;
            }
            /* 清理辅助类：将 JS 里的内联颜色统一到这里 */
            .epg-text-time { color: rgba(255, 255, 255, 0.6); font-size: 0.9em; }
            .epg-text-ch { color: #ffffff; font-weight: bold; padding: 0 5px; }
            .epg-text-normal { color: #ffffff; font-size: 0.9em; }
            .epg-text-playing { color: #00FF7F; } /* 正在播放：绿色 */
            .epg-text-next { color: #FFD700; }    /* 下一个：金色 */
            .epg-text-later { color: #FFA500; }   /* 稍后：橙色 */
            .epg-text-info { color: #AAAAAA; font-size: 0.9em; }
            /* 新增：字幕翻译样式 */
            .translated-subtitle {
                color: #a0d0ff;
                font-size: 0.92em;
                opacity: 0.92;
                display: block;
                margin-top: 4px;
            }
        `;
        document.head.appendChild(style);
    }
    function createDynamicUI() {
        UI.loudnessBtn = document.createElement("button");
        UI.loudnessBtn.className = "loudness-btn";
        UI.loudnessBtn.innerHTML = "<svg viewBox='0 0 24 24' width='18' height='18' fill='currentColor' style='vertical-align: middle;'><path d='M12 .99C5.92 .99 1 5.92 1 11.99C1 18.07 5.92 22.99 12 22.99C18.07 22.99 23 18.07 23 11.99C23 5.92 18.07 .99 12 .99ZM12 2.99C14.38 2.99 16.67 3.94 18.36 5.63C20.05 7.32 21 9.61 21 11.99C21 14.38 20.05 16.67 18.36 18.36C16.67 20.05 14.38 20.99 12 20.99C9.61 20.99 7.32 20.05 5.63 18.36C3.94 16.67 3 14.38 3 11.99C3 9.61 3.94 7.32 5.63 5.63C7.32 3.94 9.61 2.99 12 2.99ZM14 6.00C13.73 6.00 13.48 6.10 13.29 6.29C13.10 6.48 13 6.73 13 7.00V17.00C13 17.26 13.10 17.52 13.29 17.70C13.48 17.89 13.73 18.00 14 18.00C14.26 18.00 14.51 17.89 14.70 17.70C14.89 17.52 15 17.26 15 17.00V7.00C15 6.73 14.89 6.48 14.70 6.29C14.51 6.10 14.26 6.00 14 6.00ZM10 8.00C9.73 8.00 9.48 8.10 9.29 8.29C9.10 8.48 9 8.73 9 9.00V15.00C9 15.26 9.10 15.52 9.29 15.70C9.48 15.89 9.73 16.00 10 16.00C10.26 16.00 10.51 15.89 10.70 15.70C10.89 15.52 11 15.26 11 15.00V9.00C11 8.73 10.89 8.48 10.70 8.29C10.51 8.10 10.26 8.00 10 8.00ZM18 9.00C17.73 9.00 17.48 9.10 17.29 9.29C17.10 9.48 17 9.73 17 10.00V14.00C17 14.26 17.10 14.52 17.29 14.70C17.48 14.89 17.73 15.00 18 15.00C18.26 15.00 18.51 14.89 18.70 14.70C18.89 14.52 19 14.26 19 14.00V10.00C19 9.73 18.89 9.48 18.70 9.29C18.51 9.10 18.26 9.00 18 9.00ZM6 10.00C5.73 10.00 5.48 10.10 5.29 10.29C5.10 10.48 5 10.73 5 11.00V13.00C5 13.26 5.10 13.52 5.29 13.70C5.48 13.89 5.73 14.00 6 14.00C6.26 14.00 6.51 13.89 6.70 13.70C6.89 13.52 7 13.26 7 13.00V11.00C7 10.73 6.89 10.48 6.70 10.29C6.51 10.10 6.26 10.00 6 10.00Z'/></svg>";
        UI.loudnessBtn.title = "切换响度均衡(L)";
        UI.loudnessBtn.style.cssText = "background:none; border:none; color:#9CA3AF; cursor:pointer; margin-right:5px; display: flex; align-items: center; justify-content: center;";
        UI.volumeBtn.insertAdjacentElement("beforebegin", UI.loudnessBtn);
        setupButtonHoverEffects(UI.loudnessBtn);
        UI.loudnessBtn.onclick = toggleLoudnessEqualizer;
        // 新增：EPG按钮
        UI.epgBtn = document.createElement("button");
        UI.epgBtn.className = "epg-btn";
        UI.epgBtn.innerHTML = "📺";
        UI.epgBtn.title = "节目信息(e)";
        UI.epgBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.volumeContainer.insertAdjacentElement("afterend", UI.epgBtn);
        setupButtonHoverEffects(UI.epgBtn);
        UI.epgBtn.onclick = showEpgMarquee;
        UI.switchSourceBtn = document.createElement("button");
        UI.switchSourceBtn.className = "switch-source-btn";
        UI.switchSourceBtn.innerHTML = "⥮";
        UI.switchSourceBtn.title = "手动换源(s)";
        UI.switchSourceBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px; font-size:16px;";
        UI.epgBtn.insertAdjacentElement("afterend", UI.switchSourceBtn);
        setupButtonHoverEffects(UI.switchSourceBtn);
        // ─── 新增：进阶设置按钮 ───────────────────────────────
        UI.advancedBtn = document.createElement("button");
        UI.advancedBtn.innerHTML = "⚙️";
        UI.advancedBtn.title = "多码率/音轨/字幕";
        UI.advancedBtn.className = "control-btn advanced-btn";
        UI.advancedBtn.disabled = true;
        UI.switchSourceBtn.insertAdjacentElement("afterend", UI.advancedBtn);
        // 进阶设置面板
        UI.advancedPanel = document.createElement("div");
        UI.advancedPanel.className = "advanced-panel";
        UI.advancedPanel.style.display = "none";
        UI.advancedPanel.innerHTML = `
            <div class="section quality-section">
                <div class="section-title">码率</div>
                <div class="options" id="quality-options"></div>
            </div>
            <div class="section audio-section">
                <div class="section-title">音轨</div>
                <div class="options" id="audio-options"></div>
            </div>
            <div class="section subtitle-section">
                <div class="section-title">字幕</div>
                <div class="options" id="subtitle-options"></div>
            </div>
        `;
        UI.videoContainer.appendChild(UI.advancedPanel);
        UI.infoBtn = document.createElement("button");
        UI.infoBtn.className = "info-btn";
        UI.infoBtn.innerHTML = "ⓘ";
        UI.infoBtn.title = "播放信息(i)";
        UI.infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.advancedBtn.insertAdjacentElement("afterend", UI.infoBtn);
        setupButtonHoverEffects(UI.infoBtn);
        UI.infoPanel = document.createElement("div");
        UI.infoPanel.className = "info-panel";
        UI.infoPanel.style.cssText = "display:none; position:absolute; bottom:65px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px; z-index: 20;";
        UI.videoContainer.appendChild(UI.infoPanel);
        // 添加快捷键提示
        const shortcutHint = document.createElement('div');
        shortcutHint.className = 'shortcut-hint';
        shortcutHint.innerHTML = '快捷键说明';
        shortcutHint.style.cssText = 'position:absolute; top:5px; right:10px; background:rgba(0,0,0,0.7); color:#aaa; padding:6px 12px; border-radius:6px; font-size:11px; z-index:10; cursor:help;';
        UI.videoContainer.appendChild(shortcutHint);
        // 鼠标悬停时显示完整快捷键列表
        shortcutHint.addEventListener('mouseenter', () => {
            shortcutHint.innerHTML = `
                <div style="font-weight:bold; margin-bottom:5px; border-bottom:1px solid #444; padding-bottom:3px;">快捷键列表</div>
                <table style="font-size:10px; line-height:1.6;">
                    <tr><td><b>PageUp</b></td><td>搜索频道列表</td></tr>
					<tr><td><b>PageDown</b></td><td>关闭频道列表</td></tr>
                    <tr><td><b>↑↓</b></td><td>在频道列表中导航</td></tr>
					<tr><td><b>Enter</b></td><td>播放选中频道</td></tr>
                    <tr><td><b>空格</b></td><td>播放/暂停</td></tr>
                    <tr><td><b>↑↓</b></td><td>音量调节</td></tr>
                    <tr><td><b>←→</b></td><td>快退/快进5秒</td></tr>
                    <tr><td><b>f</b></td><td>全屏切换</td></tr>
                    <tr><td><b>m</b></td><td>静音切换</td></tr>
                    <tr><td><b>p</b></td><td>频道列表</td></tr>
                    <tr><td><b>[ ]</b></td><td>上/下一个频道</td></tr>
                    <tr><td><b>s</b></td><td>手动换源</td></tr>
                    <tr><td><b>i</b></td><td>信息面板</td></tr>
                    <tr><td><b>e</b></td><td>节目信息</td></tr>
                    <tr><td><b>L</b></td><td>响度均衡</td></tr>
                    <tr><td><b>T</b></td><td>AI字幕翻译</td></tr>
                </table>
                <div style="margin-top:5px; font-size:9px; color:#aaa;">
                    提示：频道列表打开时，上下方向键用于导航
                </div>
            `;
            shortcutHint.style.width = '180px';
            shortcutHint.style.fontSize = '10px';
            shortcutHint.style.padding = '10px';
        });
        shortcutHint.addEventListener('mouseleave', () => {
            shortcutHint.innerHTML = '快捷键说明';
            shortcutHint.style.width = 'auto';
            shortcutHint.style.fontSize = '11px';
            shortcutHint.style.padding = '6px 12px';
        });
        // 给搜索框添加特殊类名以便CSS选择
        UI.playlistSearchInput.classList.add('playlist-search');
    }
    // ==================== 修复的 togglePlaylistUI 函数 ====================
    function togglePlaylistUI(show) {
        if (!state.isM3UPlaylist) {
            showNotification('当前不是频道列表模式', 'warning', 2000);
            return;
        }
        const shouldShow = show !== undefined ? show : !UI.playlistContainer.classList.contains("hidden") === false;
        const currentlyVisible = !UI.playlistContainer.classList.contains("hidden");
        // 如果状态没有变化，直接返回
        if (shouldShow === currentlyVisible) return;
        UI.playlistContainer.classList.toggle("hidden", !shouldShow);
        if (shouldShow) {
            // 打开频道列表时，给频道列表容器添加一个焦点状态
            UI.playlistContainer.setAttribute('tabindex', '-1');
            UI.playlistContainer.classList.add('has-focus');
            // 如果有选中项，使其获得焦点
            setTimeout(() => {
                const selectedItem = UI.playlistItems.querySelector('.selected');
                if (selectedItem) {
                    selectedItem.focus();
                }
            }, 50);
            // 新增: 重新渲染以更新节目信息
            renderPlaylist(UI.playlistSearchInput.value);
			updatePlaylistHighlight("center"); //让正在播放的频道进入视野
        } else {
            // 如果当前焦点在频道列表内，强制让它失焦
            if (document.activeElement && document.activeElement.closest('#playlist-container')) {
                document.activeElement.blur();
            }
            // 如果关闭频道列表，确保移除焦点
            UI.playlistSearchInput.blur();
            UI.playlistSearchInput.style.border = "";
            UI.playlistSearchInput.style.boxShadow = "";
            // 清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }
    }
    function loadVolumeSettings() {
        chrome.storage.local.get(["volume", "loudnessEnabled"], function(result) {
            if (result.volume !== undefined) {
                UI.videoPlayer.volume = result.volume;
                UI.volumeProgress.style.width = result.volume * 100 + "%";
                updateVolumeIcon();
            }
            if (result.loudnessEnabled !== undefined && result.loudnessEnabled) {
                setTimeout(() => {
                    if (result.loudnessEnabled) toggleLoudnessEqualizer(true);
                }, 1000);
            }
        });
    }
    function switchToPrevChannel() {
        if (!state.isM3UPlaylist) {
            showNotification('当前不是频道列表模式', 'warning', 2000);
            return;
        } else if (state.currentPlaylist.length === 0){
            showNotification('空频道列表', 'warning', 2000);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let prevIndex = state.currentPlaylistIndex - 1;
        if (prevIndex < 0) {
            prevIndex = state.currentPlaylist.length - 1;
        }
        console.log(`[频道切换] 切换到上一个频道: ${state.currentPlaylistIndex} → ${prevIndex}`);
        const item = state.currentPlaylist[prevIndex];
        if (item) {
            showNotification(`切换到上一个频道: ${item.title || `频道 ${prevIndex + 1}`}`, 1500);
        }
        playPlaylistItem(prevIndex);
    }
    function switchToNextChannel() {
        if (!state.isM3UPlaylist) {
            showNotification('当前不是频道列表模式', 'warning', 2000);
            return;
        } else if (state.currentPlaylist.length === 0){
            showNotification('空频道列表', 'warning', 2000);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let nextIndex = state.currentPlaylistIndex + 1;
        if (nextIndex >= state.currentPlaylist.length) {
            nextIndex = 0;
        }
        console.log(`[频道切换] 切换到下一个频道: ${state.currentPlaylistIndex} → ${nextIndex}`);
        const item = state.currentPlaylist[nextIndex];
        if (item) {
            showNotification(`切换到下一个频道: ${item.title || `频道 ${nextIndex + 1}`}`, 1500);
        }
        playPlaylistItem(nextIndex);
    }
    function parseInitialUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const queryUrl = urlParams.get("url");
        const hashUrl = window.location.hash.substring(1);
        state.videoUrl = queryUrl || hashUrl;
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
            try {
                const urlObj = new URL(state.videoUrl);
                state.baseUrl = urlObj.href.substring(0, urlObj.href.lastIndexOf("/") + 1);
                state.originalPlaylistUrl = state.videoUrl;
            } catch (e) {
                console.warn("基础URL解析失败:", e);
                state.baseUrl = "";
                state.originalPlaylistUrl = state.videoUrl;
            }
        }
    }
    function clearTimers(keys = []) {
        const targets = keys.length > 0 ? keys : ["load", "stall"];
        targets.forEach(key => {
            if (state.timers[key]) {
                clearTimeout(state.timers[key]);
                state.timers[key] = null;
            }
        });
    }
    function showLoading(show) {
        UI.loading.style.display = show ? "block" : "none";
    }
    function showError(message) {
        showLoading(false);
        UI.errorMessage.textContent = message;
        UI.errorMessage.style.display = "block";
        // 1. 判断是否包含黑名单关键词
        const isBlacklisted = ["黑名单", "拦截", "禁止"].some(key => message.includes(key));
        if (isBlacklisted) {
            // 2. 如果是黑名单错误，添加样式
            UI.errorMessage.classList.add("blacklist-error");
            // 3. 只有黑名单错误才设置定时器自动隐藏（例如 10 秒后）
            setTimeout(() => {
                // 额外的保护：确保在隐藏前，消息依然是黑名单消息（防止期间被其他消息替换）
                if (UI.errorMessage.classList.contains("blacklist-error")) {
                    UI.errorMessage.style.display = "none";
                    UI.errorMessage.classList.remove("blacklist-error");
                }
            }, 10000);
        } else {
            // 4. 普通错误，移除样式且不设置定时器（会一直显示直到手动操作）
            UI.errorMessage.classList.remove("blacklist-error");
        }
    }
    function formatTime(seconds) {
        if (seconds === Infinity || isNaN(seconds)) return "Live";
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    function startVideoLoadProcess() {
        showLoading(true);
        UI.errorMessage.style.display = "none";
        UI.errorMessage.classList.remove("blacklist-error");
        checkAndInitPlayer(state.videoUrl);
    }
    // 新增：从 storage 加载用户设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'epgEnabled',
            'epgUrl',
            'marqueeSpeed',
            'marqueeColor',
            'marqueeFontSize',
            'headerRules'
        ], function(result) {
            // 更新 CONFIG（将用户友好的单位转换为毫秒）
            if (result.loadTimeout !== undefined) {
                CONFIG.LOAD_TIMEOUT_MS = result.loadTimeout;
            }
            if (result.stallTimeout !== undefined) {
                CONFIG.STALL_TIMEOUT_MS = result.stallTimeout;
            }
            if (result.maxRetryRounds !== undefined) {
                CONFIG.MAX_RETRY_ROUNDS = result.maxRetryRounds;
            }
            if (result.searchDebounce !== undefined) {
                CONFIG.SEARCH_DEBOUNCE_MS = result.searchDebounce;
            }
            if (result.playlistRefreshInterval !== undefined) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = result.playlistRefreshInterval;
            }
            if (result.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = result.autoRefreshEnabled;
            }
            if (result.epgEnabled !== undefined) {
                CONFIG.EPG_ENABLED = result.epgEnabled;
            }
            if (result.epgUrl !== undefined) {
                CONFIG.EPG_URL = result.epgUrl;
            }
            if (result.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = result.marqueeSpeed;
            }
            if (result.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = result.marqueeColor;
            }
            if (result.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = result.marqueeFontSize;
            }
            if (result.headerRules !== undefined) {
                CONFIG.RULES = result.headerRules;
            }            
            console.log('[设置] 配置已从 storage 加载');
            console.log('[设置] 加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            console.log('[设置] 卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            console.log('[设置] 最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            console.log('[设置] 列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
            console.log('[设置] 自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
            console.log('[设置] EPG启用:', CONFIG.EPG_ENABLED);
            console.log('[设置] EPG URL:', CONFIG.EPG_URL);
            console.log('[设置] 跑马灯速度:', CONFIG.MARQUEE_SPEED, 's/char');
            console.log('[设置] 跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            console.log('[设置] 跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE, 'px');
            // 如果EPG启用，加载数据
            if (CONFIG.EPG_ENABLED && state.isM3UPlaylist) {
                loadEPG();
            }
        });
    }
    // 新增：监听设置更新消息
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'settingsUpdated') {
            console.log('[设置] 收到设置更新通知');
            // 更新 CONFIG
            if (message.config.loadTimeout) {
                CONFIG.LOAD_TIMEOUT_MS = message.config.loadTimeout;
                console.log('[设置] 更新加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            }
            if (message.config.stallTimeout) {
                CONFIG.STALL_TIMEOUT_MS = message.config.stallTimeout;
                console.log('[设置] 更新卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            }
            if (message.config.maxRetryRounds) {
                CONFIG.MAX_RETRY_ROUNDS = message.config.maxRetryRounds;
                console.log('[设置] 更新最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            }
            if (message.config.searchDebounce) {
                CONFIG.SEARCH_DEBOUNCE_MS = message.config.searchDebounce;
                console.log('[设置] 更新搜索防抖:', CONFIG.SEARCH_DEBOUNCE_MS, 'ms');
            }
            if (message.config.playlistRefreshInterval) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = message.config.playlistRefreshInterval;
                console.log('[设置] 更新列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
                // 如果正在播放M3U列表，重启刷新定时器
                if (state.isM3UPlaylist && CONFIG.AUTO_REFRESH_ENABLED) {
                    if (state.timers.refreshPlaylist) {
                        clearTimeout(state.timers.refreshPlaylist);
                    }
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = message.config.autoRefreshEnabled;
                console.log('[设置] 更新自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
                if (!CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    clearTimeout(state.timers.refreshPlaylist);
                    state.timers.refreshPlaylist = null;
                } else if (CONFIG.AUTO_REFRESH_ENABLED && state.isM3UPlaylist) {
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.blacklist) {
                state.blacklist = message.config.blacklist;
                state.isBlacklistLoaded = true;
                console.log(`[设置] 黑名单已更新，${state.blacklist.length} 个关键词`);
            }
            if (message.config.headerRules) {
                CONFIG.RULES = message.config.headerRules;
                console.log(`[设置] headerRules已更新，${CONFIG.RULES.length} 条规则`);
            }            
            // 在 chrome.runtime.onMessage 监听器中，修改 EPG 相关部分为：
            if (message.config.epgEnabled !== undefined) {
                const oldEnabled = CONFIG.EPG_ENABLED;
                CONFIG.EPG_ENABLED = message.config.epgEnabled;
                console.log('[设置] 更新EPG启用:', CONFIG.EPG_ENABLED);
                if (CONFIG.EPG_ENABLED !== oldEnabled) {  // 只在启用状态真正变化时才操作
                    if (CONFIG.EPG_ENABLED && state.isM3UPlaylist) {
                        loadEPG();  // 启用时才加载
                    } else {
                        state.epgData = {};
                        state.channelMap = {};
                        state.epgExpiryTime = 0;
                        if (state.timers.epgRefresh) {
                            clearTimeout(state.timers.epgRefresh);
                            state.timers.epgRefresh = null;
                        }
                    }
                }
            }
            if (message.config.epgUrl) {
                const oldUrl = CONFIG.EPG_URL;
                CONFIG.EPG_URL = message.config.epgUrl;
                console.log('[设置] 更新EPG URL:', CONFIG.EPG_URL);
                // URL 改变且 EPG 已启用时，才重新加载
                if (CONFIG.EPG_ENABLED && oldUrl !== CONFIG.EPG_URL && state.isM3UPlaylist) {
                    loadEPG();
                }
            }
            if (message.config.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = message.config.marqueeSpeed;
                console.log('[设置] 更新跑马灯速度:', CONFIG.MARQUEE_SPEED, 'px/s');
            }
            if (message.config.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = message.config.marqueeColor;
                console.log('[设置] 更新跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            }
            if (message.config.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = message.config.marqueeFontSize;
                console.log('[设置] 更新跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE, 'px');
            }
            // 更新信息面板
            updateInfoPanel();
            showNotification('设置已更新', 'success',2000);
        }
    });
    // 修改后的 loadBlacklist 函数：优先从 storage，没有则从文件
    function loadBlacklist() {
        state.blacklist = [];
        state.isBlacklistLoaded = false;
        console.log('[黑名单] 开始加载黑名单...');
        // 1. 首先尝试从 storage 加载（用户自定义的）
        chrome.storage.local.get(['blacklist', 'blacklistContent'], function(result) {
            if (result.blacklist && Array.isArray(result.blacklist) && result.blacklist.length > 0) {
                // 从 storage 的数组加载成功
                state.blacklist = result.blacklist;
                console.log(`[黑名单] 从 storage 加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else if (result.blacklistContent) {
                // 从 storage 的字符串内容加载
                state.blacklist = result.blacklistContent.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                console.log(`[黑名单] 从 storage 内容加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else {
                // 2. storage 中没有，则从文件加载
                console.log('[黑名单] storage 中无黑名单，尝试从文件加载');
                fetch(CONFIG.BLACKLIST_URL)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return response.text();
                    })
                    .then(text => {
                        state.blacklist = text.split('\n')
                            .map(line => line.trim())
                            .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                            .filter(keyword => keyword.length > 0);
                        console.log(`[黑名单] 从文件加载 ${state.blacklist.length} 个关键词`);
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    })
                    .catch(error => {
                        console.warn('[黑名单] 文件加载失败，使用空黑名单:', error);
                        state.blacklist = [];
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    });
            }
        });
    }
    // 新增：为所有控制按钮添加统一的鼠标效果
    function addButtonHoverEffects() {
        const staticButtons = [
            UI.backBtn,
            UI.playPauseBtn,
            UI.prevChannelBtn,
            UI.nextChannelBtn,
            UI.volumeBtn,
            UI.fullscreenBtn,
            UI.playlistBtn,
            UI.closePlaylistBtn,
            UI.clearSearchBtn,
            UI.epgBtn // 新增
        ];
        staticButtons.forEach(button => {
            if (!button) return;
            setupButtonHoverEffects(button);
        });
    }
    function setupButtonHoverEffects(button) {
        if (!button) return;
        button.style.opacity = '1';
        button.style.transition = 'opacity 0.2s ease';
        button.addEventListener('mouseenter', () => {
            button.style.opacity = '0.8';
        });
        button.addEventListener('mouseleave', () => {
            button.style.opacity = '1';
        });
        button.addEventListener('mousedown', () => {
            button.style.opacity = '0.6';
        });
        button.addEventListener('mouseup', () => {
            button.style.opacity = '0.8';
        });
    }
    function checkUrlInBlacklist(url, urlType = "URL") {
        if (!url || typeof url !== 'string') {
            return false;
        }
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[黑名单] 等待黑名单加载完成...`);
            setTimeout(() => {
                checkUrlInBlacklist(url, urlType);
            }, 100);
            return false;
        }
        const lowerUrl = url.toLowerCase();
        for (const keyword of state.blacklist) {
            if (!keyword) continue;
            const lowerKeyword = keyword.toLowerCase();
            // 支持简单的通配符匹配
            if (lowerKeyword.includes('*')) {
                // 将通配符转换为正则表达式
                const pattern = lowerKeyword
                    .replace(/\./g, '\\.')
                    .replace(/\*/g, '.*');
                const regex = new RegExp(`^${pattern}$`);
                if (regex.test(lowerUrl)) {
                    console.warn(`[黑名单拦截] ${urlType} 匹配通配符模式: "${keyword}"`);
                    console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                    showError(
                        `播放被拦截：链接匹配黑名单规则\n\n` +
                        `规则: ${keyword}\n` +
                        `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                    );
                    handleBlacklistedInPlaylist(url, keyword);
                    return true;
                }
            } else if (lowerUrl.includes(lowerKeyword)) {
                console.warn(`[黑名单拦截] ${urlType} 包含黑名单关键词: "${keyword}"`);
                console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                showError(
                    `播放被拦截：链接包含黑名单关键词\n\n` +
                    `关键词: ${keyword}\n` +
                    `URL: ${url.substring(0, 80)}${url.length > 80 ? '...' : ''}`
                );
                handleBlacklistedInPlaylist(url, keyword);
                return true;
            }
        }
        return false;
    }
    // 新增：处理频道列表中被黑名单拦截的项目
    function handleBlacklistedInPlaylist(blockedUrl, keyword) {
        if (!state.isM3UPlaylist || state.currentPlaylistIndex === -1) {
            return;
        }
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item) return;
        // 从当前频道的URL列表中移除被拦截的URL
        if (item.urls && item.urls.length > 0) {
            const originalLength = item.urls.length;
            item.urls = item.urls.filter(url => url !== blockedUrl);
            if (item.urls.length < originalLength) {
                console.warn(`[黑名单] 从频道 "${item.title}" 中移除 ${originalLength - item.urls.length} 个被拦截的源`);
                // 更新当前频道信息
                if (state.currentChannelInfo.urls) {
                    state.currentChannelInfo.urls = state.currentChannelInfo.urls.filter(url => url !== blockedUrl);
                }
                // 如果当前正在播放被拦截的源，切换到下一个源
                if (item.currentUrlIndex !== undefined &&
                    item.urls.length > 0 &&
                    item.currentUrlIndex >= item.urls.length) {
                    item.currentUrlIndex = 0;
                    showNotification(`源被黑名单拦截，自动切换`, 2000);
                    // 自动播放下一个源
                    const nextUrl = item.urls[0];
                    setTimeout(() => {
                        if (checkUrlInBlacklist(nextUrl, "下一个源")) {
                            return;
                        }
                        destroyPlayer();
                        showLoading(true);
                        UI.errorMessage.style.display = "none";
                        UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                        checkAndInitPlayer(nextUrl);
                    }, 1500);
                }
            }
            // 如果频道所有源都被拦截，跳过这个频道
            if (item.urls.length === 0) {
                console.warn(`[黑名单] 频道 "${item.title}" 所有源均被拦截，将跳过`);
                showNotification(`频道 "${item.title}" 已被屏蔽`, 3000);
                // 自动播放下一个频道
                setTimeout(() => {
                    let nextIndex = state.currentPlaylistIndex + 1;
                    while (nextIndex < state.currentPlaylist.length) {
                        const nextItem = state.currentPlaylist[nextIndex];
                        if (nextItem && nextItem.urls && nextItem.urls.length > 0) {
                            // 检查下一个频道的第一个URL是否在黑名单中
                            const firstUrl = nextItem.urls[0];
                            if (!checkUrlInBlacklist(firstUrl, "下一个频道URL")) {
                                playPlaylistItem(nextIndex);
                                return;
                            }
                        }
                        nextIndex++;
                    }
                    // 所有频道都被屏蔽
                    showError("所有频道均被黑名单拦截，无法播放");
                }, 1500);
            }
        }
    }
    function checkAndInitPlayer(url) {
        const thisRequestId = ++state.loadRequestId;
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[Req #${thisRequestId}] 等待黑名单加载...`);
            setTimeout(() => {
                if (thisRequestId === state.loadRequestId) {
                    checkAndInitPlayer(url);
                }
            }, 100);
            return;
        }
        // 检查URL是否在黑名单中（包括原始URL）
        if (checkUrlInBlacklist(url, "原始URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        if (/(?:#m3u8|#m3u|#ts|#flv)$/i.test(lowerUrl)) {    
            if (thisRequestId === state.loadRequestId) {
                initPlayerWithUrl(url);
            }
        } else {
            console.log(`[Req #${thisRequestId}] 检测重定向及 Content-Type:`, url);
            new Promise(resolve => {
                chrome.runtime.sendMessage({
                    action: "checkRedirect",
                    url: url
                }, response => resolve(response));
            }).then(response => {
                if (thisRequestId !== state.loadRequestId) {
                    console.warn(`[Req #${thisRequestId}] 请求已过期 (当前ID: ${state.loadRequestId})，丢弃结果。`);
                    return;
                }
                if (response && response.success) {
                    console.log(`[Req #${thisRequestId}] 重定向成功: ${response.finalUrl}`);
                    // 检查重定向后的URL是否在黑名单中
                    if (checkUrlInBlacklist(response.finalUrl, "重定向URL")) {
                        return;
                    }
                    initPlayerWithUrl(response.finalUrl, response.contentType || "");
                } else {
                    console.warn(`[Req #${thisRequestId}] 重定向检测无响应或失败，尝试直连`);
                    initPlayerWithUrl(url);
                }
            });
        }
    }
    function destroyPlayer() {
        if (UI.subDisplay) UI.subDisplay.innerHTML = ''; // 清空字幕
        if (state.player) {
            if (typeof state.player.destroy === "function") {
                state.player.destroy();
            } else if (state.player instanceof Hls) {
                state.player.destroy();
            }
            state.player = null;
        }
        UI.videoPlayer.removeAttribute("src");
        UI.videoPlayer.load();
        state.isPlaying = false;
        clearTimers();
        // 进阶面板重置
        if (UI.advancedBtn) UI.advancedBtn.disabled = true;
        if (UI.advancedPanel) UI.advancedPanel.style.display = 'none';
        state.streamInfo = {
            resolution: "未知",
            type: "未知",
            codec: "未知",
            bitrate: "未知",
            bandwidthEstimate: 0
        };
    }
    function initPlayerWithUrl(url, contentType = "") {
        // 再次检查URL（以防万一）
        if (checkUrlInBlacklist(url, "播放URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        const ct = contentType.toLowerCase();
        const isHlsContent = ct.includes("mpegurl") || ct.includes("hls") || ct.includes("text/html") || ct.includes("text/plain") || ct.includes("application/octet-stream");
        const isTsContent = ct.includes("mp2t");
        if (/(?:\.m3u([?#].*)?|#m3u)$/i.test(lowerUrl)) {
            initM3UPlaylist(url);
        } else if (/(?:\.m3u8([?#].*)?|#m3u8)$/i.test(lowerUrl)) {
            initHlsPlayer(url);
        } else if (isTsContent || /(?:\.(?:flv|ts)([?#].*)?|#(?:flv|ts))$/i.test(lowerUrl)) {
            const mCT = isTsContent ? "TS" : "";
            initMpegtsPlayer(url,mCT);
        } else if (isHlsContent) {
            initHlsPlayer(url);
        } else {
            initNativePlayer(url);
        }
    }
    /**
     * 使用 mpegts.js 初始化播放器
     * @param {string} url - 媒体流地址
     * @param {string} [mCT=""] - 内容类型提示，"TS" 表示 TS裸流，其他值（包括空字符串）视为 FLV
     */
    function initMpegtsPlayer(url, mCT = "") {
        const lowerUrl = url.toLowerCase();
        if (!mpegts.isSupported() || !mpegts.getFeatureList().mseLivePlayback) {
            return handleError("您的浏览器不支持 MPEG-TS/FLV 播放（需要 MSE 支持）");
        }
        destroyPlayer();
        const isTsStream = mCT === "TS" || mCT.toUpperCase() === "TS" || /(?:\.ts([?#].*)?|#ts)$/i.test(lowerUrl);
        const mediaType = isTsStream ? "mpegts" : "flv";
        state.streamInfo.type = isTsStream ? "TS" : "FLV";
        const player = mpegts.createPlayer({
            type: mediaType,
            url: url,
            isLive: true,
        }, {
            enableWorker: true,
            fixAudioTimestampGap: true,
        });
        player.attachMediaElement(UI.videoPlayer);
        player.load();
        player.on(mpegts.Events.MEDIA_INFO, (info) => {
            clearTimers(["load"]);
            if (info.width && info.height) {
                state.streamInfo.resolution = `${info.width}x${info.height}`;
            }
            if (info.videoCodec) {
                state.streamInfo.codec = formatCodecName(info.videoCodec);
            }
            updateInfoPanel();
        });
        player.on(mpegts.Events.ERROR, (errType, errDetail) => {
            console.error("mpegts Error:", errType, errDetail);
            handleError(`播放错误: ${errType} - ${errDetail}`);
        });
        state.player = player;
        attachCommonVideoEvents();
    }
    function initHlsPlayer(url) {
        if (Hls.isSupported()) {
            destroyPlayer();
            state.streamInfo.type = "HLS";
            const player = new Hls({
                debug: false,
                capLevelToPlayerSize: true,
                autoLevelEnabled: true,
                fragLoadingMaxRetry: 1,
                fragLoadingRetryDelay: 500,
                xhrSetup: function (xhr, url) {
                    if (url.includes('.key') || url.includes('keyfile')) {
                        xhr.withCredentials = true;
                    }
                }
            });
            player.loadSource(url);
            player.attachMedia(UI.videoPlayer);
            // 使用支持翻译的新版 bindSubtitleEvents
            player.on(Hls.Events.SUBTITLE_TRACK_SWITCHED, () => {
                console.log("[AI Subtitle] 检测到字幕轨道切换，重置源语言检测状态");
                globalDetectedLang = null;
                detectionCount = 0;
                // 可选：清空翻译器缓存（如果不同轨道语言差异很大）
                translatorCache.clear();  // 如果想彻底清空缓存，取消注释这行
                bindSubtitleEvents();
                updateAdvancedPanel(player);
            });
            player.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, () => {
                console.log("[AI Subtitle] 字幕轨道列表更新，重置检测状态");
                globalDetectedLang = null;
                detectionCount = 0;
                bindSubtitleEvents();
                updateAdvancedPanel(player);
            });
            // 最可靠：浏览器原生 textTracks change 事件
            UI.videoPlayer.textTracks.addEventListener('change', () => {
                console.log("[AI Subtitle] 原生 textTracks 'change' 事件触发");
                let activeTrack = null;
                for (let track of UI.videoPlayer.textTracks) {
                    if (track.mode === 'showing' && track.kind === 'subtitles') {
                        activeTrack = track;
                        break;
                    }
                }
                if (activeTrack) {
                    console.log("[AI Subtitle] 检测到新字幕轨道启用，重置源语言检测状态");
                    globalDetectedLang = null;
                    detectionCount = 0;
                    translatorCache.clear();  // 彻底清空缓存
                }
            });
            player.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                clearTimers(["load"]);
                console.log("HLS Manifest Parsed");
                showLoading(false);
                updateAdvancedPanel(player);
                updateResolutionFromHls(player);
                attemptPlay();
            });
            player.on(Hls.Events.LEVEL_SWITCHED, (event, data) => { 
                updateAdvancedPanel(player); 
                updateResolutionFromHls(player);
                console.log("换码率后分辨率:", state.streamInfo.resolution);
            });
            player.on(Hls.Events.AUDIO_TRACK_SWITCHED, () => {
                updateAdvancedPanel(player);
                updateResolutionFromHls(player);
            });
            player.on(Hls.Events.SUBTITLE_TRACK_SWITCHED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.AUDIO_TRACKS_UPDATED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.BUFFER_CODECS, (event, data) => {
                console.log("[BUFFER_CODECS] 触发了！", data);
                let videoCodec = null;
                if (data?.video?.codec) {
                    videoCodec = data.video.codec;
                } else if (data?.tracks?.video?.codec) {
                    videoCodec = data.tracks.video.codec;
                }
                if (videoCodec) {
                    console.log("[BUFFER_CODECS] 成功获取视频编码:", videoCodec);
                    state.streamInfo.codec = formatCodecName(videoCodec);
                    updateInfoPanel();
                }
            });
            player.on(Hls.Events.FRAG_LOADED, () => {
                if (player.bandwidthEstimate > 0) {
                    state.streamInfo.bandwidthEstimate = player.bandwidthEstimate;
                    updateBitrateDisplay(player);
                    updateInfoPanel();
                }
            });
            player.on(Hls.Events.ERROR, (event, data) => {
                if (data.fatal) {
                    console.error("HLS Fatal Error:", data.type, data.details);
                    handleError(`HLS播放错误: ${data.details}`);
                }
            });
            state.player = player;
            attachCommonVideoEvents();
        } else if (UI.videoPlayer.canPlayType("application/vnd.apple.mpegurl")) {
            destroyPlayer();
            UI.videoPlayer.src = url;
            attachCommonVideoEvents();
        } else {
            handleError("您的浏览器不支持HLS播放");
        }
    }
    /**
     * 简单通配符匹配：支持 * （转换为 .* 正则）
     * @param {string} url      - 当前请求的完整 URL
     * @param {string} pattern  - 如 '*.abc.com' 或 'https://cdn.*.com/path/*'
     * @returns {boolean}
     */
    function matchesPattern(url, pattern) {
        const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
        const regex = new RegExp(`^${escaped}$`, 'i');
        return regex.test(url);
    }
    // ────────────────────────────────────────────────
    //  更新进阶设置面板（核心功能）
    // ────────────────────────────────────────────────
    function updateAdvancedPanel(hls) {
        if (!hls) return;
        const hasQuality   = hls.levels?.length > 1;
        const hasAudio     = hls.audioTracks?.length > 1;
        const hasSubtitle  = hls.subtitleTracks?.length > 0;
        UI.advancedBtn.disabled = !(hasQuality || hasAudio || hasSubtitle);
        // 码率
        const qContainer = document.getElementById('quality-options');
        qContainer.innerHTML = '';
        if (hasQuality) {
            hls.levels.forEach((level, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = levelToText(level);
                if (idx === hls.currentLevel) item.classList.add('active');
                item.onclick = () => {
                    hls.currentLevel = idx;
                    hls.autoLevelEnabled = false;
                    updateAdvancedPanel(hls);
                    showNotification(`码率：${levelToText(level)}`, 1500);
                };
                qContainer.appendChild(item);
            });
        } else {
            qContainer.innerHTML = '<div class="option-item disabled">无多码率选项</div>';
        }
        // 音轨
        const aContainer = document.getElementById('audio-options');
        aContainer.innerHTML = '';
        if (hasAudio) {
            hls.audioTracks.forEach((track, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = track.name || track.lang || `音轨 ${idx+1}`;
                if (hls.audioTrack === idx) item.classList.add('active');
                item.onclick = () => {
                    hls.audioTrack = idx;
                    updateAdvancedPanel(hls);
                    showNotification(`音轨：${track.name || track.lang || '未知'}`, 1500);
                };
                aContainer.appendChild(item);
            });
        } else {
            aContainer.innerHTML = '<div class="option-item disabled">无多音轨</div>';
        }
        // 字幕
        const sContainer = document.getElementById('subtitle-options');
        sContainer.innerHTML = '';
        const offItem = document.createElement('div');
        offItem.className = 'option-item' + (hls.subtitleTrack < 0 ? ' active' : '');
        offItem.textContent = '关闭字幕';
        offItem.onclick = () => {
            hls.subtitleTrack = -1;
            UI.subDisplay.innerHTML = '';
            updateAdvancedPanel(hls);
        };
        sContainer.appendChild(offItem);
        if (hasSubtitle) {
            hls.subtitleTracks.forEach((track, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = track.name || track.lang || `字幕 ${idx+1}`;
                if (hls.subtitleTrack === idx) item.classList.add('active');
                item.onclick = () => {
                    hls.subtitleTrack = idx;
                    updateAdvancedPanel(hls);
                    showNotification(`字幕：${track.name || track.lang || '未知'}`, 1500);
                };
                sContainer.appendChild(item);
            });
        }
    }
    function levelToText(level) {
        if (!level) return '未知';
        if (level.height) {
            let txt = level.height + 'p';
            if (level.bitrate) txt += ` (${formatBitrate(level.bitrate)})`;
            return txt;
        }
        if (level.bitrate) return formatBitrate(level.bitrate);
        return 'Level ' + (level.idx ?? '?');
    }
    // 格式化 codec 显示，更友好
    function formatCodecName(codec) {
        if (!codec) return "未知";
        if (codec.includes("avc1")) return "H.264";
        if (codec.includes("hvc1") || codec.includes("hev1")) return "H.265/HEVC";
        if (codec.includes("av01")) return "AV1";
        if (codec.includes("vp9")) return "VP9";
        if (codec.includes("mp4a")) return "AAC"; // 音频
        return codec.split('.')[0].toUpperCase(); // fallback
    }
    // 专门更新码率显示（避免重复逻辑）
    function updateBitrateDisplay(hls) {
        if (!hls) return;
        const currentLevel = hls.levels[hls.currentLevel];
        if (currentLevel?.bitrate > 0) {
            state.streamInfo.bitrate = formatBitrate(currentLevel.bitrate);
        } else if (hls.bandwidthEstimate > 10000) { // 避免太小不显示
            state.streamInfo.bitrate = formatBitrate(hls.bandwidthEstimate) + " (网速)";
        }
    }
    // 友好显示码率（kbps / Mbps）
    function formatBitrate(bitsPerSecond) {
        if (!bitsPerSecond || isNaN(bitsPerSecond)) return "未知";
        if (bitsPerSecond >= 1000000) {
            return (bitsPerSecond / 1000000).toFixed(1) + " Mbps";
        }
        return Math.round(bitsPerSecond / 1000) + " kbps";
    }
    function initNativePlayer(url) {
        destroyPlayer();
        state.streamInfo.type = "原生";
        const lower = url.toLowerCase();
        if (lower.includes(".mp4")) state.streamInfo.type = "MP4";
        else if (lower.includes(".webm")) state.streamInfo.type = "WebM";
        else if (lower.includes(".ogg") || lower.includes(".ogv")) state.streamInfo.type = "OGG";
        UI.videoPlayer.src = url;
        attachCommonVideoEvents();
    }
    function attachCommonVideoEvents() {
        UI.videoPlayer.onloadedmetadata = function() {
            clearTimers(["load"]);
            showLoading(false);
            updateVideoInfoFromElement();
            attemptPlay();
        };
        UI.videoPlayer.onloadeddata = function() {
            updateVideoInfoFromElement();
        };
        UI.videoPlayer.onerror = function() {
            if (!UI.videoPlayer.getAttribute("src") && !UI.videoPlayer.currentSrc) return;
            handleError("视频加载失败或格式不支持");
        };
        UI.videoPlayer.onplay = () => {
            state.isPlaying = true;
            UI.playPauseBtn.textContent = "❚❚";
            UI.playPauseBtn.title = "暂停(空格键)";
        };
        UI.videoPlayer.onpause = () => {
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放(空格键)";
        };
        UI.videoPlayer.ontimeupdate = updateProgress;
        UI.videoPlayer.onvolumechange = updateVolumeIcon;
        UI.videoPlayer.onended = () => {
            if (state.isM3UPlaylist) {
                const item = state.currentPlaylist[state.currentPlaylistIndex];
                if (item && item.urls && item.currentUrlIndex < item.urls.length - 1) {
                    item.currentUrlIndex++;
                    console.log(`当前源播放结束，切换至本频道下一个源: ${item.currentUrlIndex + 1}/${item.urls.length}`);
                    showNotification(`播放结束，切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
                    const nextUrl = item.urls[item.currentUrlIndex];
                    destroyPlayer();
                    showLoading(true);
                    UI.errorMessage.style.display = "none";
                    UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                    checkAndInitPlayer(nextUrl);
                    if (state.timers.load) clearTimeout(state.timers.load);
                    state.timers.load = setTimeout(() => {
                        console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
                        tryNextRedundantUrl();
                    }, CONFIG.LOAD_TIMEOUT_MS);
                    return;
                }
                if (state.currentPlaylistIndex < state.currentPlaylist.length - 1) {
                    playPlaylistItem(state.currentPlaylistIndex + 1);
                }
            }
        };
        UI.videoPlayer.onwaiting = () => {
            if (state.isM3UPlaylist && state.isPlaying) {
                console.warn(`卡顿检测: 启动超时计时器 (${CONFIG.STALL_TIMEOUT_MS}ms)`);
                if (state.timers.stall) clearTimeout(state.timers.stall);
                state.timers.stall = setTimeout(() => {
                    console.error("播放停滞超时，尝试切换线路。");
                    tryNextRedundantUrl();
                }, CONFIG.STALL_TIMEOUT_MS);
            }
        };
        UI.videoPlayer.onplaying = () => {
            if (state.timers.stall) {
                clearTimeout(state.timers.stall);
                state.timers.stall = null;
            }
        };
    }
    function handleError(msg) {
        if (state.isM3UPlaylist) {
            console.warn(`捕获错误: ${msg} -> 尝试下一个源`);
            tryNextRedundantUrl();
        } else {
            showError(msg);
        }
    }
    let isFirstPlay = true;
    function attemptPlay() {
        const promise = UI.videoPlayer.play();
        if (promise !== undefined) {
            promise.then(() => {
                state.isPlaying = true;
                UI.playPauseBtn.textContent = "❚❚";
                UI.playPauseBtn.title = "暂停(空格键)";
                if (isFirstPlay && !document.fullscreenElement) {
                    isFirstPlay = false;
                }
            }).catch(error => {
                console.error("自动播放被阻止或失败:", error);
                state.isPlaying = false;
                UI.playPauseBtn.textContent = "▶";
                UI.playPauseBtn.title = "播放(空格键)";
            });
        }
    }
    function initM3UPlaylist(url) {
        state.isM3UPlaylist = true;
        state.streamInfo.type = "M3U";
        const parser = new M3UParser;
        parser.parseFromUrl(url).then(playlist => {
            if (!playlist || playlist.length === 0) {
                throw new Error("频道列表为空");
            }
            const processedPlaylist = playlist.map(item => {
                if (!item.tvgId && item.attributes) {
                    item.tvgId = item.attributes['tvg-id'];
                }
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                throw new Error("解析后无有效项目");
            }
            if (state.currentPlaylist.length === 0) {
                state.currentPlaylist = processedPlaylist;
                renderPlaylist();
                playPlaylistItem(0);
                togglePlaylistUI(true);
                if (CONFIG.AUTO_REFRESH_ENABLED) {
                    startPlaylistRefreshTimer();
                }
            } else {
                refreshPlaylist(processedPlaylist);
            }
        }).catch(err => {
            console.error("M3U解析失败:", err);
            showError("解析频道列表失败: " + err.message);
        });
        if (CONFIG.EPG_ENABLED) {
            loadEPG();
        }
    }
    function startPlaylistRefreshTimer() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            state.timers.refreshPlaylist = null;
        }
        if (!CONFIG.AUTO_REFRESH_ENABLED) {
            console.log('[定时刷新] 自动刷新已禁用');
            return;
        }
        if (CONFIG.PLAYLIST_REFRESH_INTERVAL <= 0) {
            console.log('[定时刷新] 刷新间隔为0，不启用定时刷新');
            return;
        }
        state.timers.refreshPlaylist = setTimeout(() => {
            console.log(`[定时刷新] 开始刷新频道列表...`);
            refreshM3UPlaylist();
        }, CONFIG.PLAYLIST_REFRESH_INTERVAL);
        console.log(`[定时刷新] 已设置定时器，${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/1000)}秒后刷新`);
    }
    function refreshM3UPlaylist() {
        if (!state.isM3UPlaylist || !state.originalPlaylistUrl) {
            console.warn("[定时刷新] 当前不是M3U频道列表或缺少原始URL");
            startPlaylistRefreshTimer();
            return;
        }
        console.log(`[定时刷新] 刷新频道列表: ${state.originalPlaylistUrl}`);
        const parser = new M3UParser;
        parser.parseFromUrl(state.originalPlaylistUrl).then(playlist => {
            if (!playlist || playlist.length === 0) {
                console.warn("[定时刷新] 刷新的频道列表为空");
                startPlaylistRefreshTimer();
                return;
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                console.warn("[定时刷新] 解析后无有效项目");
                startPlaylistRefreshTimer();
                return;
            }
            refreshPlaylist(processedPlaylist);
            startPlaylistRefreshTimer();
        }).catch(err => {
            console.error("[定时刷新] M3U解析失败:", err);
            startPlaylistRefreshTimer();
        });
    }
    function refreshPlaylist(newPlaylist) {
        console.log('[定时刷新] 开始刷新频道列表...');
        const oldIndex = state.currentPlaylistIndex;
        const oldItem = oldIndex >= 0 ? state.currentPlaylist[oldIndex] : null;
        if (oldItem) {
            state.currentChannelInfo = {
                title: oldItem.title || "",
                originalIndex: oldIndex,
                urls: [...oldItem.urls],
                currentUrlIndex: oldItem.currentUrlIndex || 0,
                currentRound: oldItem.currentRound || 1
            };
            console.log(`[定时刷新] 保存当前频道: "${state.currentChannelInfo.title}"`);
        }
        const oldPlaylist = [...state.currentPlaylist];
        state.currentPlaylist = newPlaylist;
        let newIndex = -1;
        if (state.currentChannelInfo.title) {
            newIndex = state.currentPlaylist.findIndex(item =>
                item.title === state.currentChannelInfo.title
            );
            if (newIndex === -1 && state.currentChannelInfo.urls.length > 0) {
                newIndex = state.currentPlaylist.findIndex(item =>
                    item.urls && item.urls.some(url =>
                        state.currentChannelInfo.urls.includes(url)
                    )
                );
            }
        }
        if (newIndex === -1) {
            console.log(`[定时刷新] 当前频道在新列表中不存在，继续播放原频道`);
            if (oldItem) {
                const preservedItem = {
                    ...oldItem,
                    title: oldItem.title ? `${oldItem.title} (旧列表)` : "旧列表频道"
                };
                state.currentPlaylist.push(preservedItem);
                newIndex = state.currentPlaylist.length - 1;
                state.currentPlaylistIndex = newIndex;
            }
        } else {
            console.log(`[定时刷新] 在新列表中找到当前频道，位置: ${newIndex}`);
            state.currentPlaylistIndex = newIndex;
            const newItem = state.currentPlaylist[newIndex];
            if (newItem.urls && newItem.urls.length > 0) {
                newItem.currentUrlIndex = oldItem ? oldItem.currentUrlIndex || 0 : 0;
                newItem.currentRound = oldItem ? oldItem.currentRound || 1 : 1;
            }
        }
        renderPlaylist(UI.playlistSearchInput.value);
        updatePlaylistHighlight("center");
        if (!UI.playlistContainer.classList.contains("hidden")) {
            const currentSearch = UI.playlistSearchInput.value;
            if (currentSearch) {
                renderPlaylist(currentSearch);
            }
            addRefreshIndicator();
        }
        showNotification(`频道列表已刷新: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`,'success', 3000);
        console.log(`[定时刷新] 频道列表刷新完成: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
    }
    function addRefreshIndicator() {
        const oldIndicator = UI.playlistContainer.querySelector('.refresh-indicator');
        if (oldIndicator) {
            oldIndicator.remove();
        }
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator';
        indicator.textContent = '刷新中...';
        indicator.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 100, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 1002;
        `;
        UI.playlistContainer.appendChild(indicator);
        setTimeout(() => {
            if (indicator.parentNode) {
                indicator.parentNode.removeChild(indicator);
            }
        }, 1500);
    }
    function manualSwitchToNextSource() {
        if (!state.isM3UPlaylist) {
            showNotification('当前不是频道列表模式', 'warning', 2000);
            return;
        }    
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("当前频道没有可用的源");
            return;
        }
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        if (item.currentRound === undefined) item.currentRound = 1;
        const nextIndex = (item.currentUrlIndex + 1) % item.urls.length;
        if (nextIndex === 0) {
            if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
                item.currentRound++;
            }
        }
        console.log(`[手动换源] 从源 ${item.currentUrlIndex + 1} 切换到源 ${nextIndex + 1} (轮次: ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS})`);
        item.currentUrlIndex = nextIndex;
        const nextUrl = item.urls[nextIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "手动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => manualSwitchToNextSource(), 500);
            return;
        }
        showLoading(true);
        UI.errorMessage.style.display = "none";
        showNotification(`切换到源 ${nextIndex + 1}/${item.urls.length}`, 2000);
        destroyPlayer();
        checkAndInitPlayer(nextUrl);
        if (state.timers.load) clearTimeout(state.timers.load);
        state.timers.load = setTimeout(() => {
            console.error(`[手动换源] 加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，触发自动换源逻辑。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
        setTimeout(updateInfoPanel, 500);
    }
    /**
     * 通知组件
     * 优点：无需外部 CSS，逻辑完全闭环，动画与销毁精准同步
     */
    function showNotification(message, type = 'info', duration = 2000) {
        const typeStyles = {
            'info': 'rgba(0, 100, 200, 0.9)',
            'success': 'rgba(40, 167, 69, 0.9)',
            'warning': 'rgba(255, 152, 0, 0.9)'
        };
        const backgroundColor = typeStyles[type] || typeStyles['info'];
        let notification = playerContainer.querySelector('.source-notification');
        // 1. 获取或创建元素
        if (!notification) {
            notification = document.createElement("div");
            notification.className = "source-notification";
            Object.assign(notification.style, {
                position: 'absolute',
                top: '20px',
                left: '50%',
                transform: 'translateX(-50%)',
                color: 'white',
                padding: '10px 15px',
                borderRadius: '5px',
                zIndex: '1000',
                fontSize: '14px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                pointerEvents: 'none',
                //whiteSpace: 'nowrap' // 防止内容换行抖动
                whiteSpace: 'pre'
            });
            playerContainer.appendChild(notification);
        }
        // 2. 更新属性
        notification.textContent = message;
        notification.style.background = backgroundColor;
        // 3. 核心：WAAPI 动画控制
        // 如果已有动画正在运行（包括淡出），立即取消它
        if (notification.currentAnim) {
            notification.currentAnim.cancel();
        }
        // 定义关键帧：入场(0-10%) -> 停留(10-90%) -> 离场(90-100%)
        const animation = notification.animate([
            { opacity: 0, transform: 'translateX(-50%) translateY(-20px)' }, // 起点：上方隐身
            { opacity: 1, transform: 'translateX(-50%) translateY(0)', offset: 0.1 }, // 10% 时间点入场完成
            { opacity: 1, transform: 'translateX(-50%) translateY(0)', offset: 0.9 }, // 保持到 90%
            { opacity: 0, transform: 'translateX(-50%) translateY(-10px)' } // 终点：略微上移消失
        ], {
            duration: duration,
            easing: 'ease-out',
            fill: 'forwards'
        });
        notification.currentAnim = animation;
        // 4. 精准销毁：动画真正结束时才移除 DOM
        animation.onfinish = () => {
            // 只有当动画确实播完（不是被 cancel）才移除
            if (animation.playState === 'finished' && notification.parentNode) {
                notification.remove();
            }
        };
    }
    function tryNextRedundantUrl() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError("频道列表数据错误");
            return;
        }
        if (item.currentRound === undefined) item.currentRound = 1;
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        const nextIndex = item.currentUrlIndex + 1;
        if (nextIndex < item.urls.length) {
            item.currentUrlIndex = nextIndex;
        } else if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
            item.currentUrlIndex = 0;
            item.currentRound++;
            console.warn(`频道 [${item.title}] 开启第 ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS} 轮尝试...`);
            showNotification(`第 ${item.currentRound} 轮尝试 (共 ${CONFIG.MAX_RETRY_ROUNDS} 轮)`, 2000);
        } else {
            if (state.timers.load) {
                clearTimeout(state.timers.load);
                state.timers.load = null;
            }
            destroyPlayer();
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            UI.playPauseBtn.title = "播放";
            showError(`频道 [${item.title || "未知"}] 无法播放或太过卡顿，请尝试其他频道。`);
            return;
        }
        const nextUrl = item.urls[item.currentUrlIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "自动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => tryNextRedundantUrl(), 500);
            return;
        }
        console.warn(`自动换源 (轮次:${item.currentRound}, 索引:${item.currentUrlIndex}): ${nextUrl}`);
        showNotification(`自动切换到源 ${item.currentUrlIndex + 1}/${item.urls.length}`, 1500);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function playPlaylistItem(index) {
        if (index < 0 || index >= state.currentPlaylist.length) return;
        const item = state.currentPlaylist[index];
        const itemUrl = item.urls[0];
        // 检查URL是否在黑名单中
        if (checkUrlInBlacklist(itemUrl, "频道列表URL")) {
            return;
        }
        state.currentPlaylistIndex = index;
        item.currentUrlIndex = 0;
        item.currentRound = 1;
        state.currentChannelInfo = {
            title: item.title || "",
            originalIndex: index,
            urls: [...item.urls]
        };
        updatePlaylistHighlight();
        UI.videoInfo.textContent = item.title || decodeURIComponent(itemUrl);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(itemUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function renderPlaylist(searchTerm = "") {
        UI.playlistItems.innerHTML = "";
        const lowerTerm = searchTerm.toLowerCase();
        const fragment = document.createDocumentFragment();
        state.currentPlaylist.forEach((item, index) => {
            const channelName = item.title || `项目 ${index + 1}`;
            if (searchTerm && !channelName.toLowerCase().includes(lowerTerm)) {
                return;
            }
            const el = document.createElement("div");
            el.className = "playlist-item";
            el.setAttribute('tabindex', '-1');
            if (index === state.currentPlaylistIndex) el.classList.add("active");
            el.textContent = channelName;
            el.dataset.index = index;
            el.onclick = () => {
                playPlaylistItem(index);
                // 点击后保持频道列表焦点状态
                maintainPlaylistFocus();
            };
            setupButtonHoverEffects(el);
            // 添加鼠标和焦点事件以显示EPG弹出框
            el.addEventListener('mouseenter', () => showEpgPopup(el, item));
            el.addEventListener('mouseleave', hideEpgPopup);
            el.addEventListener('focus', () => showEpgPopup(el, item));
            el.addEventListener('blur', hideEpgPopup);
            // 如果EPG启用，添加当前节目显示
            if (CONFIG.EPG_ENABLED) {
                const chId = getChannelId(item);
                const programs = state.epgData[chId] || [];
                const current = getCurrentProgram(programs);
                if (current) {
                    const span = document.createElement('span');
                    span.className = 'current-program';
                    span.textContent = `当前: ${current.title}`;
                    el.appendChild(span);
                }
            }
            fragment.appendChild(el);
        });
        UI.playlistItems.appendChild(fragment);
    }
    /**
     * 更新播放列表高亮并滚动到视野
     * @param {string} blockScroll - 滚动对齐方式，可选 "nearest", "center", "start", "end"。默认为 "nearest"。
     */
    function updatePlaylistHighlight(blockScroll = "nearest") {
        const items = UI.playlistItems.children;
        const container = UI.playlistItems; // 假设这是滚动的父容器
        const currentIndex = state.currentPlaylistIndex;
        for (let el of items) {
            if (parseInt(el.dataset.index) === currentIndex) {
                el.classList.add("active");
                if (blockScroll === "center") {
                    // --- 手动计算居中逻辑 ---
                    // 目标元素相对于容器顶部的距离 + 元素高度的一半 - 容器高度的一半
                    const elementTop = el.offsetTop;
                    const elementHeight = el.offsetHeight;
                    const containerHeight = container.clientHeight;
                    container.scrollTo({
                        top: elementTop - (containerHeight / 2) + (elementHeight / 2),
                        behavior: "instant"
                    });
                } else if (blockScroll === "nearest") {
                    // nearest 模式下原生方法通常表现良好
                    el.scrollIntoView({ behavior: "instant", block: "nearest" });
                }
            } else {
                el.classList.remove("active");
            }
        }
    }
    function handlePlaylistSearch(e) {
        const term = e.target.value;
        if (term) UI.clearSearchBtn.classList.add("visible");
        else UI.clearSearchBtn.classList.remove("visible");
        if (state.timers.searchDebounce) clearTimeout(state.timers.searchDebounce);
        state.timers.searchDebounce = setTimeout(() => {
            renderPlaylist(term);
            // 搜索后清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, CONFIG.SEARCH_DEBOUNCE_MS);
    }
    function clearSearch() {
        UI.playlistSearchInput.value = "";
        UI.clearSearchBtn.classList.remove("visible");
        renderPlaylist("");
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
    }
    function updateVideoInfoFromElement() {
        if (UI.videoPlayer.videoWidth && UI.videoPlayer.videoHeight) {
            state.streamInfo.resolution = `${UI.videoPlayer.videoWidth}x${UI.videoPlayer.videoHeight}`;
        }
        updateInfoPanel();
    }
    function updateResolutionFromHls(hls) {
        if (!hls?.levels?.length) return;
        let idx = hls.currentLevel;
        // 自动模式下优先使用最近一次自适应结果
        if (idx < 0 && hls.autoLevelEnabled) {
            idx = hls.autoLevelLast >= 0 ? hls.autoLevelLast :
                  hls.nextLoadLevel >= 0   ? hls.nextLoadLevel : 0;
        }
        // 防止索引越界（虽然正常情况下不应该发生，但防御性编程）
        idx = Math.max(0, Math.min(idx, hls.levels.length - 1));
        const level = hls.levels[idx];
        if (level?.width > 0 && level?.height > 0) {
            state.streamInfo.resolution = `${level.width}×${level.height}`;
        }
        // 可选：增加 video 元素 fallback（最保险）
        else if (hls.media?.videoWidth > 0 && hls.media?.videoHeight > 0) {
            state.streamInfo.resolution = `${hls.media.videoWidth}×${hls.media.videoHeight}(ｖ)`;
        }
        updateInfoPanel();
    }
    /**
     * 更新信息面板
     * 采用声明式数据结构，确保冒号贴合文字且数值垂直对齐
     */
    function updateInfoPanel() {
        if (!UI.infoPanel) return;
        // 1. 构造结构化数据数组 (Label/Value 分离)
        const infoItems = [
            { label: '类型', value: state.streamInfo.type },
            { label: '分辨率', value: state.streamInfo.resolution }
        ];
        // HLS 特有信息
        if (state.streamInfo.type === "HLS") {
            infoItems.push({ label: '码率', value: state.streamInfo.bitrate });
        }
        // 编码格式支持判断
        const codecSupported = ["HLS", "TS", "FLV"];
        if (codecSupported.includes(state.streamInfo.type)) {
            infoItems.push({ label: '编码', value: state.streamInfo.codec });
        }
        // 播放列表与源信息
        if (state.isM3UPlaylist && state.currentPlaylist && state.currentPlaylistIndex >= 0) {
            const item = state.currentPlaylist[state.currentPlaylistIndex];
            if (item) {
                const totalUrls = Array.isArray(item.urls) ? item.urls.length : 0;
                if (totalUrls >= 1) {
                    const currentIndex = (Number(item.currentUrlIndex) || 0) + 1;
                    infoItems.push({ label: '源', value: `${currentIndex}/${totalUrls}` });
                }
                infoItems.push({ 
                    label: '频道列表', 
                    value: `${state.currentPlaylistIndex + 1}/${state.currentPlaylist.length}` 
                });
                // 自动刷新配置
                if (CONFIG.AUTO_REFRESH_ENABLED && state.timers?.refreshPlaylist) {
                    const refreshMin = Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL / 60000);
                    infoItems.push({ label: '列表刷新', value: `${refreshMin}分钟` });
                }
                // 状态标签
                if (item.title && String(item.title).includes("(旧列表)")) {
                    infoItems.push({ label: '状态', value: '来自旧列表' });
                }
            }
        }
        // 黑名单信息
        if (Array.isArray(state.blacklist) && state.blacklist.length > 0) {
            infoItems.push({ label: '黑名单', value: `${state.blacklist.length}个规则` });
        }
        // 2. 渲染 HTML (使用 CSS Grid 结构)
        // 过滤掉空值，映射为标准网格行
        UI.infoPanel.innerHTML = infoItems
            .filter(item => item.value !== undefined && item.value !== null && item.value !== '')
            .map(item => `
                <div class="info-row">
                    <div class="info-label-group">
                        <span class="info-label">${item.label}</span>
                        <span class="info-colon">:</span>
                    </div>
                    <div class="info-value">${item.value}</div>
                </div>
            `).join('');
    }
    function toggleVideoInfo() {
        updateInfoPanel();
        const currentDisplay = UI.infoPanel.style.display;
        UI.infoPanel.style.display = currentDisplay === "none" ? "block" : "none";
    }
    function updateProgress() {
        const { currentTime, duration } = UI.videoPlayer;
        if (duration && !isNaN(duration) && duration !== Infinity) {
            const percent = currentTime / duration * 100;
            UI.progressBar.style.width = percent + "%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / ${formatTime(duration)}`;
        } else {
            UI.progressBar.style.width = "100%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / Live`;
        }
    }
    function seek(e) {
        if (!UI.videoPlayer.duration || UI.videoPlayer.duration === Infinity) return;
        const rect = UI.progress.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        UI.videoPlayer.currentTime = pos * UI.videoPlayer.duration;
    }
    function adjustVolume(e) {
        const rect = UI.volumeSlider.getBoundingClientRect();
        let volume = (e.clientX - rect.left) / rect.width;
        volume = Math.max(0, Math.min(1, volume));
        UI.videoPlayer.volume = volume;
        UI.volumeProgress.style.width = volume * 100 + "%";
        updateVolumeIcon();
        chrome.storage.local.set({
            volume: volume
        });
    }
    function updateVolumeIcon() {
        const v = UI.videoPlayer.volume;
        if (UI.videoPlayer.muted || v === 0) UI.volumeBtn.textContent = "🔇";
        else if (v < .5) UI.volumeBtn.textContent = "🔉";
        else UI.volumeBtn.textContent = "🔊";
    }
    function toggleMute() {
        UI.videoPlayer.muted = !UI.videoPlayer.muted;
        updateVolumeIcon();
    }
    function toggleFullscreen() {
        const container = document.querySelector(".player-container");
        if (!document.fullscreenElement) {
            (container.requestFullscreen || container.webkitRequestFullscreen || container.msRequestFullscreen).call(container);
        } else {
            (document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen).call(document);
        }
    }
    function initAudioContext() {
        if (state.audioContext) return;
        try {
            state.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            state.sourceNode = state.audioContext.createMediaElementSource(UI.videoPlayer);
            state.dynamicsCompressor = state.audioContext.createDynamicsCompressor();
            // 配置压缩器以实现响度均衡
            state.dynamicsCompressor.threshold.setValueAtTime(-24, state.audioContext.currentTime);
            state.dynamicsCompressor.knee.setValueAtTime(30, state.audioContext.currentTime);
            state.dynamicsCompressor.ratio.setValueAtTime(12, state.audioContext.currentTime);
            state.dynamicsCompressor.attack.setValueAtTime(0.003, state.audioContext.currentTime);
            state.dynamicsCompressor.release.setValueAtTime(0.25, state.audioContext.currentTime);
            state.sourceNode.connect(state.audioContext.destination);
        } catch (e) {
            console.error('Web Audio API 初始化失败:', e);
        }
    }
    function toggleLoudnessEqualizer(forceState) {
        if (!state.audioContext) initAudioContext();
        if (!state.audioContext) return;
        // 修复：如果是点击事件触发，forceState 会是 Event 对象，此时应视为 undefined
        const actualForceState = (typeof forceState === 'boolean') ? forceState : undefined;
        if (actualForceState !== undefined) {
            state.isLoudnessEnabled = actualForceState;
        } else {
            state.isLoudnessEnabled = !state.isLoudnessEnabled;
        }
        // 保存状态到 storage
        chrome.storage.local.set({ loudnessEnabled: state.isLoudnessEnabled });
        if (state.isLoudnessEnabled) {
            state.sourceNode.disconnect();
            state.sourceNode.connect(state.dynamicsCompressor);
            state.dynamicsCompressor.connect(state.audioContext.destination);
            UI.loudnessBtn.style.color = '#1E90FF';
            showNotification("响度均衡已开启",'success', 1500);
        } else {
            state.sourceNode.disconnect();
            state.dynamicsCompressor.disconnect();
            state.sourceNode.connect(state.audioContext.destination);
            UI.loudnessBtn.style.color = '#9CA3AF';
            showNotification("响度均衡已关闭", 1500);
        }
        if (state.audioContext.state === 'suspended') {
            state.audioContext.resume();
        }
    }
    function togglePlayPause() {
        if (UI.videoPlayer.paused) attemptPlay();
        else UI.videoPlayer.pause();
    }
    function showControls() {
        UI.controls.classList.remove("hidden");
        if (state.timers.controls) clearTimeout(state.timers.controls);
        state.timers.controls = setTimeout(() => {
            if (state.isPlaying) {
                UI.controls.classList.add("hidden");
            }
        }, 30000);
    }
    function initGlobalEvents() {
        document.addEventListener("mousemove", showControls);
        // 添加键盘事件监听
        document.addEventListener("keydown", handleKeyDown);
        // 新增：进阶面板开关
        UI.advancedBtn.onclick = (e) => {
            e.stopPropagation();
            const isVisible = UI.advancedPanel.style.display !== 'none';
            UI.advancedPanel.style.display = isVisible ? 'none' : 'block';
        };
        // 点击其他地方关闭
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.advanced-btn') && 
                !e.target.closest('.advanced-panel')) {
                if (UI.advancedPanel) UI.advancedPanel.style.display = 'none';
            }
        });
        UI.playPauseBtn.onclick = togglePlayPause;
        UI.prevChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToPrevChannel();
        };
        UI.nextChannelBtn.onclick = function(e) {
            e.stopPropagation();
            switchToNextChannel();
        };
        UI.volumeBtn.onclick = toggleMute;
        UI.volumeSlider.onclick = adjustVolume;
        UI.fullscreenBtn.onclick = toggleFullscreen;
        UI.backBtn.onclick = () => window.close();
        UI.infoBtn.onclick = toggleVideoInfo;
        UI.playlistBtn.onclick = () => togglePlaylistUI();
        UI.closePlaylistBtn.onclick = () => togglePlaylistUI(false);
        UI.progress.onclick = seek;
        UI.playlistSearchInput.oninput = handlePlaylistSearch;
        UI.clearSearchBtn.onclick = clearSearch;
        UI.switchSourceBtn.onclick = function(e) {
            e.stopPropagation();
            manualSwitchToNextSource();
        };
        UI.playlistContainer.onmouseleave = () => {
            if (document.activeElement !== UI.playlistSearchInput) {
                state.timers.hidePlaylist = setTimeout(() => togglePlaylistUI(false), 300);
            }
        };
        UI.playlistContainer.onmouseenter = () => {
            if (state.timers.hidePlaylist) clearTimeout(state.timers.hidePlaylist);
        };
    }
    window.addEventListener('beforeunload', function() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            console.log('[清理] 频道列表刷新定时器已清理');
        }
        if (state.timers.load) {
            clearTimeout(state.timers.load);
            console.log('[清理] 加载定时器已清理');
        }
        if (state.timers.stall) {
            clearTimeout(state.timers.stall);
            console.log('[清理] 卡顿定时器已清理');
        }
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            console.log('[清理] EPG刷新定时器已清理');
        }
    });
    init();
});