'use strict';
/**
 * js/soda-asr.js
 *
 * 基于浏览器原生 SpeechRecognition（SODA, processLocally:true）的
 * 离线实时语音识别模块，完整替代原 Whisper/transformers.js 链路
 * （whisper-iframe.js / whisper-audio-worker.js / whisper-worker.js /
 *   whisper-offscreen.js 均已删除，不再需要）。
 *
 * 音频来源：直接从 player.js 持有的 <video> 元素通过
 * AudioContext.createMediaElementSource + createMediaStreamDestination
 * 抽取一路 MediaStreamTrack 喂给 recognition.start(track)。
 * 因为不是从麦克风 getUserMedia 拿到的 track，不会触发麦克风权限弹窗；
 * 同时把该路音频接回 audioContext.destination，保证用户仍能听到声音。
 *
 * 已知平台限制（供后续排障参考）：
 *   · 不同浏览器/版本支持的语言集合差异很大（Chrome 官方支持较全，
 *     Edge 早期版本仅 en-US/de-DE/it-IT/pt-PT/es-ES/ko-KR 六种且需
 *     Canary/Dev 频道 + flag开启实验项），必须用 available() 实测，不能硬编码。
 *   · available() 显示 available 不代表 start() 一定成功
 *     （偶发 language-not-supported），这是浏览器该实验性 API 自身的
 *     不稳定行为。
 *   · install() 必须在用户点击的同步手势链路内直接调用；跨消息传递
 *     （如经 background/offscreen 中转）后调用会报
 *     "Requires handling a user gesture"。本模块的 installLang() 因此
 *     被设计为可以直接从 DOM click handler 里同步发起调用。
 *
 * 用法：
 *   const asr = new SodaAsr({ videoEl, onInterim, onFinal, onStatus, onError });
 *   await asr.start('zh-CN');
 *   asr.stop();
 *
 *   SodaAsr.LANGS                     常用语言候选表
 *   SodaAsr.checkAvailability(lang)   → 'available'|'downloadable'|'downloading'|'unavailable'|'unsupported'
 *   SodaAsr.installLang(lang)         → Promise<boolean>
 */

const RecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;

// 常用语言候选表：实际是否支持由 checkAvailability() 实测决定，
// 这里只是提供一个便于选择的候选清单。
const LANGS = [
    //{ code: 'zh-CN', label: '中文（普通话）' },
    { code: 'en-US', label: '英语' },
    { code: 'ja-JP', label: '日语' },
    { code: 'ko-KR', label: '韩语' },
    { code: 'de-DE', label: '德语' },
    { code: 'fr-FR', label: '法语' },
    { code: 'ru-RU', label: '俄语' },	
    { code: 'es-ES', label: '西班牙语' },
    { code: 'it-IT', label: '意大利语' },
    { code: 'pt-PT', label: '葡萄牙语' },
];

async function checkAvailability(langCode) {
    if (!RecognitionAPI || typeof RecognitionAPI.available !== 'function') return 'unsupported';
    try {
        const st = await RecognitionAPI.available({ langs: [langCode], processLocally: true });
        return st || 'unavailable';
    } catch (e) {
        return 'unsupported';
    }
}

// 注意：调用方必须保证这是从用户点击事件回调里直接、同步触发的
// （中间不能先 await 别的异步操作再调用它），否则浏览器会拒绝安装。
async function installLang(langCode) {
    if (!RecognitionAPI || typeof RecognitionAPI.install !== 'function') return false;
    try {
        return !!(await RecognitionAPI.install({ langs: [langCode], processLocally: true }));
    } catch (e) {
        console.warn('[SodaAsr] installLang 失败:', e && e.message);
        return false;
    }
}

class SodaAsr {
    constructor({ videoEl, onInterim, onFinal, onStatus, onError }) {
        this.videoEl   = videoEl;
        this.onInterim = onInterim || function () {};
        this.onFinal   = onFinal   || function () {};
        this.onStatus  = onStatus  || function () {};
        this.onError   = onError   || function () {};

        this.recognition  = null;
        this.audioCtx     = null;
        this.sourceNode   = null;
        this.destNode     = null;
        this.track        = null;
        this._graphReady  = false; // 音频抓取图（Context+SourceNode）是否已建立
        this.lang         = 'zh-CN';
        this.enabled      = false;
        this._userStopped = true;
    }

    get supported() {
        return !!RecognitionAPI;
    }

    // ── 从 <video> 元素抽取音频 track ──────────────────────────────
    //
    // 重要：createMediaElementSource() 对同一个 <video> 元素在其整个
    // DOM 生命周期内只能成功调用一次——这个绑定是浏览器内部永久性的，
    // 即使后续把 AudioContext close() 掉也无法解除，再次调用会直接
    // 抛出 InvalidStateError。因此这个音频图必须只建立一次，
    // 开关字幕只应该控制 SpeechRecognition 的启停，绝不能在 stop()
    // 里销毁 Context / SourceNode，否则：
    //   1) close() 会切断 video 的音频输出链路 → 停止字幕后没声音；
    //   2) 下次开启再调 createMediaElementSource 会直接报错；
    //   3) 处于半损坏状态的音频图还可能连带卡住视频解码时钟。
    _acquireTrack() {
        if (this._graphReady) return this.track;
        this.audioCtx   = new (window.AudioContext || window.webkitAudioContext)();
        this.sourceNode = this.audioCtx.createMediaElementSource(this.videoEl);
        this.destNode   = this.audioCtx.createMediaStreamDestination();
        this.sourceNode.connect(this.destNode);              // 一路送给识别
        this.sourceNode.connect(this.audioCtx.destination);  // 一路接回正常播放，保持有声音
        this.track = this.destNode.stream.getAudioTracks()[0];
        this._graphReady = true;
        return this.track;
    }

    _createRecognition() {
        const r = new RecognitionAPI();
        r.lang           = this.lang;
        r.continuous     = true;
        r.interimResults = true;
        r.processLocally = true;
		if ('unspokenPunctuation' in r) {
		  r.unspokenPunctuation = true;
		}

        r.onresult = (e) => {
            for (let i = e.resultIndex; i < e.results.length; i++) {
                const res  = e.results[i];
                const text = ((res[0] && res[0].transcript) || '').trim();
                if (!text) continue;
                if (res.isFinal) this.onFinal(text);
                else              this.onInterim(text);
            }
        };
        r.onerror = (e) => {
            // no-speech 是正常的静音间隙，不当错误上报，交给 onend 处理重启
            if (e.error === 'no-speech' || e.error === 'aborted') return;
            this.onError(e.error);
        };
        r.onend = () => {
            // continuous 模式下浏览器仍可能自行结束会话（已知的不稳定行为），
            // 只要用户没有主动停止字幕，就自动重启，维持"持续识别"体验。
            if (this.enabled && !this._userStopped) {
                setTimeout(() => {
                    if (this.enabled && !this._userStopped) this._restart();
                }, 250);
            } else {
                this.onStatus('idle');
            }
        };
        return r;
    }

    _restart() {
        try {
            this.recognition = this._createRecognition();
            this.recognition.start(this.track || this._acquireTrack());
        } catch (e) {
            this.onError('重启识别失败: ' + e.message);
        }
    }

    async start(langCode) {
        if (!this.supported) {
            this.onError('当前浏览器不支持 SpeechRecognition（SODA）');
            return;
        }
        if (this.enabled) return;
        this.lang          = langCode || this.lang;
        this._userStopped  = false;
        this.onStatus('loading', '正在检测本地语音模型…');

        const avail = await checkAvailability(this.lang);
        if (avail === 'unavailable' || avail === 'unsupported') {
            this.onError(avail === 'unsupported'
                ? '当前浏览器不支持该语言的离线识别'
                : '该语言暂无可用的离线识别模型');
            return;
        }
        if (avail === 'downloadable' || avail === 'downloading') {
            this.onError('模型尚未下载完成，请先在面板中点击"下载模型"');
            return;
        }

        try {
            const track = this._acquireTrack();
            if (this.audioCtx && this.audioCtx.state === 'suspended') {
                this.audioCtx.resume().catch(() => {});
            }
            this.enabled      = true;
            this.recognition  = this._createRecognition();
            this.recognition.start(track);
            this.onStatus('running', `识别中 · ${this.lang}`);
        } catch (e) {
            this.enabled = false;
            this.onError('启动失败: ' + e.message);
        }
    }

    stop() {
        this._userStopped = true;
        this.enabled       = false;
        if (this.recognition) {
            try { this.recognition.stop(); } catch (_) {}
            this.recognition = null;
        }
        // 注意：这里绝不能关闭 audioCtx 或断开 sourceNode——
        // 那个连接是 <video> 音频能正常播放的唯一路径（见 _acquireTrack 注释），
        // 关掉就再也连不回去了。只停止识别本身。
        this.onStatus('idle', '已停止');
    }
}

SodaAsr.LANGS              = LANGS;
SodaAsr.checkAvailability  = checkAvailability;
SodaAsr.installLang        = installLang;

window.SodaAsr = SodaAsr;