// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", async function() {
    await i18n.ready; // 必须先等语言包加载完，下面 init() 里创建的按钮/tooltip 才能拿到正确文案
    // 默认配置（使用毫秒）
    const DEFAULT_CONFIG = {
        LOAD_TIMEOUT_MS: 10000, // 10秒
        STALL_TIMEOUT_MS: 10000, // 10秒
        MAX_RETRY_ROUNDS: 1, // 1轮
        SEARCH_DEBOUNCE_MS: 300, // 300毫秒
        PLAYLIST_REFRESH_INTERVAL: 1000 * 60 * 30, // 30分钟
        AUTO_REFRESH_ENABLED: true, // 启用自动刷新频道列表
        BLACKLIST_URL: chrome.runtime.getURL('blacklist.txt'), // 黑名单文件URL
        EPG_ENABLED: false, // 默认关闭EPG
        EPG_URL: FmDefaults.EPG_URL, // 默认EPG URL（统一来自 js/defaults.js）
        RULES: [], //Headers设置 示例：[{ pattern: '*.abc.com', headers: { Auth: 'xxx', Referer: 'xxx' } },...]
        MARQUEE_SPEED: 100, // 跑马灯速度 (像素/秒)
        MARQUEE_COLOR: '#ffd700', // 跑马灯字体颜色
        MARQUEE_FONT_SIZE: '20' // 跑马灯字体大小(px)
    };
    // 实际使用的配置（会被用户设置覆盖）
    const CONFIG = { ...DEFAULT_CONFIG };
    const MIN_EPG_REFRESH_INTERVAL = 10 * 60 * 1000; // 最小EPG刷新间隔: 10分钟
    const state = {
        player: null,
        isPlaying: false,
        videoUrl: "",
        baseUrl: "",
        currentPlaylist: [],
        originalPlaylistUrl: "",
        currentPlaylistIndex: -1,
        isM3UPlaylist: false,
        streamInfo: {
            resolution: "--",
            type: "--",
            codec: "--",
            bitrate: "--",
            bandwidthEstimate: 0
        },
        loadRequestId: 0,
        timers: {
            load: null,
            stall: null,
            controls: null,
            hidePlaylist: null,
            searchDebounce: null,
            refreshPlaylist: null,
            epgRefresh: null // 新增: EPG刷新定时器
        },
        currentChannelInfo: {
            title: "",
            originalIndex: -1,
            urls: []
        },
        blacklist: [], // 黑名单关键词数组
        isBlacklistLoaded: false, // 黑名单是否已加载
        epgData: {}, // EPG数据: {channelId: [{start, stop, title}]}
        channelMap: {}, // name.lower -> id
        epgExpiryTime: 0, // EPG到期时间戳
        lastEpgRefreshTime: 0, // 上次EPG刷新时间戳
        isMarqueeActive: false, // 新增: 跑马灯是否活跃标志
        isLoudnessEnabled: false, // 新增: 响度均衡是否开启
        audioContext: null, // 新增: Web Audio Context（响度均衡 / 实时字幕共用，见 _ensureSharedAudioGraph）
        sourceNode: null, // 新增: Audio Source Node（同上，两个功能共用同一个）
        dynamicsCompressor: null, // 新增: 动态压缩器节点
        sodaDestNode: null, // 供实时字幕(SODA)抽取音频轨用的 MediaStreamDestination，从共享 sourceNode 上分出的一路
        // 新增：AI字幕翻译开关
        isSubtitleTranslationEnabled: false,
        // 实时字幕（浏览器原生 SODA 离线语音识别，替代原 Whisper 全链路）
        whisper: {
            enabled:     false,
            language:    'zh-CN',
            interimText: '',   // 当前未定稿的识别结果（灰色滚动显示）
            subtitles:   [],   // 已定稿的 [{text, showAt, hideAt}]，用于短暂停留展示
            rafId:       null,
            langStatus:  'unsupported', // 'available'|'downloadable'|'downloading'|'unavailable'|'unsupported'
        },
        // 视频内容总结（基于 Chrome 内置 Summarizer API，对实时字幕的原文做周期性总结）
        summary: {
            enabled:         false,   // 总结开关；只有 whisper.enabled 时才允许打开
            intervalMinutes: 10,      // 总结间隔：5 或 10 分钟
            pendingTexts:    [],      // 自上次总结以来新增的字幕原文（纯文本，已清洗，跟展示用的 whisper.subtitles 完全独立）
            cycleStartTime:  0,       // 当前累积周期起始的 video.currentTime，用于给总结结果打时间范围标签
            nextSummaryAt:   0,       // 下一次总结的时间点（Date.now() 时间戳，毫秒），供面板显示倒计时
            timerId:         null,    // setInterval 句柄
            summarizer:      null,    // 缓存的 Summarizer 实例（同一输出语言下可复用，避免每轮都重新下载/创建）
            summarizerLang:  null,    // 实际喂给 Summarizer 的 outputLanguage（支持列表里没有目标语言时会是 'en'）
            outputLang:      null,    // 最终想要展示给用户的语言（浏览器本地语言，跟 summarizerLang 不一致时需要再翻译一次）
            running:         false,   // 是否有一轮总结正在进行（避免并发）
            results:         [],      // 已产生的总结记录 [{rangeLabel, text, error}]，供面板展示
            onUpdate:        null,    // 面板 UI 的重渲染回调，由 soda-panel.js 注册
        }
    };
    const UI = {
        videoPlayer: document.getElementById("videoPlayer"),
        videoInfo: document.getElementById("videoInfo"),
        videoContainer: document.querySelector(".video-container"),
        controls: document.getElementById("controls"),
        playPauseBtn: document.getElementById("playPauseBtn"),
        backBtn: document.getElementById("backBtn"),
        prevChannelBtn: document.getElementById("prevChannelBtn"),
        nextChannelBtn: document.getElementById("nextChannelBtn"),
        volumeBtn: document.getElementById("volumeBtn"),
        fullscreenBtn: document.getElementById("fullscreenBtn"),
        playlistBtn: document.getElementById("playlistBtn"),
        closePlaylistBtn: document.getElementById("closePlaylistBtn"),
        clearSearchBtn: document.getElementById("clearSearchBtn"),
        infoBtn: null,
        progress: document.getElementById("progress"),
        progressBar: document.getElementById("progressBar"),
        timeDisplay: document.getElementById("time"),
        volumeSlider: document.getElementById("volumeSlider"),
        volumeProgress: document.getElementById("volumeProgress"),
        volumeContainer: document.querySelector(".volume-container"),
        playlistContainer: document.getElementById("playlist-container"),
        playlistItems: document.getElementById("playlist-items"),
        playlistSearchInput: document.getElementById("playlist-search-input"),
        loading: document.getElementById("loading"),
        errorMessage: document.getElementById("errorMessage"),
        infoPanel: null,
        switchSourceBtn: null,
        epgBtn: null,
        // 新增：进阶设置相关
        advancedBtn: null,
        advancedPanel: null,
        whisperBtn: null,
        loudnessBtn: null,
        subDisplay: document.getElementById('subtitle-display')
    };
    let epgPopup = null;
    let playerContainer = null;
    // ==================== 新增：AI 字幕翻译相关 ====================
    let detector = null;
    let translatorCache = new Map();
    let modelStatusShown = false;
    // 字幕翻译的目标语言：不再写死 'zh'，改成跟随浏览器/系统语言设置。
    // 只算一次并缓存——用户不会在一个播放会话中途切换浏览器语言。
    let _subtitleTargetLang = null;
    function getSubtitleTargetLang() {
        if (_subtitleTargetLang) return _subtitleTargetLang;
        let lang = '';
        try {
            if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getUILanguage === 'function') {
                lang = chrome.i18n.getUILanguage() || '';
            }
        } catch (e) { /* ignore */ }
        if (!lang) lang = (navigator.language || navigator.userLanguage || '');
        // Translator API 用的是不带地区的主语言子标签（如 'zh'、'en'、'ja'），
        // 浏览器语言可能是 'zh-CN'、'en-US' 这种带地区的完整代码，取第一段即可。
        _subtitleTargetLang = (lang || 'en').split('-')[0].toLowerCase() || 'en';
        return _subtitleTargetLang;
    }
    // 目标语言的可读名称（用于"正在下载 xx → yy 翻译模型"这类提示），
    // 用 Intl.DisplayNames 而不是手写语言名称表，覆盖面更广也不用维护。
    function getLanguageDisplayName(langCode) {
        try {
            return new Intl.DisplayNames([i18n.locale === 'zh_CN' ? 'zh-CN' : 'en'], { type: 'language' }).of(langCode) || langCode;
        } catch (e) {
            return langCode;
        }
    }

    // ==================== 带上下文的字幕翻译 ====================
    // 原来是"一句话独立翻译一句"，模型看不到前后文，容易出现代词指代不清、
    // 术语前后不一致这类问题。改成把当前这句和它前面若干句原文用一个标记符号
    // 拼接起来一起丢给翻译模型（模型能看到完整上下文，翻译质量更好），拿到译文
    // 后只截取"最后一个标记符号之后"的部分，当作当前这句的译文——前面几句
    // 的译文不需要，只是拿来给模型"看"的。
    //
    // 这个变量控制"设置上下文的长度"：多少句原文（含当前这句）叠加在一起
    // 翻译。比如设成 3，就是"前两句 + 当前这句"一起送去翻译。设成 1 就完全
    // 等价于原来的"每句独立翻译"（不带任何上下文）。
    const WHISPER_TRANSLATION_CONTEXT_LENGTH = 10;
    // 拼接用的标记符号：要选一个正常语音字幕里几乎不可能出现、翻译模型大概率
    // 会原样保留（不当成需要翻译的词）的符号。希腊字母在大多数语言的日常字幕
    // 文本里都不会自然出现，是个安全的选择。
    const WHISPER_TRANSLATION_CONTEXT_MARKER = '★';

    // 从某条字幕所在的历史数组（state.whisper.subtitles 或 hlsSubHistory）里，
    // 取出排在它前面、最近的最多 (contextLength-1) 条原文，按时间从早到晚排列，
    // 作为这句话的上下文。用对象引用在数组里定位——finals/pending 里的元素
    // 本来就是从同一个数组 filter 出来的，是同一个对象引用，不会找错。
    function _getContextTextsFor(historyArray, entry, contextLength) {
        if (!historyArray || contextLength <= 1) return [];
        const idx = historyArray.indexOf(entry);
        if (idx <= 0) return [];
        const start = Math.max(0, idx - (contextLength - 1));
        return historyArray.slice(start, idx).map(e => e.text);
    }

    // 核心逻辑：把 [上下文...,当前这句] 用标记符号拼成一段话一起翻译，
    // 再从译文里把"最后一个标记符号之后"的部分切出来，作为当前这句的译文。
    // 如果标记符号在译文里没有按预期次数出现（翻译模型不一定会一字不差地
    // 保留任意符号，尤其是标点/特殊字符前后可能被模型加工），就退化成不带
    // 上下文、单独翻译当前这句——保底总要有个可用的结果，不能因为这个
    // 花活儿失败就整句没有译文。
    async function _translateWithContext(trans, contextTexts, currentText) {
        const marker = WHISPER_TRANSLATION_CONTEXT_MARKER;
        // 极少见的边界情况：如果当前这句原文自己就包含标记符号（比如内容真的在
        // 说"α粒子""α测试"之类），按标记切分译文时会把这句自己内部也切开，
        // 取到的"最后一段"就不是完整译文了。这种情况直接跳过上下文拼接，
        // 单独翻译更安全。
        if (currentText.includes(marker)) {
            return await trans.translate(currentText);
        }
        const combinedSource = [...contextTexts, currentText].join(` ${marker} `);
        let combinedTranslated;
        try {
            combinedTranslated = await trans.translate(combinedSource);
        } catch (e) {
            console.warn('[AI Subtitle] 带上下文翻译请求失败，退化为单独翻译:', e);
            return await trans.translate(currentText);
        }
        if (!combinedTranslated) return combinedTranslated;
        const parts = combinedTranslated.split(marker);
        if (parts.length >= contextTexts.length + 1) {
            // 正常情况：标记符号被完整保留了 contextTexts.length 次，
            // 取最后一段就是当前这句对应的译文。
            //console.warn(`完整译文: "${combinedTranslated}"`);
            return parts[parts.length - 1].trim();
        }
        console.warn(`[AI Subtitle] 带上下文翻译时标记符号"${marker}"在译文里丢失（期望切出 ${contextTexts.length + 1} 段，实际 ${parts.length} 段），退化为单独翻译。原文: "${currentText}" | 完整译文: "${combinedTranslated}"`);
        return await trans.translate(currentText);
    }

    let globalDetectedLang = null;          // 全局缓存的源语言，null 表示尚未确定
    let detectionCount = 0;                 // 已检测的字幕条数计数器
    const MAX_DETECTIONS = 10;              // 最多检测前 10 条
    const CONFIDENCE_THRESHOLD = 0.80;      // 置信度达到 80% 就锁定语言
    let translatorSupported = false;        // 全局标志：浏览器是否真正支持 Translator API
    // 一次性检测 Translator 是否真正可用
    async function checkTranslatorSupport() {
        if (!('Translator' in self)) {
            console.log("[AI Subtitle] 浏览器不支持 Translator API");
            translatorSupported = false;
            return;
        }
        const targetLang = getSubtitleTargetLang();
        // 探测用的源语言必须跟目标语言不同，否则同语言探测的行为在各浏览器版本上不一致；
        // 目标语言恰好是英语时，改用中文作探测源。
        const probeSourceLang = targetLang === 'en' ? 'zh' : 'en';
        try {
            // 方案1：最严格模式，同时传 source 和 target（推荐先试这个）
            let availability = await Translator.availability({
                sourceLanguage: probeSourceLang,
                targetLanguage: targetLang
            });
            console.log(`[AI Subtitle] availability (${probeSourceLang}→${targetLang}) 测试成功:`, availability);
            translatorSupported = true;
            return;
        } catch (err1) {
            console.warn(`[AI Subtitle] availability (${probeSourceLang}→${targetLang}) 失败:`, err1.message);
            try {
                // 方案2：只传 targetLanguage（部分版本接受）
                let availability = await Translator.availability({
                    targetLanguage: targetLang
                });
                console.log(`[AI Subtitle] availability (only ${targetLang}) 测试成功:`, availability);
                translatorSupported = true;
                return;
            } catch (err2) {
                console.warn(`[AI Subtitle] availability (only ${targetLang}) 失败:`, err2.message);
                try {
                    // 方案3：无参调用（极少数版本）
                    let availability = await Translator.availability();
                    console.log("[AI Subtitle] availability (无参) 测试成功:", availability);
                    translatorSupported = true;
                    return;
                } catch (err3) {
                    console.warn("[AI Subtitle] availability (无参) 失败:", err3.message);
                    translatorSupported = false;
                }
            }
        }
        console.log("[AI Subtitle] 最终结论：Translator API 不可用");
        translatorSupported = false;
    }
    function showModelLoadingMessage(show = true, message = "") {
        if (show) {
            showNotification(message || i18n.t('player_ai_subtitle_preparing_model'), "info", 5000);
            modelStatusShown = true;
        } else {
            modelStatusShown = false;
        }
    }
    async function getLanguageDetector() {
        if (detector) return detector;
        if (!('LanguageDetector' in self)) return null;
        try {
            const availability = await LanguageDetector.availability();
            if (availability === 'unavailable') return null;
            if ((availability === 'downloading' || availability === 'downloadable') && !modelStatusShown) {
                showModelLoadingMessage(true, i18n.t('player_downloading_lang_detector'));
            }
            detector = await LanguageDetector.create();
            showModelLoadingMessage(false);
            return detector;
        } catch (err) {
            console.warn("[AI Subtitle] LanguageDetector 创建失败", err);
            return null;
        }
    }
    /**
     * 综合语言检测函数：返回统一的 { detectedLanguage, confidence } 对象
     * 模拟原生 LanguageDetector 的输出格式，确保 player.js 的锁定机制正常工作
     */
    async function getDetectedResult(track, text) {
        // 0. 清理文本，去除 HTML 标签以提高检测准确度
        const plainText = text.replace(/<[^>]+>/g, '').trim();
        if (plainText.length < 2) return null;
        // --- 方案 1: TextTrack 元数据 (最高优先级) ---
        // 如果视频流本身定义了语言，这是最可靠的，直接给予 1.0 置信度
        if (track && track.language && track.language !== 'und' && track.language !== '') {
            const lang = track.language.split('-')[0].toLowerCase();
            console.log(`[AI Subtitle] 采用轨道元数据: ${lang} (Confidence: 1.0)`);
            return { detectedLanguage: lang, confidence: 1.0 };
        }
        // --- 方案 2: 原生 AI LanguageDetector (次高优先级) ---
        /*if ('LanguageDetector' in self) {
            try {
                // 注意：这里需要考虑你之前提到的 Model not available 异常
                const availability = await LanguageDetector.availability();
                if (availability === 'available') {
                    const detectorInstance = await LanguageDetector.create();
                    const results = await detectorInstance.detect(plainText);
                    if (results && results.length > 0) {
                        console.log(`[AI Subtitle] 采用原生 AI 检测: ${results[0].detectedLanguage} (${results[0].confidence.toFixed(4)})`);
                        return results[0]; // 直接返回原生对象 {detectedLanguage, confidence}
                    }
                }
            } catch (err) {
                console.warn("[AI Subtitle] 原生 AI 检测器不可用，尝试备选方案...");
            }
        }*/
        // --- 方案 3: chrome.i18n.detectLanguage (中等优先级) ---
        // 无需下载模型，系统内置，非常稳定
        if (typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.detectLanguage) {
            try {
                const result = await new Promise(resolve => {
                    chrome.i18n.detectLanguage(plainText, resolve);
                });
                if (result && result.languages.length > 0) {
                    const top = result.languages[0];
                    // 模拟置信度逻辑：
                    // 如果结果列表中只有一个语言，或者第一个语言占比很高，给予 0.9
                    // 否则给予 0.7 (不足以触发锁定，但足以尝试翻译)
                    const mockConfidence = (result.languages.length === 1 || top.percentage > 85) ? 0.9 : 0.7;
                    console.log(`[AI Subtitle] 采用 i18n 检测: ${top.language} (Mock Confidence: ${mockConfidence})`);
                    return { detectedLanguage: top.language, confidence: mockConfidence };
                }
            } catch (err) {
                console.error("[AI Subtitle] i18n 检测异常:", err);
            }
        }
        // --- 方案 4: 正则表达式兜底 (最低优先级) ---
        // 针对中日韩字符的硬匹配
        let langByRegex = 'en'; // 默认英文
        let regexConfidence = 0.5; // 默认较低置信度
        if (/[\u4e00-\u9fa5]/.test(plainText)) {
            langByRegex = 'zh';
            regexConfidence = 0.9; // 汉字特征明显，置信度设高
        } else if (/[\u3040-\u30ff]/.test(plainText)) {
            langByRegex = 'ja';
            regexConfidence = 0.9; // 假名特征明显
        } else if (/[\uac00-\ud7af]/.test(plainText)) {
            langByRegex = 'ko';
            regexConfidence = 0.9;
        }
        console.log(`[AI Subtitle] 采用正则检测: ${langByRegex} (Mock Confidence: ${regexConfidence})`);
        return { detectedLanguage: langByRegex, confidence: regexConfidence };
    }
    async function getTranslatorForSource(sourceLang = 'en') {
        if (translatorCache.has(sourceLang)) {
            return translatorCache.get(sourceLang);
        }
        if (!('Translator' in self)) {
            console.warn("[AI Subtitle] Translator API 不存在");
            return null;
        }
        const targetLang = getSubtitleTargetLang();
        try {
            let availability;
            try {
                availability = await Translator.availability({
                    sourceLanguage: sourceLang,
                    targetLanguage: targetLang
                });
                console.log(`[AI Subtitle] availability (${sourceLang}→${targetLang}) 返回:`, availability);
            } catch (e) {
                console.warn(`[AI Subtitle] availability (${sourceLang}→${targetLang}) 失败:`, e.message);
                try {
                    availability = await Translator.availability({
                        targetLanguage: targetLang
                    });
                } catch (e2) {
                    console.warn(`[AI Subtitle] availability (only ${targetLang}) 失败:`, e2.message);
                    availability = await Translator.availability();
                }
            }
            if (availability === 'unavailable') {
                console.warn("[AI Subtitle] 翻译模型不可用");
                return null;
            }
            if (availability === 'downloading' || availability === 'downloadable') {
                if (!modelStatusShown) {
                    showModelLoadingMessage(true, i18n.t('player_downloading_translation_model', {
                        SRC: getLanguageDisplayName(sourceLang),
                        TARGET: getLanguageDisplayName(targetLang)
                    }));
                    modelStatusShown = true;
                }
                await new Promise(r => setTimeout(r, 4000));
            }
            const newTranslator = await Translator.create({
                sourceLanguage: sourceLang,
                targetLanguage: targetLang
            });
            translatorCache.set(sourceLang, newTranslator);
            console.log(`[AI Subtitle] 创建并缓存 translator: ${sourceLang} → ${targetLang}`);
            showModelLoadingMessage(false);
            return newTranslator;
        } catch (err) {
            console.error(`[AI Subtitle] 创建 ${sourceLang} → ${targetLang} translator 失败:`, err);
            return null;
        }
    }
    // ==================== 键盘事件处理函数（已新增 T 键） ====================
    function handleKeyDown(e) {
        // 如果频道列表可见，优先处理频道列表相关快捷键
        if (!UI.playlistContainer.classList.contains("hidden")) {
            // PageDown键：关闭频道列表
            if (e.code === 'PageDown' || e.key === 'PageDown' || e.keyCode === 34) {
                e.preventDefault();
                closePlaylist();
                return;
            }
            // 回车键：播放当前选中的项目
            if ((e.code === 'Enter' || e.key === 'Enter' || e.keyCode === 13)) {
                e.preventDefault();
                playSelectedSearchResult();
                // 不移除焦点，保持频道列表控制状态
                return;
            }
            // 上下箭头：在搜索结果中导航
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                hideEpgPopup(); // 隐藏旧的
                navigateSearchResults(e.code === 'ArrowUp' ? -1 : 1);
                const selected = UI.playlistItems.querySelector('.selected');
                if (selected) {
                    const index = parseInt(selected.dataset.index);
                    const item = state.currentPlaylist[index];
                    showEpgPopup(selected, item);
                }
                return;
            }
            // 搜索框特殊处理
            if (e.target === UI.playlistSearchInput) {
                // 允许在搜索框中正常输入
                return;
            }
            // 其他按键在频道列表可见时不处理全局快捷键
            // 防止上下箭头变成音量调节
            if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
                e.preventDefault();
                return;
            }
            // 左右箭头：在频道列表打开时不处理，保持静默
            if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
                e.preventDefault();
                return;
            }
        }
        // 全局快捷键处理（仅当频道列表不可见时）
        // PageUp 键：调出频道列表并定位搜索框
        if (e.code === 'PageUp' || e.key === 'PageUp') {
            e.preventDefault(); // 防止浏览器搜索功能
            focusPlaylistSearch();
            showKeyFeedback(i18n.t('player_kf_search_playlist'));
        }
        // 空格键：播放/暂停
        else if (e.code === 'Space' || e.key === ' ' || e.keyCode === 32) {
            e.preventDefault(); // 防止空格键滚动页面
            togglePlayPause();
            // 显示控制栏反馈
            //showControls();
            // 短暂显示一个视觉反馈
            showKeyFeedback(i18n.t('player_kf_space', { STATE: UI.videoPlayer.paused ? i18n.t('player_kf_play') : i18n.t('player_kf_pause') }));
        }
        // 上箭头键：增加音量（仅当频道列表不可见时）
        else if (e.code === 'ArrowUp') {
            e.preventDefault();
            const result = adjustVolumeByArrow(0.05); // 每次增加5%
            if (result.changed) {
                showKeyFeedback(i18n.t('player_kf_volume', { VOL: result.newVolume }));
                //showControls();
            } else {
                showKeyFeedback(i18n.t('player_kf_volume_max'));
            }
        }
        // 下箭头键：减少音量（仅当频道列表不可见时）
        else if (e.code === 'ArrowDown') {
            e.preventDefault();
            const result = adjustVolumeByArrow(-0.05); // 每次减少5%
            if (result.changed) {
                showKeyFeedback(i18n.t('player_kf_volume', { VOL: result.newVolume }));
                //showControls();
            } else {
                showKeyFeedback(i18n.t('player_kf_volume_min'));
            }
        }
        // 左箭头键：快退5秒（仅当频道列表不可见时）
        else if (e.code === 'ArrowLeft') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.max(0, UI.videoPlayer.currentTime - 5);
                showKeyFeedback(i18n.t('player_kf_rewind'));
                //showControls();
            }
        }
        // 右箭头键：快进5秒（仅当频道列表不可见时）
        else if (e.code === 'ArrowRight') {
            e.preventDefault();
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration)) {
                UI.videoPlayer.currentTime = Math.min(UI.videoPlayer.duration, UI.videoPlayer.currentTime + 5);
                showKeyFeedback(i18n.t('player_kf_forward'));
                //showControls();
            }
        }
        // F键：全屏切换
        else if (e.code === 'KeyF' || e.key === 'f') {
            e.preventDefault();
            toggleFullscreen();
            showKeyFeedback(i18n.t('player_kf_fullscreen_toggle'));
            //showControls();
        }
        // M键：静音切换
        else if (e.code === 'KeyM' || e.key === 'm') {
            e.preventDefault();
            toggleMute();
            showKeyFeedback(UI.videoPlayer.muted ? i18n.t('player_kf_mute') : i18n.t('player_kf_unmute'));
            //showControls();
        }
        // P键：频道列表切换
        else if (e.code === 'KeyP' || e.key === 'p') {
            e.preventDefault();
            togglePlaylistUI();
            showKeyFeedback(i18n.t('player_kf_playlist'));
            //showControls();
        }
        // 左方括号键：上一个频道
        else if (e.code === 'BracketLeft' || e.key === '[') {
            e.preventDefault();
            switchToPrevChannel();
            //showKeyFeedback('上一个频道');
            //showControls();
        }
        // 右方括号键：下一个频道
        else if (e.code === 'BracketRight' || e.key === ']') {
            e.preventDefault();
            switchToNextChannel();
            //showKeyFeedback('下一个频道');
            //showControls();
        }
        // S键：手动换源
        else if (e.code === 'KeyS' || e.key === 's') {
            e.preventDefault();
            manualSwitchToNextSource();
            showKeyFeedback(i18n.t('player_kf_switch_source'));
            //showControls();
        }
        // I键：显示/隐藏信息面板
        else if (e.code === 'KeyI' || e.key === 'i') {
            e.preventDefault();
            toggleVideoInfo();
            showKeyFeedback(i18n.t('player_kf_info_panel'));
            //showControls();
        }
        // E键：显示EPG跑马灯
        else if (e.code === 'KeyE' || e.key === 'e') {
            e.preventDefault();
            showEpgMarquee();
            showKeyFeedback(i18n.t('player_kf_program_info'));
            //showControls();
        }
        // L键：响度均衡切换
        else if (e.code === 'KeyL' || e.key === 'l') {
            e.preventDefault();
            toggleLoudnessEqualizer();
            showKeyFeedback(i18n.t('player_kf_loudness', { STATE: state.isLoudnessEnabled ? i18n.t('player_state_on') : i18n.t('player_state_off') }));
            //showControls();
        }
        // ==================== 新增：T 键开关 AI 字幕翻译 ====================
        else if (e.code === 'KeyT' || e.key.toLowerCase() === 't') {
            if (e.ctrlKey || e.altKey || e.metaKey) return;
            e.preventDefault();
            state.isSubtitleTranslationEnabled = !state.isSubtitleTranslationEnabled;
            if (!state.isSubtitleTranslationEnabled) {
                // 关闭翻译：释放 Chrome 内置 Translator 实例占用的资源
                // （Translator API 实例自带 destroy() 方法），并清空缓存，
                // 下次重新开启时会重新创建 Translator 实例。
                translatorCache.forEach((t) => {
                    if (t && typeof t.destroy === 'function') {
                        try { t.destroy(); } catch (_) {}
                    }
                });
                translatorCache.clear();
                _whisperTransCache.clear();
            }
            const msg = state.isSubtitleTranslationEnabled 
                ? i18n.t('player_ai_subtitle_on') 
                : i18n.t('player_ai_subtitle_off');
            showKeyFeedback(msg);
            showNotification(msg, "info", 1800);
        }
    }
    // 新增：关闭频道列表
    function closePlaylist() {
        // 直接关闭频道列表，不通过 togglePlaylistUI 递归
        // 如果当前焦点在频道列表内，强制让它失焦
        if (document.activeElement && document.activeElement.closest('#playlist-container')) {
            document.activeElement.blur();
        }
        UI.playlistContainer.classList.add("hidden");
        UI.playlistSearchInput.blur();
        UI.playlistSearchInput.style.border = "";
        UI.playlistSearchInput.style.boxShadow = "";
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
        hideEpgPopup(); // 关闭EPG弹出框
        showKeyFeedback(i18n.t('player_kf_close_list'));
        //showControls();
    }
    // 新增：在搜索结果中导航
    function navigateSearchResults(direction) {
        console.log("[NAV START] navigateSearchResults 被调用，direction =", direction);
        // 防护：确保 UI.playlistItems 已初始化
        if (!UI.playlistItems) {
            console.error("[NAV ERROR] UI.playlistItems 未初始化！无法继续导航");
            return;
        }
        const searchTerm = UI.playlistSearchInput.value;
        console.log("[NAV] 当前搜索词：", searchTerm || "(空)");
        // 获取所有可见的 playlist-item
        const filteredItems = Array.from(UI.playlistItems.children)
            .filter(item => item.style.display !== 'none');
        console.log("[NAV] 过滤后可见频道数量：", filteredItems.length);
        if (filteredItems.length === 0) {
            console.log("[NAV] 无可见项，返回");
            return;
        }
        // ────────────── 优先查找 .active（当前播放频道） ──────────────
        let preferredStartIndex = -1;
        // 先找 .active（视觉最可靠）
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].classList.contains('active')) {
                preferredStartIndex = i;
                console.log("[NAV] 从 .active 找到起点，位置：", i, "data-index:", filteredItems[i].dataset.index);
                break;
            }
        }
        // 如果没找到 .active，再用 state.currentPlaylistIndex 匹配
        if (preferredStartIndex === -1 && state.currentPlaylistIndex >= 0) {
            console.log("[NAV] 未找到 .active，使用 state.currentPlaylistIndex =", state.currentPlaylistIndex);
            for (let i = 0; i < filteredItems.length; i++) {
                const itemGlobalIndex = parseInt(filteredItems[i].dataset.index);
                if (itemGlobalIndex === state.currentPlaylistIndex) {
                    preferredStartIndex = i;
                    console.log("[NAV] 从 state.currentPlaylistIndex 匹配到位置：", i);
                    break;
                }
            }
        }
        if (preferredStartIndex === -1) {
            console.log("[NAV] 警告：当前播放频道不在过滤结果中，将从头/尾开始");
        } else {
            console.log("[NAV] preferredStartIndex 最终值：", preferredStartIndex);
        }
        // ────────────── 查找当前 .selected ──────────────
        let currentSelectedIndex = -1;
        for (let i = 0; i < filteredItems.length; i++) {
            if (filteredItems[i].classList.contains('selected')) {
                currentSelectedIndex = i;
                console.log("[NAV] 找到已有 .selected，位置：", i);
                break;
            }
        }
        // ────────────── 决定新选中位置 ──────────────
        let newIndex;
        if (currentSelectedIndex !== -1) {
            // 有 .selected → 正常移动（后续按键）
            newIndex = currentSelectedIndex + direction;
            console.log("[NAV] 从已有 selected 移动，新位置：", newIndex);
        } else {
            // 第一次导航 → 优先选中当前播放频道（.active 或 state）
            if (preferredStartIndex !== -1) {
                newIndex = preferredStartIndex;
                console.log("[NAV] 第一次导航，选中当前播放频道 (preferredStartIndex)：", newIndex);
            } else {
                // 没有当前播放 → fallback 到头或尾
                newIndex = direction > 0 ? 0 : filteredItems.length - 1;
                console.log("[NAV] 无当前播放频道，fallback 到：", newIndex);
            }
        }
        // 环绕处理
        if (newIndex < 0) newIndex = filteredItems.length - 1;
        if (newIndex >= filteredItems.length) newIndex = 0;
        console.log("[NAV] 最终选中索引：", newIndex);
        // 移除所有旧 .selected
        filteredItems.forEach(item => item.classList.remove('selected'));
        // 添加新 .selected
        filteredItems[newIndex].classList.add('selected');
        // 滚动到选中项
        filteredItems[newIndex].scrollIntoView({
            //behavior: 'smooth',
            behavior: 'instant',
            block: 'center'
        });
        // 反馈
        //const itemText = filteredItems[newIndex].textContent.trim();
        const itemText = filteredItems[newIndex].firstChild.textContent.trim();  // 只取第一个文本节点（频道名）
        showKeyFeedback(i18n.t('player_kf_selected', { NAME: itemText }));
        maintainPlaylistFocus();
        console.log("[NAV END] 导航完成");
    }
    // 新增：保持频道列表焦点状态
    function maintainPlaylistFocus() {
        // 如果频道列表可见但焦点不在任何可输入元素上，给频道列表一个虚拟焦点
        if (!UI.playlistContainer.classList.contains("hidden") &&
            document.activeElement !== UI.playlistSearchInput &&
            !document.activeElement.classList.contains('playlist-item')) {
            // 可以给频道列表容器添加一个焦点状态样式
            UI.playlistContainer.classList.add('has-focus');
            // 或者给选中的频道列表项添加焦点
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.focus();
            }
        }
    }
    // 新增：播放选中的搜索结果
    function playSelectedSearchResult() {
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            const index = parseInt(selectedItem.dataset.index);
            if (!isNaN(index)) {
                // 播放选中的项目
                playPlaylistItem(index);
                // 播放后保持选中状态，以便继续使用上下箭头导航
                setTimeout(() => {
                    maintainPlaylistFocus();
                }, 100);
            }
        } else {
            // 如果没有选中项，提示用户
            showKeyFeedback(i18n.t('player_kf_select_first'));
        }
    }
    // 新增：聚焦到频道列表搜索框
    function focusPlaylistSearch() {
        // 首先确保频道列表是可见的
        if (UI.playlistContainer.classList.contains("hidden")) {
            togglePlaylistUI(true);
        }
        // 等待一小段时间确保DOM已更新
        setTimeout(() => {
            // 聚焦到搜索框
            UI.playlistSearchInput.focus();
            // 选中所有文本以便直接输入
            UI.playlistSearchInput.select();
            // 添加一个聚焦样式
            UI.playlistSearchInput.style.border = "2px solid #4dabf7";
            UI.playlistSearchInput.style.boxShadow = "0 0 0 3px rgba(77, 171, 247, 0.3)";
            // 清除任何现有的选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, 50);
    }
    // 修改：使用箭头键调整音量，返回调整结果
    function adjustVolumeByArrow(delta) {
        const oldVolume = UI.videoPlayer.volume;
        let newVolume = oldVolume + delta;
        // 限制在0-1之间
        newVolume = Math.max(0, Math.min(1, newVolume));
        // 检查是否实际发生了变化
        const changed = Math.abs(newVolume - oldVolume) > 0.001;
        if (changed) {
            UI.videoPlayer.volume = newVolume;
            UI.videoPlayer.muted = (newVolume === 0); // 如果音量为0，则静音
            // 更新音量条
            UI.volumeProgress.style.width = newVolume * 100 + "%";
            updateVolumeIcon();
            // 保存音量设置
            chrome.storage.local.set({
                volume: newVolume
            });
        }
        // 返回调整结果
        return {
            changed: changed,
            oldVolume: oldVolume * 100,
            newVolume: Math.round(newVolume * 100)
        };
    }
    /**
     * 反馈提示函数
     * 采用 Web Animations API (WAAPI) 实现，解决连续触发导致的闪烁
     */
    function showKeyFeedback(message) {
        let feedback = playerContainer.querySelector('.key-feedback');
        // 1. 如果不存在则创建，避免重复编写样式字符串
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'key-feedback';
            Object.assign(feedback.style, {
                position: 'absolute',
                bottom: '100px',
                left: '50%',
                transform: 'translateX(-50%)',
                background: 'rgba(0, 100, 200, 0.9)',
                color: 'white',
                padding: '10px 20px',
                borderRadius: '25px',
                fontSize: '14px',
                fontWeight: 'bold',
                zIndex: '1001',
                pointerEvents: 'none',
                boxShadow: '0 4px 12px rgba(0, 100, 200, 0.3)',
                minWidth: '120px',
                textAlign: 'center'
            });
            playerContainer.appendChild(feedback);
        }
        // 2. 更新内容
        feedback.textContent = message;
        // 3. 核心：使用 WAAPI 处理动画
        // 如果当前有正在运行的动画，先取消它
        if (feedback.currentAnimation) {
            feedback.currentAnimation.cancel();
        }
        // 创建新动画：瞬间回到不透明，维持1秒，然后0.3秒淡出
        const animation = feedback.animate([
            { opacity: 1, transform: 'translateX(-50%) scale(1)', offset: 0 },
            { opacity: 1, transform: 'translateX(-50%) scale(1)', offset: 0.8 },
            { opacity: 0, transform: 'translateX(-50%) scale(0.95)', offset: 1 }
        ], {
            duration: 2000,
            easing: 'ease-out',
            fill: 'forwards'
        });
        feedback.currentAnimation = animation;
        animation.onfinish = () => {
            if (animation.playState === 'finished' && feedback.parentNode) {
                feedback.remove();
            }
        };
    }
    // ==================== AI 字幕渲染函数（支持翻译 + 双语显示） ====================
    // 在外部定义持久化缓冲区
    let subtitleBuffer = "";

    // ── 原生隐藏字幕的历史队列 ──────────────────────────────────────
    // 原来的实现是"新 cue 一来就整体替换显示"，导致一段字幕的实际展示时长
    // 完全取决于下一段字幕什么时候出现（说话快时字幕一闪而过）。
    // 现在改成跟 SODA 实时字幕一样的模式：定稿的句子进历史队列，按估算时长
    // 停留一段时间，多条同时在场时纵向堆叠（旧的在上，新的在下），而不是
    // 相互顶替。
    let hlsSubHistory   = [];   // [{text, showAt, hideAt}]
    let hlsPendingText  = '';   // 当前还没定稿（ongoing）的文本，不进历史，随时覆盖显示
    let hlsSubRafId     = null;
    let hlsLastTrackRef = null; // 供语言检测使用的当前活动 track 引用
    let hlsWindowLines  = [];   // 上一次 cuechange 时该 cue 的显示行数组（从上到下），
                                 // 用于识别广播"滚动字幕"（CEA-608 paint-on 风格）的
                                 // 顶部行何时被顶掉——见 bindOneSubtitleTrack() 里的说明
    let hlsLastFinalizedTail = ''; // 最近一次成功定稿推入历史队列的文本，用于防止
                                    // 同一段内容（尤其是流刚开始时）被误判重复定稿
    let hlsFinalizedLen = 0;       // subtitleBuffer 中已经定稿推入历史队列的前缀长度。
                                    // subtitleBuffer 本身只增不减（定稿后不再清空/截断）——
                                    // 因为有些字幕源里"仍在变长的同一行"，它的原始 cue 文本
                                    // 会一直带着已经说完的前缀（比如先出现 "...school."，
                                    // 后面接着长成 "...school. so"），如果定稿时把 buffer
                                    // 截断成只剩 "so"，下一次合并新 cue 时 mergeStreamingCaption
                                    // 找不到这段"已经定稿的前缀"作为参照，会把整段原始文本
                                    // 重新拼接一遍，造成重复。真正"还没定稿"的部分用
                                    // subtitleBuffer.slice(hlsFinalizedLen) 取即可。
    let hlsBracketCandidateLen = -1; // 给"疑似括号/中括号收尾"的边界做二次确认用：
                                      // 记录第一次发现这个疑似边界时 subtitleBuffer 的长度。
                                      // 只有当下一轮检查时 buffer 长度还是这个值（说明中间
                                      // 没有再收到新内容）才真正当作这句话说完了；如果又长
                                      // 出了新内容，说明括号只是插入语的收尾，不是句末，作废
                                      // 重新找。见 findFinalizableBoundary / finalizeIfReady。
    let hlsFlushTimer = null;      // "activeCues 变空"时的宽限期定时器句柄——真实 VTT 里
                                    // 逻辑连续的两条 cue 之间也经常留有几十毫秒的时间轴小
                                    // 间隙（常见于字幕导出工具的一帧误差），不能一看到
                                    // activeCues 变空就立刻强制定稿，否则会把本该连在一起
                                    // 的句子拆成两截。见 bindOneSubtitleTrack 里的说明。
    const HLS_SUB_FLUSH_GRACE_MS = 600; // 宽限期时长：这段时间内如果下一条 cue 到了就取消，
                                         // 真到期了还没有新 cue 才认为这段字幕彻底结束。

    // ── 常见缩写词表：这些词后面跟的 "." 不是句号，不能当句末边界 ──────────
    // 覆盖两类常见缩写：
    //   1. 逐字母缩写，比如 "U.S." "O.K." "a.m." —— 每个字母单独跟一个句点，
    //      不需要词表，靠"句点前只有一个字母"这个规律判断（见下面
    //      isAbbreviationPeriod 里的逻辑）。
    //   2. 整词缩写，比如 "Mr." "Dr." "etc." —— 需要靠词表识别。
    const HLS_ABBREV_WORDS = new Set([
        'mr','mrs','ms','mx','dr','prof','sr','jr','st','mt','ft',
        'vs','etc','eg','ie','al','no','vol','fig','approx',
        'inc','ltd','co','corp','dept','univ','assn','govt','gov',
        'capt','col','gen','lt','sgt','maj','adm','cmdr','rev','hon','pres','sen','rep',
        'ave','blvd','rd','apt','bldg',
        'jan','feb','mar','apr','jun','jul','aug','sep','sept','oct','nov','dec',
        'mon','tue','tues','wed','thu','thurs','fri','sat','sun',
    ]);
    // dotIndex：这个 "." 在 text 里的位置。判断它前面紧跟的"词"是不是缩写。
    const _isAbbreviationPeriod = (text, dotIndex) => {
        let k = dotIndex - 1;
        while (k >= 0 && /[A-Za-z]/.test(text[k])) k--;
        const word = text.slice(k + 1, dotIndex);
        if (!word) return false;
        if (word.length === 1) return true; // 单字母缩写链："U.S." "O.K." "a.m." 里的每一段
        return HLS_ABBREV_WORDS.has(word.toLowerCase());
    };

    // ── "近似重复/修正版本"检测 ──────────────────────────────────────────
    // 有些真实的滚动直播字幕（尤其是实时语音识别）会出现"自我纠正"：同一句话
    // 先给出一个不完整或识别错误的结尾，隔了几条 cue 之后整段重新说一遍、
    // 只改动中间几个词（比如先定稿 "...are them out of the mud."，后面又
    // 整段重新出现、纠正成 "...are bringing them out of the mud."）。这不是
    // 窗口解析的 bug，是字幕源自己在修正，但如果每次都当成新的一句话定稿，
    // 历史队列里就会堆出好几条内容几乎一样、只差几个词的字幕，看起来像重复。
    // 判定"新定稿内容是不是对上一条的修正"，用两条比较宽松但仍然保守的规则：
    //   1. 其中较短的一句，逐字整体是较长那句的前缀或后缀（比如 "them out of
    //      the mud." 完整地是 "There are Helicopters are them out of the
    //      mud." 的后半段）——这种情况措辞完全没变，只是多/少了一截，非常
    //      确定是同一句话，直接判定为修正。
    //   2. 词序重叠比例很高（≥85%，即绝大部分词按原有顺序也出现在另一句
    //      里，只是中间插入/替换了个别词，比如 "are them" 改成 "are
    //      bringing them"）——阈值刻意定得比较高，避免把"开头相同、后面
    //      说的其实是不同内容"的两句话误判成同一句的修正。
    const _isRevisionOfPrevious = (prevText, curText) => {
        const a = String(prevText || '').split(/\s+/).filter(Boolean).map(w => w.toLowerCase());
        const b = String(curText || '').split(/\s+/).filter(Boolean).map(w => w.toLowerCase());
        if (a.length < 3 || b.length < 3) return false; // 太短的话不判断，避免误伤
        const shorter = a.length <= b.length ? a : b;
        const longer  = a.length <= b.length ? b : a;
        const shorterStr = shorter.join(' ');
        if (longer.slice(0, shorter.length).join(' ') === shorterStr) return true; // 前缀
        if (longer.slice(-shorter.length).join(' ') === shorterStr) return true;   // 后缀
        let matched = 0, li = 0;
        for (const w of shorter) {
            const idx = longer.indexOf(w, li);
            if (idx === -1) continue;
            matched++;
            li = idx + 1;
        }
        return matched / shorter.length >= 0.85;
    };

    function _hlsSubDuration(text) {
        // 按字数估算展示时长：短句子给最低 3 秒兜底（读不完），
        // 长句子按字数线性增加，封顶 10 秒（不然会跟下一句叠太久）。
        return Math.min(10, Math.max(3, text.length / 5));
    }

    function _pushHlsSubFinal(text, track) {
        if (!text) return;
        hlsLastTrackRef = track || hlsLastTrackRef;
        const now = UI.videoPlayer.currentTime || 0;
        let hideAt = now + _hlsSubDuration(text);
        // 规则：新字幕的消失时间不能早于上一条（更旧）字幕的消失时间。
        // 否则字数少的新字幕可能比字数多、还在显示中的旧字幕先消失，
        // 堆叠顺序上就会出现"中间那行突然没了"的错位感。
        // 只要每次入队都保证这条不变式，最后一条的 hideAt 天然就是
        // 全队列里最大的，只需要跟上一条比较（O(1)），不用扫全表。
        const prev = hlsSubHistory[hlsSubHistory.length - 1];
        if (prev && hideAt < prev.hideAt) hideAt = prev.hideAt;
        hlsSubHistory.push({ text, showAt: now, hideAt });
        // 历史条数上限，防止长时间不清空导致数组无限增长
        if (hlsSubHistory.length > 30) hlsSubHistory.splice(0, hlsSubHistory.length - 30);
    }

    // 跟 SODA 实时字幕共用同一份译文缓存（_whisperTransCache，文本→译文，
    // 目标语言现在跟随浏览器语言（getSubtitleTargetLang()）而不是写死中文，
    // 但同一个播放会话里目标语言只在启动时确定一次，不会中途变化，所以两边
    // 共用缓存仍然是安全的），源语言走的是 VTT 字幕自己的
    // 语言检测结果（globalDetectedLang），跟 SODA 的识别语言（state.whisper.language）
    // 是两回事，所以不能直接复用 _translateWhisperSeg，单独写一份。
    async function _translateHlsSeg(entry) {
        const text = entry.text;
        const cached = _whisperTransCache.get(text);
        if (cached !== undefined) return cached;
        _whisperTransCache.set(text, 'pending');
        try {
            let currentSourceLang = globalDetectedLang || 'en';
            if (!globalDetectedLang && detectionCount < MAX_DETECTIONS && hlsLastTrackRef) {
                detectionCount++;
                const result = await getDetectedResult(hlsLastTrackRef, text);
                if (result && result.confidence >= CONFIDENCE_THRESHOLD) {
                    globalDetectedLang = result.detectedLanguage;
                    currentSourceLang = globalDetectedLang;
                }
            }
            if (currentSourceLang === getSubtitleTargetLang()) { _whisperTransCache.set(text, 'same'); return 'same'; }
            const trans = await getTranslatorForSource(currentSourceLang);
            if (!trans) { _whisperTransCache.set(text, 'same'); return 'same'; }
            const contextTexts = _getContextTextsFor(hlsSubHistory, entry, WHISPER_TRANSLATION_CONTEXT_LENGTH);
            const translated = contextTexts.length
                ? await _translateWithContext(trans, contextTexts, text)
                : await trans.translate(text);
            const result = (translated && translated.trim() && translated.trim() !== text)
                ? 'OK:' + translated.trim() : 'same';
            _whisperTransCache.set(text, result);
            return result;
        } catch (e) {
            _whisperTransCache.delete(text);
            return 'same';
        }
    }

    // ── 打字机（流式显示）效果 ────────────────────────────────────────────
    // 原来的渲染是：字幕文本一变（整句进来 / 一段新内容拼上来 / 定稿），整段文字
    // 直接一下子出现在屏幕中间。现在改成逐字打出来：
    //   · 每条定稿字幕、以及还没定稿的 pending 文本，各自记录"已经显示了多少个
    //     字符"（_twRev / hlsPendingRev），每一帧按速度往前推进；
    //   · 还没打到的部分不是不渲染，而是用 visibility:hidden 占位——字幕框的宽度
    //     和居中位置从一开始就是整句的，逐字打出来时不会因为每多一个字就整体左右
    //     晃动；
    //   · 译文（双语显示时）接在原文后面继续打，不会一下子冒出来；
    //   · pending 定稿成历史条目时，已经打出来的字符数会被"认领"过去，不会重新
    //     从头再打一遍；文本被修正（ASR 自我纠正等）时，只保留还匹配的前缀。
    // 想关掉这个效果把 HLS_SUB_TYPEWRITER 改成 false 即可；速度可以调下面两个常量。
    // 译文（双语显示时）可以单独关掉打字机：HLS_SUB_TYPEWRITER_TRANS 改成 false 后，
    // 原文仍然逐字打出，译文则不参与打字，翻译一好就整段直接显示（总开关
    // HLS_SUB_TYPEWRITER 为 false 时，这个开关不起作用，原文译文都是直接显示）。
    const HLS_SUB_TYPEWRITER      = true;
    const HLS_SUB_TYPEWRITER_TRANS = false;
    const HLS_SUB_TYPE_CPS        = 45;  // 基础打字速度：每秒多少个字符
    const HLS_SUB_TYPE_MAX_LAG_S  = 1.0; // 积压太多时自动加速，保证大约这么多秒内追上，
                                         // 避免长句子（或整段 pop-on 字幕）一直打不完

    let hlsPendingRev = 0;       // pending 文本当前已显示的字符数（浮点，按帧推进）

    function _twCommonPrefix(a, b) {
        const n = Math.min(a.length, b.length);
        let i = 0;
        while (i < n && a.charCodeAt(i) === b.charCodeAt(i)) i++;
        return i;
    }
    // 把"已显示 n 个字符"换算成不会把代理对（emoji 等）或 <br> 标签从中间切断的位置
    function _twCut(text, n) {
        n = Math.floor(n);
        if (n >= text.length) return text.length;
        if (n <= 0) return 0;
        const c = text.charCodeAt(n - 1);
        if (c >= 0xD800 && c <= 0xDBFF) n++;
        const lt = text.lastIndexOf('<', n - 1);
        if (lt !== -1 && text.startsWith('<br>', lt) && n < lt + 4) n = lt + 4;
        return Math.min(n, text.length);
    }
    // 一段文字按已显示字符数拆成"已显示 + 隐藏占位"两部分
    function _twSplitHtml(text, rev) {
        const cut = _twCut(text, rev);
        const shown = text.slice(0, cut);
        const rest  = text.slice(cut);
        return rest ? `${shown}<span style="visibility:hidden">${rest}</span>` : shown;
    }
    // 取某段文本当前可用的译文（没有或还没翻译好返回空字符串）
    function _hlsTransOf(text) {
        if (state.isSubtitleTranslationEnabled && translatorSupported) {
            const cached = _whisperTransCache.get(text);
            if (cached && cached !== 'pending' && cached !== 'same') return cached.slice(3);
        }
        return '';
    }
    // rev 是"原文 + 译文"合起来已经打出的字符数：先打原文，原文打完再接着打译文
    function _hlsSegHtmlTyped(text, rev) {
        const trans = _hlsTransOf(text);
        if (!HLS_SUB_TYPEWRITER) rev = Infinity;
        if (!trans) return `<span class="subtitle-text">${_twSplitHtml(text, rev)}</span>`;
        // 译文单独关了打字机：整段直接显示（不跟原文的打字进度走）
        const transRev = HLS_SUB_TYPEWRITER_TRANS ? rev - text.length : Infinity;
        return `<span class="subtitle-text">${_twSplitHtml(text, rev)}<br>` +
               `<span class="translated-subtitle">${_twSplitHtml(trans, transRev)}</span></span>`;
    }

    // 同时在场的定稿字幕行数上限，防止说话很快时把整个画面糊满
    const HLS_SUB_MAX_VISIBLE = 2;

    function _startHlsSubRaf() {
        if (hlsSubRafId) return;
        let _lastFinalsKey = '';
        let _lastCombined  = '';
        let _twLastMs      = performance.now();
        let _twPrevPending = '';   // 上一帧的 pending 文本（用来认领"已经打出的字符数"）
        let _twCps         = HLS_SUB_TYPE_CPS; // 当前打字速度（积压大时会被抬高，积压清空后恢复）

        function resetTypewriterState() {
            _twPrevPending = '';
            hlsPendingRev = 0;
            _twCps = HLS_SUB_TYPE_CPS;
        }

        function tick() {
            const now = UI.videoPlayer.currentTime || 0;
            if (hlsSubHistory.length) {
                hlsSubHistory = hlsSubHistory.filter(s => s.hideAt >= now - 5);
            }
            let finals = hlsSubHistory.filter(s => s.showAt <= now && s.hideAt >= now);
            if (finals.length > HLS_SUB_MAX_VISIBLE) {
                finals = finals.slice(finals.length - HLS_SUB_MAX_VISIBLE);
            }

            // 在场的定稿集合变了就触发翻译（译文写进缓存，下一帧渲染时自然会取到，
            // 已翻译好的段落不会因为新加入一段没翻译的就被打回原文——跟 SODA 字幕
            // 踩过的同一个闪烁坑，这里从一开始就避开）。
            const finalsKey = finals.map(s => s.text).join('\n');
            if (finalsKey !== _lastFinalsKey) {
                _lastFinalsKey = finalsKey;
                if (state.isSubtitleTranslationEnabled && translatorSupported && finals.length) {
                    const pending = finals.filter(s => _whisperTransCache.get(s.text) === undefined);
                    if (pending.length) Promise.all(pending.map(s => _translateHlsSeg(s)));
                }
            }

            if (finals.length === 0 && !hlsPendingText) {
                if (_lastCombined !== '') {
                    UI.subDisplay.innerHTML = '';
                    _lastCombined = '';
                }
                resetTypewriterState();
                _twLastMs = performance.now();
            } else {
                // ── 1. 认领：新出现的定稿条目，从上一帧 pending 里接手已经打出的字符数 ──
                let remText = _twPrevPending;
                let remRev  = hlsPendingRev;
                for (const e of finals) {
                    if (e._twText === undefined) {
                        e._twRev = 0;
                        const t = e.text;
                        const lead = remText.length - remText.trimStart().length;
                        const body = remText.slice(lead);
                        const p = _twCommonPrefix(body, t);
                        // 定稿内容是 pending 的开头一段（或 pending 还没长到这么长）才算"同一段"
                        if (p > 0 && p >= Math.min(t.length, body.length)) {
                            e._twRev = Math.min(Math.max(0, remRev - lead), p);
                            const consumed = lead + (p === t.length ? t.length : body.length);
                            remText = remText.slice(consumed);
                            remRev  = Math.max(0, remRev - consumed);
                        }
                        e._twText = t;
                    } else if (e._twText !== e.text) {
                        // 文本被原位修正（比如 ASR 自我纠正），只保留还匹配的前缀
                        e._twRev = Math.min(e._twRev, _twCommonPrefix(e._twText, e.text));
                        e._twText = e.text;
                    }
                }
                // pending 自己：跟（扣掉被定稿条目认领之后剩下的）上一帧 pending 对齐
                {
                    const P2 = hlsPendingText;
                    if (!P2) {
                        hlsPendingRev = 0;
                    } else {
                        const lead = remText.length - remText.trimStart().length;
                        const p = _twCommonPrefix(remText.slice(lead), P2);
                        hlsPendingRev = Math.min(Math.max(0, remRev - lead), p);
                    }
                }

                // ── 2. 推进：按速度往前打字，从最早的一段开始依次打 ──
                const segs = finals.map(e => ({
                    // 译文单独关了打字机时，只有原文需要逐字打，译文不计入进度
                    total: e.text.length + (HLS_SUB_TYPEWRITER_TRANS ? _hlsTransOf(e.text).length : 0),
                    get: () => e._twRev, set: v => { e._twRev = v; }
                }));
                if (hlsPendingText) {
                    segs.push({
                        total: hlsPendingText.length,
                        get: () => hlsPendingRev, set: v => { hlsPendingRev = v; }
                    });
                }
                const nowMs = performance.now();
                const dt = Math.min(Math.max((nowMs - _twLastMs) / 1000, 0), 0.1);
                _twLastMs = nowMs;
                let backlog = 0;
                for (const sg of segs) backlog += Math.max(0, sg.total - sg.get());
                // 速度只升不降，直到积压清空：如果每帧都按"当前积压÷时限"算，积压越
                // 小速度越慢，会呈指数衰减，永远追不上；锁定住新内容刚进来时算出的
                // 速度，才能保证大约 HLS_SUB_TYPE_MAX_LAG_S 秒内线性打完。
                if (backlog <= 0) _twCps = HLS_SUB_TYPE_CPS;
                else _twCps = Math.max(_twCps, backlog / HLS_SUB_TYPE_MAX_LAG_S);
                let budget = _twCps * dt;
                for (const sg of segs) {
                    const need = sg.total - sg.get();
                    if (need <= 0) continue;
                    if (!HLS_SUB_TYPEWRITER) { sg.set(sg.total); continue; }
                    const add = Math.min(need, budget);
                    sg.set(sg.get() + add);
                    budget -= add;
                    if (budget <= 0) break;
                }
                _twPrevPending = hlsPendingText;

                // ── 3. 渲染 ──
                const finalsHtml = finals.map(e => _hlsSegHtmlTyped(e.text, e._twRev)).join('');
                const pendingHtml = hlsPendingText
                    ? `<span class="subtitle-text pending">${_twSplitHtml(hlsPendingText, HLS_SUB_TYPEWRITER ? hlsPendingRev : Infinity)}</span>` : '';
                const combined = finalsHtml + pendingHtml;
                if (combined !== _lastCombined) {
                    _lastCombined = combined;
                    UI.subDisplay.innerHTML = combined;
                }
            }
            hlsSubRafId = requestAnimationFrame(tick);
        }
        hlsSubRafId = requestAnimationFrame(tick);
    }

    function _stopHlsSubRaf() {
        if (hlsSubRafId) { cancelAnimationFrame(hlsSubRafId); hlsSubRafId = null; }
    }

    function _resetHlsSubHistory() {
        hlsSubHistory  = [];
        hlsPendingText = '';
        subtitleBuffer = '';
        hlsWindowLines = [];
        hlsLastFinalizedTail = '';
        hlsFinalizedLen = 0;
        hlsBracketCandidateLen = -1;
        hlsPendingRev = 0;
        if (hlsFlushTimer) {
            clearTimeout(hlsFlushTimer);
            hlsFlushTimer = null;
        }
    }

    /**
     * 增量/滚动字幕合并（替换原来"只比对首尾一个单词"的朴素拼接逻辑）
     * 兼容两种常见的字幕推送模式：
     *   模式一：每次把当前完整句子原样重发再变长（新闻直播"滚动字幕"常见），
     *          如 "i will" -> "i will go to school" -> "i will go to school for study."
     *          —— incoming 是 buffer 的"生长版"，直接用 incoming 替换即可，不能再拼接。
     *   模式二：识别引擎偶尔回退重发一个比当前缓冲区更短/更旧的片段
     *          —— 保留已有的更长文本，忽略这次。
     *   模式三：真正的增量 delta（每次只发新增的一小段）
     *          —— 在词级别找 buffer 结尾与 incoming 开头的最长重叠，只拼接真正新增的部分
     *          （不再局限于只比较一个单词，避免重叠 2~3 个词时被错误处理）。
     *   模式四：确认没有任何重叠关系的独立新内容 —— 直接拼接。
     */
    function mergeStreamingCaption(buffer, incoming) {
        incoming = String(incoming || '').trim();
        if (!incoming) return buffer;
        buffer = String(buffer || '').trim();
        if (!buffer) return incoming;

        if (incoming.startsWith(buffer)) return incoming; // 模式一
        if (buffer.startsWith(incoming)) return buffer;    // 模式二

        // filter(Boolean) 去掉因为多个/首尾空白产生的空 token——不然 tail/head
        // 对齐会因为一个多余的空字符串整体错开一位，明明有完整重叠也匹配不上，
        // 退化到模式四整段拼接，把已经出现过的内容重复接一遍。
        const bufferWords = buffer.split(/\s+/).filter(Boolean);
        const incomingWords = incoming.split(/\s+/).filter(Boolean);
        const maxCheck = Math.min(bufferWords.length, incomingWords.length);

        // 模式三 + 模式三':词级重叠比对。对每个候选长度 k（从长到短，优先取最长
        // 的重叠），要求重叠区间前 k-1 个词逐字完全相同；最后一个词额外允许
        // "还在长"的情况——即 buffer 侧的词是 incoming 侧对应词的前缀（比如
        // 广播字幕逐字母吐词，"heartbrea" 后面几条 cue 接着长成 "heartbreak"）。
        // 这不是两个不同的词，是同一个词还没打完，必须用 incoming 里更完整的
        // 版本替换掉 buffer 里那个半截词，而不是当成两个词都保留、拼出
        // "heartbrea heartbreak" 这种重复。之所以允许"最后一个词"而不是只看
        // 重叠区间第一个词，是因为这个还没打完的词不一定正好在重叠区间开头
        // （比如 "their heartbrea" 长成 "their heartbreak on"，没打完的词
        // 排在重叠区间第二位，前面还有一个已经完全匹配的 "their"）。
        for (let k = maxCheck; k > 0; k--) {
            const tailWords = bufferWords.slice(-k);
            const headWords = incomingWords.slice(0, k);
            let prefixOk = true;
            for (let i = 0; i < k - 1; i++) {
                if (tailWords[i] !== headWords[i]) { prefixOk = false; break; }
            }
            if (!prefixOk) continue;

            const tailLast = tailWords[k - 1];
            const headLast = headWords[k - 1];
            if (tailLast === headLast) {
                const remainder = incomingWords.slice(k).join(' ');
                // 没有真正新增内容时原样返回 buffer，不要额外拼一个空格上去——
                // 哪怕这个空格看似无害，攒上几十次之后 split(/\s+/) 就会在 buffer
                // 尾部产生空 token，后面每一次合并的词级对齐都会被带偏。
                return remainder ? buffer + ' ' + remainder : buffer;
            }
            if (tailLast.length >= 2 && headLast !== tailLast &&
                headLast.toLowerCase().startsWith(tailLast.toLowerCase())) {
                // 只有严格前缀（长度至少 2）才处理，避免把单字母词（比如 "a"
                // 后面恰好接一个也以 "a" 开头的新词）误判成同一个词在长。
                const prefix = bufferWords.slice(0, bufferWords.length - k).join(' ');
                return (prefix ? prefix + ' ' : '') + incomingWords.join(' ');
            }
        }
        return buffer + ' ' + incoming; // 模式四
    }

    /**
     * 给单个原生字幕 TextTrack 绑定 oncuechange 处理逻辑。
     * 从 bindSubtitleEvents() 的循环体中抽出来，方便在 addtrack 事件里
     * （见 initHlsPlayer 中的兜底监听）对新出现的 track 单独补绑。
     *
     * 不同字幕源的 cue 组织方式差异很大，这里按"这次 cue 跟上一次是什么关系"
     * 分三种情况处理：
     *
     *   情形 A · 广播"滚动字幕"（CEA-608 paint-on 风格）：cue 是一个最多两行的
     *   滚动窗口快照——第一行是上一句已经"定型"、即将被顶掉的文本（静止不变），
     *   第二行是当前正在逐词变长的文本。识别依据是结构关系（新顶部==旧底部 /
     *   顶部不变底部在长 / 底部不变行数在减），而不是字符串相似度——因为这类
     *   源经常用 ">>" 这种所有新句子都共享的前缀，字符串前缀匹配会误判。
     *   只展示窗口最后一行；行数增加时说明上一次的底部已经不会再变，并入 buffer
     *   走"是否够格定稿"的判断。
     *
     *   情形 B · 单行原地生长：没有多行窗口，但当前行是上一行的延伸（比如
     *   "i will" -> "i will go to school"），逐字变长后原地替换整条 cue。
     *
     *   情形 C · 普通/不相关字幕：跟上一条 cue 没有直接结构关系的字幕——可能是
     *   全新独立的一句（典型点播字幕，每条 cue 是一句完整的话，可能因为宽度
     *   限制换行成多行，这些行属于同一句，要整体拼接，不能像情形 A 那样只取
     *   最后一行），也可能是上一句还没说完、这条接着补全（没有标点结尾的
     *   一条会一直拼接下一条，直到遇到以标点结尾的一条才整体定型——跟原版
     *   逻辑保持一致，不在这里强制提前收口）。
     *
     *   为避免流刚开始时第一条 cue 恰好是"已经两行"的普通字幕、随后又被
     *   误判成情形 A 的延续而重复定稿，用 hlsLastFinalizedTail 记录最近一次
     *   已经推入历史的文本，情形 A 合并前检查是否已经包含过。
     */
    function bindOneSubtitleTrack(track) {
        track.mode = 'hidden';
        track.oncuechange = null;
        track.oncuechange = (e) => {
            const activeCues = e.target.activeCues;
            // 1. 如果当前没有活跃字幕，且缓冲区已清空，清掉"未定稿"文本
            //    （已定稿、进了历史队列的字幕不受影响，该显示多久继续显示多久）
            if (!activeCues || activeCues.length === 0) {
                // 不能一看到 activeCues 变空就立刻强制定稿——真实 VTT 里，即便是
                // 逻辑上连续、该合并成一句的两条 cue（比如同一句话中途被切成
                // 两段），时间轴上也经常留有几十毫秒的小间隙（常见于字幕导出
                // 工具的一帧误差），这段间隙里 activeCues 会短暂变空。如果这时
                // 候就把还没定稿的内容强制切断，"...and the insurance" 和
                // "will be paid off to you." 这种本该连在一起的句子就会被拆成
                // 两截。改成：先记下"现在开始 activeCues 空了"，给一个短暂的
                // 宽限期（HLS_SUB_FLUSH_GRACE_MS）——宽限期内如果下一条 cue 就
                // 来了，说明只是正常的小间隙，取消这次强制定稿，交给下一条
                // cue 的内容自己决定要不要合并；只有宽限期真的到了、还是没有
                // 新 cue 出现，才认为这段字幕真的彻底结束了，把剩下的内容强制
                // 定稿。宽限期内暂时保留原来的 pending 展示，不提前清空，避免
                // 正常小间隙之间出现闪烁。
                if (!hlsFlushTimer) {
                    hlsFlushTimer = setTimeout(() => {
                        hlsFlushTimer = null;
                        const leftover = subtitleBuffer.slice(hlsFinalizedLen).trim();
                        if (leftover) {
                            // 这一行字幕真的彻底消失、不会再有后续内容了——不管有没有
                            // 遇到真正的句末标点（包括之前"疑似括号收尾、还在等下一轮
                            // 确认"的情况），直接把剩下的内容整体定稿，避免永远卡在
                            // "未定稿"状态一直挂在屏幕上不消失。同样要判断一下是不是
                            // 对上一条的修正。
                            const prevHist = hlsSubHistory[hlsSubHistory.length - 1];
                            if (prevHist && _isRevisionOfPrevious(hlsLastFinalizedTail, leftover)) {
                                prevHist.text = leftover;
                            } else {
                                _pushHlsSubFinal(leftover, track);
                            }
                            hlsLastFinalizedTail = leftover;
                            hlsFinalizedLen = subtitleBuffer.length;
                        }
                        hlsBracketCandidateLen = -1;
                        hlsPendingText = '';
                    }, HLS_SUB_FLUSH_GRACE_MS);
                }
                return;
            }
            // 有新的 active cue 了，说明刚才 activeCues 变空只是正常的时间轴小
            // 间隙，不是真的结束——取消宽限期定时器，避免它稍后误触发把这句
            // 已经在继续的内容强制切断。
            if (hlsFlushTimer) {
                clearTimeout(hlsFlushTimer);
                hlsFlushTimer = null;
            }
            // 2. 同一时刻通常只有一个 active cue；如果有多个，取时间上最新的一个
            //    （TextTrackCueList 按时间排序，最后一个即最新）
            const cue = activeCues[activeCues.length - 1];
            const rawLines = String(cue.text || '')
                .split('\n')
                .map(line => cleanSubtitleText(line))
                .filter(Boolean);
            if (rawLines.length === 0) return;

            // 2.5 特殊情况优先处理：整条 cue 就是一个方括号/圆括号音效或动作
            //     标注（比如 "[clicks]"、"[audience laughs]"、"(applause)"），
            //     前后不带任何台词文字。这类标注是独立的旁注，不是台词的一
            //     部分，不能被下面的窗口合并逻辑跟前后台词粘在一起——不然会
            //     出现 "[clicks] [audience laughs] So I thought to myself..."
            //     这种音效和台词混成一段的情况（常见于传统"逐条弹出式"VTT，
            //     每条 cue 本身已经是完整独立的一段，不是持续增长的同一句）。
            //     检测到就直接：先把当前还没定稿的内容（如果有）整体定稿，
            //     再把这条标注单独定稿，然后清空 buffer 重新开始，完全不参与
            //     后面的情形 A/B/C 窗口结构判断。
            const wholeCueText = rawLines.join(' ').trim();
            if (/^(\[[^\]]*\]|\([^)]*\))$/.test(wholeCueText)) {
                const pendingLeftover = subtitleBuffer.slice(hlsFinalizedLen).trim();
                if (pendingLeftover) {
                    const prevHist1 = hlsSubHistory[hlsSubHistory.length - 1];
                    if (prevHist1 && _isRevisionOfPrevious(hlsLastFinalizedTail, pendingLeftover)) {
                        prevHist1.text = pendingLeftover;
                    } else {
                        _pushHlsSubFinal(pendingLeftover, track);
                    }
                    hlsLastFinalizedTail = pendingLeftover;
                }
                const prevHist2 = hlsSubHistory[hlsSubHistory.length - 1];
                if (prevHist2 && _isRevisionOfPrevious(hlsLastFinalizedTail, wholeCueText)) {
                    prevHist2.text = wholeCueText;
                } else {
                    _pushHlsSubFinal(wholeCueText, track);
                }
                hlsLastFinalizedTail = wholeCueText;
                subtitleBuffer = '';
                hlsFinalizedLen = 0;
                hlsBracketCandidateLen = -1;
                hlsWindowLines = rawLines;
                hlsPendingText = '';
                return;
            }

            const prevLines  = hlsWindowLines;
            const prevBottom = prevLines.length ? prevLines[prevLines.length - 1] : '';
            const prevTop    = prevLines.length ? prevLines[0] : '';
            const newTop     = rawLines[0];
            const newBottom  = rawLines[rawLines.length - 1];

            // 判断某段文本是否已经被计入过（在当前未定稿部分里，或者已经
            // 是最近一次推入历史的文本的一部分），避免重复合并/重复定稿
            const isAlreadyAccounted = (text) => {
                if (!text) return true;
                const pending = subtitleBuffer.slice(hlsFinalizedLen);
                if (pending && (pending === text || pending.endsWith(text))) return true;
                if (!pending && hlsLastFinalizedTail && hlsLastFinalizedTail.endsWith(text)) return true;
                return false;
            };
            // ── 判定"这段话是否已经说完，可以先切一段出去定稿" ───────────────
            // 规则：
            //   · 句末标点（. ! ? 。！？ …）本身，只要前面有实际文字内容，出现在
            //     文本中的任何位置都当作句末边界——出现在中间就说明这里确实是
            //     一句话说完了，后面是新的一句。
            //   · 小括号 ")"、右中括号 "]"（含全角 ）】）本身也算句末标点，但只有
            //     它出现在"当前已知文本的末尾"（后面还没有更多内容）时才当作句子
            //     说完了——比如 "(applause)" 收尾。如果它出现在句子中间、后面还
            //     跟着别的字词（比如 "he said (laughs) that was funny" 里的
            //     "(laughs)"），说明只是插入语，这句话其实还没说完，不能在这里
            //     切断。（若右括号后面紧跟的就是真正的句末标点，比如 "(laughs)."，
            //     两者会被当成一个整体的边界，不受这条限制。）
            //   · 常见缩写（Mr. / Dr. / etc. / U.S. / O.K. / a.m. 这类）后面的
            //     "." 不算句末——不管是整词缩写（查词表）还是逐字母缩写（句点前
            //     只有一个字母，比如 "U.S." 里的每一段），都会跳过继续找下一个
            //     真正的句末标点。
            //   · ">>" 说话人切换标记：只要它不在整段文本最开头（说明前面还
            //     有内容），就当作"新一段话"的起点——它之前的内容先定稿，它
            //     自己和后面的内容留给下一段继续攒。
            // 用 "+" 把连续的句末符号（比如省略号 "..." "。。。"）当成一个整体
            // 处理，避免把 "..." 拆成 "." + ".." 两截、切出一条内容只有句号的
            // 空字幕；同时要求边界前面必须有真正的文字/数字内容才算数——纯标点
            // （比如单独出现的省略号）不能自己充当一句独立的话，跳过继续找下一个
            // 真正带内容的边界。
            // 找的是"最靠左（最早出现）"的边界，而不是整个 buffer 结尾是否为
            // 标点——因为持续变长的字幕经常是 "i will go to" -> "i will go to
            // school. so" 这种情况：句号出现在文本中间，后面 "so" 已经是还没
            // 说完的新句子，只看结尾会漏掉中间这个已经完成的句子，导致一大段
            // 文字堆到最后才一次性定稿。
            const TERMINAL_RE = /([.!?…。！？)\]）】]+)(["'”’)\]）】]*)/gu;
            const BRACKET_ONLY_RE = /^[)\]）】]+$/; // 这个匹配是不是"纯右括号/右中括号"
            const CONTENT_RE = /[\p{L}\p{N}]/u;      // 是否包含真正的文字/数字（而非纯标点）
            const findFinalizableBoundary = (text) => {
                TERMINAL_RE.lastIndex = 0;
                let m;
                while ((m = TERMINAL_RE.exec(text))) {
                    const core = m[1]; // 主体符号，比如 "." "!" ")" "..."（不含追加的引号/括号）
                    const end = m.index + m[0].length;
                    if (!CONTENT_RE.test(text.slice(0, end))) continue; // 前面全是标点，跳过
                    if (core === '.' && _isAbbreviationPeriod(text, m.index)) continue; // 缩写词的句点，跳过
                    // 小数点不是句号："18.8"、"0.2"、".5" 里的 "." 后面紧跟数字，
                    // 真正的句号后面只会是空白、引号或文本结束，不会直接接数字。
                    if (core === '.' && /\d/.test(text[m.index + 1] || '')) continue;
                    // 数字后面的句点恰好出现在当前文本的最末尾时，无法判断它是句号
                    // （"…collect $250,000."）还是小数点才打到一半（"18." 马上要长成
                    // "18.8"）——标记为"疑似"，不立即定稿，交给 finalizeIfReady 做
                    // 二次确认；如果后面接着长出了数字，下一轮检查时上面那条规则
                    // 自然会把它跳过。
                    const tentative = core === '.' && end === text.length &&
                        /\d/.test(text[m.index - 1] || '');
                    const bracketOnly = BRACKET_ONLY_RE.test(core);
                    if (bracketOnly && end !== text.length) continue; // 纯括号且后面还有内容，跳过
                    return { boundary: end, bracketOnly, tentative };
                }
                const arrowIdx = text.indexOf('>>');
                if (arrowIdx > 0 && CONTENT_RE.test(text.slice(0, arrowIdx))) {
                    return { boundary: arrowIdx, bracketOnly: false }; // ">>" 边界：切到它之前
                }
                return null;
            };
            const finalizeIfReady = () => {
                // 注意：这里不再把 subtitleBuffer 清空/截断成"剩余部分"——
                // subtitleBuffer 只增不减，靠 hlsFinalizedLen 指针记录"到哪里
                // 为止已经定稿"。原因见 hlsFinalizedLen 声明处的注释：有些
                // 还在变长的字幕行，它的原始 cue 文本会一直带着已经说完的
                // 前缀，如果把 buffer 截断，下一次合并新 cue 时就找不到这段
                // 前缀作参照，会把整段原始文本重新拼接一遍，造成重复。
                //
                // 循环切分：一次 merge 可能一口气带进来多个已经说完的边界
                // （见上面 "i will go to school. so" 的例子），所以要反复切，
                // 不能只判断一次。
                while (true) {
                    const pending = subtitleBuffer.slice(hlsFinalizedLen);
                    const pendingTrimmed = pending.trim();
                    if (!pendingTrimmed) { hlsBracketCandidateLen = -1; return; }
                    if (pendingTrimmed.length >= 300) {
                        // 兜底：一直没遇到边界也不能让未定稿部分无限增长
                        hlsLastFinalizedTail = pendingTrimmed;
                        _pushHlsSubFinal(pendingTrimmed, track);
                        hlsFinalizedLen = subtitleBuffer.length;
                        hlsBracketCandidateLen = -1;
                        return;
                    }
                    const found = findFinalizableBoundary(pending);
                    if (!found) { hlsBracketCandidateLen = -1; return; } // 还没说完，继续攒着等下一条 cue

                    if (found.bracketOnly || found.tentative) {
                        // 括号/中括号收尾、或数字后面的句点（可能是小数点打到一半）
                        // 都只是"疑似"句末——第一次发现时先记下来，
                        // 不立即定稿；只有下一轮检查时 subtitleBuffer 长度还是
                        // 老样子（说明这中间确实没有再收到新内容），才真的确认
                        // 这句话说完了。不然像 "he said (with a laugh) that he
                        // was fine." 这种括号后面还会接着长出新内容的情况，会把
                        // 插入语的收尾误判成整句话说完。
                        if (hlsBracketCandidateLen !== subtitleBuffer.length) {
                            hlsBracketCandidateLen = subtitleBuffer.length;
                            return;
                        }
                    } else {
                        hlsBracketCandidateLen = -1; // 真正的句末标点/说话人切换，不需要二次确认
                    }

                    const finalPart = pending.slice(0, found.boundary).trim();
                    // 指针推进：boundary 是相对 pending（= subtitleBuffer 从
                    // hlsFinalizedLen 开始的切片）的偏移量，直接累加到指针上
                    // 即为在 subtitleBuffer 里的新位置，不受 trim() 影响。
                    hlsFinalizedLen += found.boundary;
                    if (!finalPart) continue; // 边界前全是空白，跳过继续找下一个边界
                    // 句子定稿：推入历史队列，交给 rAF 渲染循环按估算时长展示，
                    // 翻译也由渲染循环统一处理（带缓存，避免闪烁）。
                    // 但如果这段内容跟上一条已定稿的内容高度重叠（很可能是同一句话
                    // 的语音识别修正版本，见 _isRevisionOfPrevious 的注释），就直接
                    // 替换上一条历史记录的文本，不再单独展示一条几乎一样的字幕。
                    const prevHist = hlsSubHistory[hlsSubHistory.length - 1];
                    if (prevHist && _isRevisionOfPrevious(hlsLastFinalizedTail, finalPart)) {
                        prevHist.text = finalPart;
                    } else {
                        _pushHlsSubFinal(finalPart, track);
                    }
                    hlsLastFinalizedTail = finalPart;
                }
            };

            // 情形 A：滚动字幕窗口的顶部被顶掉/换新
            const isRollingSlide = !!prevBottom && (
                (rawLines.length > prevLines.length && newTop === prevBottom) ||
                (rawLines.length === prevLines.length && rawLines.length > 1 && newTop === prevTop) ||
                (rawLines.length <= prevLines.length && rawLines.length > 0 && newBottom === prevBottom)
            );
            // 情形 B：没有多行窗口，但单行内容是上一行的延伸
            const isSingleLineGrowth = !isRollingSlide && rawLines.length === 1 && prevLines.length === 1 &&
                newBottom !== prevBottom && (newBottom.startsWith(prevBottom) || prevBottom.startsWith(newBottom));

            hlsWindowLines = rawLines;

            // 不管是哪种情形，现在统一把"这一次真正新出现的内容"实时并入
            // subtitleBuffer——不再像以前那样在"行数不变、只是最后一行在变长"
            // 期间让 buffer 停在旧值、只更新一个临时的 pending 文本。这样每次
            // cue 来了都能立刻用 finalizeIfReady() 检查一遍是否出现了新的定稿
            // 边界（句末标点/右括号/">>" 说话人切换），既不会漏检，也不会因为
            // buffer 和展示文本长期不同步而在拼接时把重叠部分显示两遍。
            if (isRollingSlide) {
                if (rawLines.length > prevLines.length && !isAlreadyAccounted(prevBottom)) {
                    // 窗口新长出一行，说明上一次的底部行已经不会再变了，先并入 buffer
                    subtitleBuffer = mergeStreamingCaption(subtitleBuffer, prevBottom);
                }
                subtitleBuffer = mergeStreamingCaption(subtitleBuffer, newBottom);
            } else if (isSingleLineGrowth) {
                subtitleBuffer = mergeStreamingCaption(subtitleBuffer, newBottom);
            } else {
                // 情形 C：跟上一条没有直接结构关系的新字幕——可能是全新独立的一句，
                // 也可能是上一句还没说完、这条接着把它补完（比如 "I want to know"
                // 后面接 "where Sean Miller and Kevin O'Donnell are."）。把这条 cue
                // 的所有行整体拼接后并入 buffer，是否定稿交给 finalizeIfReady() 判断。
                subtitleBuffer = mergeStreamingCaption(subtitleBuffer, rawLines.join(" "));
            }
            finalizeIfReady();
            hlsPendingText = subtitleBuffer.slice(hlsFinalizedLen).trim();
        };
    }

    /**
     * 绑定视频字幕事件（遍历当前已存在的 track）。
     * 注意：hls.js 1.7.x 起原生字幕轨道改为真正插入 <track> DOM 元素，
     * 浏览器把它加入 video.textTracks 列表是异步的，不保证这里同步遍历时
     * 已经能读到刚创建的 track——所以还需要 initHlsPlayer 里的 'addtrack'
     * 兜底监听（见下方），对之后才出现的 track 单独补绑。
     */
    const bindSubtitleEvents = () => {
        const video = UI.videoPlayer;
        const tracks = video.textTracks;
        // 进度跳转时必须清空，否则会把旧句子的结尾拼到新句子的开头，
        // 历史队列里跳转前遗留的字幕也要一并清掉。跟 attachCommonVideoEvents()
        // 共用同一个 handleVideoSeeked，见该函数定义处的注释。
        video.onseeked = handleVideoSeeked;
        for (let i = 0; i < tracks.length; i++) {
            bindOneSubtitleTrack(tracks[i]);
        }
        _startHlsSubRaf();
    };
    /**
     * 辅助工具：清洗字幕文本，处理对话格式
     */
    function cleanSubtitleText(text) {
        if (!text) return '';
        // 先去掉 WebVTT 提示文本里的行内标签标记，比如样式/着色标签
        // <c.white><c.bg_black>...</c></c>、<b> <i> <u>、说话人标签
        // <v Speaker Name>、逐词计时用的时间戳标签 <00:00:01.234> 等——这些
        // 都是 WebVTT 官方允许的行内标注语法，不是纯文本内容的一部分。
        // 有些字幕源（尤其是从广播闭路字幕转出来的）还会用形如
        // <c.white>       </c> 这种只包起一串空格的标签，作为"占位/清掉
        // 残留字符"的视觉技巧；如果不在这里先剥掉标签，这些标签会原样保留在
        // 行文本里，污染后面所有基于行文本做的结构比较（新旧顶部/底部是否
        // 相等）、mergeStreamingCaption 的分词、以及句末标点/缩写的匹配。
        const stripped = text.replace(/<[^>]*>/g, '');
        const dialogRegex = /\n(?=\s*([-—–]|>>|[^:\n：]+\s*[:：]))/g;
        return stripped.trim()
            .replace(dialogRegex, '[DIALOG_BR]')
            .replace(/\n/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .replace(/\[DIALOG_BR\]/g, '<br>');
    }
    // ==================== 键盘事件处理结束 ====================
    // 新增：加载EPG数据
    async function loadEPG(nocache = false) {
        if (!CONFIG.EPG_ENABLED) return;
        try {
            state.lastEpgRefreshTime = Date.now(); // 更新上次刷新时间
            console.log('[EPG] 开始加载:', CONFIG.EPG_URL, nocache ? '(忽略缓存)' : '');
            // 修改点：根据 nocache 参数配置 fetch 选项
            const fetchOptions = nocache ? { cache: 'reload' } : {};
            const response = await fetch(CONFIG.EPG_URL, fetchOptions);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status} - ${response.statusText}`);
            }
            let text;
            // 判断是否需要解压（根据 Content-Type 或文件后缀）
            const contentType = response.headers.get('content-type') || '';
            const isGzipped = 
                contentType.includes('gzip') || 
                contentType.includes('application/gzip') ||
                CONFIG.EPG_URL.toLowerCase().endsWith('.gz');
            if (isGzipped && 'DecompressionStream' in window) {
                console.log('[EPG] 检测到 gzip 压缩，使用 DecompressionStream 解压');
                const buffer = await response.arrayBuffer();
                const decompressedStream = new Response(
                    new Blob([buffer]).stream().pipeThrough(
                        new DecompressionStream('gzip')
                    )
                );
                text = await decompressedStream.text();
            } else {
                // 普通文本或已自动解压的情况
                text = await response.text();
            }
            const parser = new DOMParser();
            const xml = parser.parseFromString(text, 'text/xml');
            // 检查解析是否成功
            if (xml.getElementsByTagName('parsererror').length > 0) {
                throw new Error('XML 解析失败，可能文件格式错误或未正确解压');
            }
            // ==================== 原有解析逻辑 ====================
            const channels = xml.getElementsByTagName('channel');
            state.channelMap = {}; // name.lower -> id (备用匹配)
            for (let ch of channels) {
                const id = ch.getAttribute('id');
                const displayName = ch.querySelector('display-name')?.textContent?.trim();
                if (displayName && id) {
                    state.channelMap[displayName.toLowerCase()] = id;
                }
            }
            const programmes = xml.getElementsByTagName('programme');
            state.epgData = {};
            for (let prog of programmes) {
                const channelId = prog.getAttribute('channel');
                if (!state.epgData[channelId]) state.epgData[channelId] = [];
                const startStr = prog.getAttribute('start');
                const stopStr = prog.getAttribute('stop');
                const start = parseEpgTime(startStr);
                const stop = parseEpgTime(stopStr);
                const titleElem = prog.querySelector('title');
                const title = titleElem?.textContent?.trim() || i18n.t('player_unknown_program');
                state.epgData[channelId].push({ start, stop, title });
            }
            // 按开始时间排序
            for (let id in state.epgData) {
                state.epgData[id].sort((a, b) => a.start - b.start);
            }
            console.log(`[EPG] 加载完成，共 ${Object.keys(state.epgData).length} 个频道节目表`);
            // 新增: 计算EPG到期时间（最晚节目结束时间）
            calculateEpgExpiry();
            // 新增: 启动到期前刷新定时器
            scheduleEpgRefresh();
        } catch (err) {
            console.error('[EPG] 加载失败:', err);
        }
    }
    // 新增：计算EPG到期时间
    function calculateEpgExpiry() {
        let maxStop = 0;
        for (let id in state.epgData) {
            const programs = state.epgData[id];
            if (programs.length > 0) {
                const lastStop = programs[programs.length - 1].stop;
                if (lastStop > maxStop) maxStop = lastStop;
            }
        }
        state.epgExpiryTime = maxStop;
        console.log(`[EPG] 计算到期时间: ${new Date(maxStop).toLocaleString()}`);
    }
    // 新增：调度EPG刷新（到期前1小时刷新）
    function scheduleEpgRefresh() {
        // 1. 清理现有定时器，确保不重叠
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            state.timers.epgRefresh = null;
        }
        // 2. 前置检查
        if (!CONFIG.EPG_ENABLED || state.epgExpiryTime <= 0) return;
        const now = Date.now();
        const timeToExpiry = state.epgExpiryTime - now;
        // 计算触发更新的目标时间点：过期前1小时 (3600000 ms)
        // 如果现在已经进入了过期前1小时，则目标延迟为 0
        const targetTriggerDelay = Math.max(timeToExpiry - 3600000, 0);
        // 设置触发器
        state.timers.epgRefresh = setTimeout(() => {
            const currentTime = Date.now();
            const timeSinceLastRefresh = currentTime - state.lastEpgRefreshTime;
            // 3. 触发时检查：是否满足最小刷新间隔
            if (timeSinceLastRefresh >= MIN_EPG_REFRESH_INTERVAL) {
                console.log('[EPG] 满足刷新条件（进入过期预警期且已过最小间隔），开始更新...');
                loadEPG(true);
            } else {
                // 4. 不满足间隔：计算还需等待多久并安排补跳
                const remainingWait = MIN_EPG_REFRESH_INTERVAL - timeSinceLastRefresh;
                console.log(`[EPG] 触发太频繁，等待最小间隔：还需 ${Math.round(remainingWait / 1000)} 秒后补刷`);
                // 覆盖当前的 timer，确保最后一次补刷能执行
                state.timers.epgRefresh = setTimeout(() => {
                    console.log('[EPG] 最小间隔已满，执行补刷...');
                    loadEPG(true);
                }, remainingWait);
            }
        }, targetTriggerDelay);
        if (targetTriggerDelay > 0) {
            console.log(`[EPG] 调度成功：将于 ${Math.round(targetTriggerDelay / 3600000 * 10) / 10} 小时后尝试触发更新`);
        } else {
            console.log('[EPG] 处于过期预警期，尝试立即触发检查');
        }
    }
    // 新增：解析EPG时间字符串到时间戳
    function parseEpgTime(timeStr) {
        if (!timeStr) return 0;
        const year = timeStr.substring(0, 4);
        const month = timeStr.substring(4, 6);
        const day = timeStr.substring(6, 8);
        const hour = timeStr.substring(8, 10);
        const min = timeStr.substring(10, 12);
        const sec = timeStr.substring(12, 14);
        const tz = timeStr.substring(14).trim() || '+0000';
        const dateStr = `${year}-${month}-${day}T${hour}:${min}:${sec}${tz.replace(' ', '')}`;
        const ts = Date.parse(dateStr);
        return isNaN(ts) ? 0 : ts;
    }
    // 新增：格式化时间戳为本地时间字符串
    function formatEpgTime(ts) {
        if (!ts) return i18n.t('player_unknown');
        const date = new Date(ts);
        return date.toLocaleTimeString(i18n.locale === 'zh_CN' ? 'zh-CN' : 'en-US', {hour: '2-digit', minute: '2-digit'});
    }
    /**
     * 精准清洗频道名称（修复CCTV10科教频道匹配问题）
     * @param {string} name - 原始频道名称
     * @returns {string} 清洗后的名称
     */
    function cleanName(name) {
        if (!name || typeof name !== 'string') return "";
        let cleaned = name
            .toLowerCase()
            .replace(/\s+/g, "")
            .replace(/[^\w\+\-\u4e00-\u9fa5]/g, "")
            .trim();
        // 统一符号
        cleaned = cleaned.replace(/plus/g, '+');
        console.log(`[EPG调试] 清洗: "${name}" -> "${cleaned}"`);
        // ========== 特殊频道映射表 ==========
        const specialChannels = {
            // 4K/8K超高清频道
            'cctv4k': 'cctv4k',
            'cctv8k': 'cctv8k',
            'cctv4k超高清': 'cctv4k',
            'cctv8k超高清': 'cctv8k',
            'cctv-4k': 'cctv4k',
            'cctv-8k': 'cctv8k',
            // 错误名称修正
            'cctv-': 'cctv',
            'cctv_': 'cctv',
            'cctv ': 'cctv',
            // 其他特殊处理
            'cctv4k+': 'cctv4k+',
            'cctv8k+': 'cctv8k+',
            'cctv5+体育赛事': 'cctv5+',
            'cctv5+': 'cctv5+',
            'cctv4欧洲': 'cctv4欧洲',
            'cctv4美洲': 'cctv4美洲',
            '文化精品':'央视文化精品',
            'cctv文化精品':'央视文化精品'
        };
        // 先检查特殊频道映射
        if (specialChannels[cleaned]) {
            console.log(`[EPG调试] 特殊频道映射: "${cleaned}" -> "${specialChannels[cleaned]}"`);
            return specialChannels[cleaned];
        }
        // ========== 正则匹配 ==========
        // 1. 4K/8K频道（优先于数字频道）
        const hdMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(4k|8k)(\+)?$/i);
        if (hdMatch) {
            const result = hdMatch[1] + hdMatch[2] + (hdMatch[3] || '');
            console.log(`[EPG调试] 4K/8K频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 2. 带+号的数字频道
        const plusMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)\+$/i);
        if (plusMatch) {
            const result = plusMatch[1] + plusMatch[2] + '+';
            console.log(`[EPG调试] 带+号频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 3. 普通数字频道
        const numberMatch = cleaned.match(/^(cctv|channel|tv)[\-_]?(\d+)/i);
        if (numberMatch) {
            const result = numberMatch[1] + numberMatch[2];
            console.log(`[EPG调试] 数字频道: "${cleaned}" -> "${result}"`);
            return result;
        }
        // 4. CCTV+中文
        if (cleaned.startsWith('cctv')) {
            const withoutCctv = cleaned.substring(4);
            if (withoutCctv && /^[\u4e00-\u9fa5]+$/.test(withoutCctv)) {
                console.log(`[EPG调试] CCTV+中文: "${cleaned}" -> "${withoutCctv}"`);
                return withoutCctv;
            }
        }
        // 5. 后缀处理
        const suffixes = [
            '超高清', '高清', '标清', 'hd', 'sd', 'fhd', 'uhd',
            '台', '频道', 'channel', 'tv'
        ];
        for (const suffix of suffixes) {
            if (cleaned.endsWith(suffix)) {
                const result = cleaned.slice(0, -suffix.length);
                console.log(`[EPG调试] 去除后缀: "${cleaned}" -> "${result}"`);
                // 如果去除后缀后是空字符串，返回原始
                if (!result) {
                    console.log(`[EPG调试] 警告: 去除后缀后为空，返回原始: "${cleaned}"`);
                    return cleaned;
                }
                return result;
            }
        }
        console.log(`[EPG调试] 最终结果: "${cleaned}"`);
        return cleaned;
    }
    // 新增：获取频道ID
    function getChannelId(item) {
        let prechId = item.attributes ? item.attributes['tvg-id'] : '';
        let chId = cleanName(prechId);
        if (!chId) {
            const nameLower = cleanName(item.title || '');
            chId = state.channelMap[nameLower] || nameLower; // 如果没有匹配，用name作为fallback
        }
        return chId;
    }
    // 新增：获取当前节目
    function getCurrentProgram(programs) {
        const now = Date.now();
        return programs.find(p => now >= p.start && now < p.stop) || null;
    }
    // 新增：获取接下来几个节目
    function getNextPrograms(programs, num = 3) {
        const now = Date.now();
        const future = programs.filter(p => p.start > now).sort((a, b) => a.start - b.start);
        return future.slice(0, num);
    }
    // 新增：显示EPG弹出框（智能自适应位置，避免被边缘挡住）
    function showEpgPopup(itemEl, item) {
        if (!CONFIG.EPG_ENABLED) return;
        // 先隐藏旧的弹出框（如果存在）
        if (epgPopup) hideEpgPopup();
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const next = getNextPrograms(programs, 10);
        if (!current && next.length === 0) return;
        // 使用全局的 playerContainer（已在 init 中赋值）
        if (!playerContainer) {
            console.warn("playerContainer 未初始化，无法显示 EPG 弹出框");
            return;
        }
        epgPopup = document.createElement('div');
        epgPopup.className = 'epg-popup';
        let html = '';
        // 第一行显示频道名称
        const channelName = item.title || i18n.t("player_unknown_channel");
        html += `<div style="color: #FFFFFF; font-weight: bold; font-size: 14px; margin-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.2); padding-bottom: 4px;">${channelName}</div>`;
        // 当前节目
        if (current) {
            html += `
            <div class="epgpopup-row">
                <div class="epgpopup-info-part">
                    <span style="color: #4CAF50; font-weight: bold;">${i18n.t('player_epg_current_label')}</span> 
                    <span class="epg-text-info">[${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)}]</span>
                </div>
                <div class="epgpopup-title-part">${current.title}</div>
            </div>`;
        }
        // 后续节目
        next.forEach((p, i) => {            
            const hideLater = i > 0 ? 'style="visibility: hidden;"' : '';
            html += `
            <div class="epgpopup-row">
                <div class="epgpopup-info-part">
                    <span ${hideLater} style="color: #FFA500; font-weight: bold;">${i18n.t('player_epg_later_label')}</span> 
                    <span class="epg-text-info">[${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)}]</span>
                </div>
                <div class="epgpopup-title-part">${p.title}</div>
            </div>`;
        });
        epgPopup.innerHTML = html;
        // 先隐藏，添加到 playerContainer 以正确计算尺寸
        epgPopup.style.visibility = 'hidden';
        playerContainer.appendChild(epgPopup);
        // 使用 requestAnimationFrame 确保布局计算准确
        requestAnimationFrame(() => {
            // 获取频道项相对于视口的 rect
            const itemRect = itemEl.getBoundingClientRect();
            // 获取 playerContainer 相对于视口的 rect
            const containerRect = playerContainer.getBoundingClientRect();
            // 获取频道列表容器相对于视口的 rect
            const playlistRect = UI.playlistContainer.getBoundingClientRect();
            // 计算相对于 playerContainer 的坐标
            const relativeTop = itemRect.top - containerRect.top;
            const playlistRelativeLeft = playlistRect.left - containerRect.left;
            // 获取弹出框自身的尺寸
            const popupRect = epgPopup.getBoundingClientRect();
            const containerHeight = playerContainer.clientHeight;
            const margin = 8; // 目标间隔 8px
            // 核心逻辑：右边缘固定在频道列表左侧 8px 处
            // left = 频道列表左边界 - 弹窗宽度 - 间隔
            let left = playlistRelativeLeft - popupRect.width - margin;
            let top = relativeTop;
            // 垂直方向智能调整（保持原有的垂直逻辑，确保不超出容器）
            const spaceBelow = containerHeight - (relativeTop + itemRect.height);
            if (spaceBelow < popupRect.height && relativeTop > popupRect.height) {
                // 下方空间不足且上方空间足够，则向上对齐
                top = relativeTop + itemRect.height - popupRect.height;
            }
            // 最终边界保护（防止弹出框超出容器顶部或底部）
            top = Math.max(10, Math.min(top, containerHeight - popupRect.height - 10));
            // 应用位置和样式
            epgPopup.style.position = 'absolute';
            epgPopup.style.right = `${containerRect.right - playlistRect.left + margin}px`;
            epgPopup.style.left = 'auto'; // 确保 left 不干扰 right 定位
            epgPopup.style.top = `${top}px`;
            epgPopup.style.visibility = 'visible';
            // 其他视觉样式（建议后续可移到 CSS 类中统一管理）
            epgPopup.style.maxHeight   = `${containerHeight * 0.75}px`;
            epgPopup.style.overflowY   = 'auto';
            epgPopup.style.maxWidth    = '340px';
            epgPopup.style.minWidth    = 'auto'; // 允许根据内容收缩
            epgPopup.style.background  = 'rgba(59,59,68,0.88)';
            epgPopup.style.color       = 'rgb(239, 239, 241)';
            epgPopup.style.padding     = '12px';
            epgPopup.style.borderRadius = '8px';
            epgPopup.style.zIndex      = '1001';
            epgPopup.style.boxShadow   = '0 6px 20px rgba(0,0,0,0.6)';
        });
    }
    // 新增：隐藏EPG弹出框
    function hideEpgPopup() {
        if (epgPopup) {
            // 确保它确实在 playerContainer 里（可选，但推荐）
            if (epgPopup.parentNode === playerContainer) {
                epgPopup.remove();
            } else if (epgPopup.parentNode) {
                // 如果不在预期位置，也强制移除
                epgPopup.parentNode.removeChild(epgPopup);
                console.warn("epgPopup 被挂载到了非预期的父节点，已强制移除");
            } else {
                // 已经不在 DOM 中，直接置空
                console.warn("epgPopup 已不在 DOM 中");
            }
            epgPopup = null;
        }
    }
    /**
     * EPG 跑马灯函数
     * 改进：消除强制重绘，使用 WAAPI 精准控制动画生命周期
     */
    function showEpgMarquee() {
        // 1. 基础拦截逻辑 (保持不变)
        if (!CONFIG.EPG_ENABLED) {
            showNotification(i18n.t('player_epg_not_enabled'), 'warning', 2000);
            return;
        } else if (!state.isM3UPlaylist) {
            showNotification(i18n.t('player_not_playlist_mode'), 'warning', 2000);
            return;
        }
        if (state.isMarqueeActive) return;
        // 2. 数据准备
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        const chId = getChannelId(item);
        const programs = state.epgData[chId] || [];
        const current = getCurrentProgram(programs);
        const nextProgs = getNextPrograms(programs, 2);
        const chName = state.currentChannelInfo?.title || item?.title || i18n.t("player_unknown_channel");
        const currentTime = getCurrentTimeStr('time');
        const spacing = '\u00A0'.repeat(8); // 使用 Unicode 空格，避免 innerHTML 注入风险
        // 3. 构建 HTML 内容 
        let htmlContent = current ? `
            <span class="epg-text-normal">${currentTime}</span>
            <span class="epg-text-ch">【${chName}】</span>
            <span class="epg-text-playing">${i18n.t('player_epg_now_playing', { TITLE: current.title })}</span> 
            <span class="epg-text-info">(${formatEpgTime(current.start)} - ${formatEpgTime(current.stop)})</span>${spacing}` 
            : '';
        nextProgs.forEach((p, i) => {
            const className = i === 0 ? 'epg-text-next' : 'epg-text-later';
            const label = i === 0 ? i18n.t('player_epg_upcoming_next', { TITLE: p.title }) : i18n.t('player_epg_upcoming_later', { TITLE: p.title });
            htmlContent += `<span class="${className}">${label}</span> 
                            <span class="epg-text-info">(${formatEpgTime(p.start)} - ${formatEpgTime(p.stop)})</span>${spacing}`;
        });
        if (!htmlContent) {
            showNotification(i18n.t('player_no_program_info'), 2000);
            return;
        }
        // 4. 创建 DOM (一次性构建)
        const container = document.createElement('div');
        container.className = 'epg-marquee-container active'; // 初始即 active
        const content = document.createElement('span');
        content.className = 'epg-marquee-content';
        content.style.fontSize = `${CONFIG.MARQUEE_FONT_SIZE}px`;
        content.innerHTML = htmlContent;
        container.appendChild(content);
        playerContainer.appendChild(container);
        // 5. 核心：无需测量，直接动画
        // 我们让内容从容器 100% 处移动到 -100% 处
        const containerWidth = container.clientWidth;
        const contentWidth = content.offsetWidth; // 此时元素已在文档流中，读取宽度
        const speed = CONFIG.MARQUEE_SPEED || 110;
        const duration = ((containerWidth + contentWidth) / speed) * 1000;
        state.isMarqueeActive = true;
        // 6. 使用 WAAPI 执行动画
        const animation = content.animate([
            { transform: `translateX(${containerWidth}px)` },
            { transform: `translateX(-${contentWidth}px)` }
        ], {
            duration: duration,
            easing: 'linear',
            fill: 'forwards'
        });
        // 7. 动画结束后的清理逻辑 (精准且优雅)
        animation.onfinish = () => {
            // 先淡出容器
            const fadeOut = container.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 400, fill: 'forwards' });
            fadeOut.onfinish = () => {
                if (container.parentNode) container.remove();
                state.isMarqueeActive = false;
            };
        };
        //showKeyFeedback(i18n.t('player_kf_program_info'));
    }
    /**
     * 获取当前时间/日期字符串
     * @param {string} mode - 模式: 'datetime'(默认), 'date', 'time'
     * @param {string} separator - 日期和时间之间的分隔符，默认为空格
     * @returns {string} 格式化后的字符串
     */
    function getCurrentTimeStr(mode = 'datetime', separator = ' ') {
        const d = new Date();
        // 1. 获取并格式化日期部分 (YYYY-MM-DD)
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        // 2. 获取并格式化时间部分 (HH:mm)
        const hours = String(d.getHours()).padStart(2, '0');
        const minutes = String(d.getMinutes()).padStart(2, '0');
        const timeStr = `${hours}:${minutes}`;
        // 3. 根据模式返回对应格式
        switch (mode) {
            case 'date':
                return dateStr;
            case 'time':
                return timeStr;
            case 'datetime':
            default:
                return `${dateStr}${separator}${timeStr}`;
        }
    }
    function init() {
        playerContainer = document.querySelector(".player-container");
        if (!playerContainer) {
            console.error("找不到 .player-container 元素");
            return;
        }
        checkTranslatorSupport();
        addStyles();
        createDynamicUI();
        loadVolumeSettings();
        loadSettings(); // 从 storage 加载用户设置
        loadBlacklist(); // 加载黑名单
        parseInitialUrl();
        initGlobalEvents();
        addButtonHoverEffects();
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
        }
        if (CONFIG.EPG_ENABLED && state.isM3UPlaylist) {
            loadEPG();
        }
        updateSearchPlaceholder();
    }
    function addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .control-btn {
              background: none;
              border: none;
              color: white;
              cursor: pointer;
              padding: 5px;
              font-size: 16px;
              opacity: 1;
              transition: opacity 0.2s ease;
            }
            .control-btn:disabled {
                opacity: 0.4;
                cursor: not-allowed;
            }
            .advanced-panel {
                position: absolute;
                bottom: 60px;
                right: 20px;
                background: rgba(20,20,30,0.95);
                border-radius: 8px;
                padding: 12px 16px;
                min-width: 240px;
                max-width: 320px;
                box-shadow: 0 6px 24px rgba(0,0,0,0.7);
                backdrop-filter: blur(8px);
                border: 1px solid rgba(255,255,255,0.12);
                z-index: 150;
                color: white;
                font-size: 13px;
            }
            /*进阶设置面板限高*/
            .advanced-panel {
                /* 设置最大高度，防止超出容器 */
                max-height: 80%; 
                /* 核心：内容过多时显示垂直滚动条 */
                overflow-y: auto; 
                /* 避免内容紧贴边缘 */
                padding-right: 5px; 
                /* 确保面板在容器内定位正确（如果需要） */
                position: absolute;
                z-index: 1000;
            }            
            /* 优化滚动条样式（可选） */
            .advanced-panel::-webkit-scrollbar {
                width: 5px;
            }
            .advanced-panel::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 3px;
            }
            .advanced-panel::-webkit-scrollbar-track {
              background: transparent; /* 轨道透明 */
              border-radius: 3px;
            }
            .advanced-panel::-webkit-scrollbar-thumb:hover {
              background: rgba(255, 255, 255, 0.5); /* 鼠标悬停时滑块加亮 */
            }
            .section {
                margin: 12px 0;
            }
            .section-title {
                color: #4dabf7;
                font-weight: bold;
                margin-bottom: 6px;
                font-size: 14px;
            }
            .option-item {
                padding: 6px 10px;
                cursor: pointer;
                border-radius: 4px;
                margin: 2px 0;
                transition: all 0.15s;
            }
            .option-item:hover {
                background: rgba(77,171,247,0.25);
            }
            .option-item.active {
                background: rgba(77,171,247,0.45);
                font-weight: 500;
            }
            .option-item.disabled {
                color: #777;
                cursor: not-allowed;
                pointer-events: none;
            }
            .switch-source-btn:hover {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
                transform: scale(1);
                transition: all 0.2s ease;
            }
            .switch-source-btn:active {
                transform: scale(1);
                transition: all 0.1s ease;
            }
            /* info-panel 样式 */
            /* 信息面板主容器 */
            .info-panel {
                display: none; /* 默认隐藏，由 JS 控制显示 */
                position: absolute;
                right: 350px !important;
                left: auto !important;
                bottom: 60px;
                z-index: 20;
                /* 现代玻璃拟态视觉 */
                background: rgba(59, 59, 68, 0.85) !important;
                backdrop-filter: blur(12px) saturate(160%);
                -webkit-backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 8px;
                padding: 14px 18px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
                /* 网格布局核心：第一列自适应宽度，第二列填充 */
                display: grid;
                grid-template-columns: auto 1fr;
                column-gap: 8px; /* 冒号与数值之间的间距 */
                row-gap: 6px;     /* 行与行之间的间距 */
                font-size: 13px;
                line-height: 1.4;
                pointer-events: none; /* 防止面板遮挡点击 */
            }
            /* 强制覆盖 grid 行为，当 JS 设置 display: grid 时生效 */
            .info-panel[style*="display: block"],
            .info-panel[style*="display: inline-grid"] {
                display: grid !important;
            }
            /* 每一行的容器 */
            .info-row {
                display: contents; /* 关键：使子元素直接参与父级 Grid 布局 */
            }
            /* 标签组：包含文字和冒号 */
            .info-label-group {
                grid-column: 1;      /* 占据网格第一列 */
                display: flex;
                justify-content: flex-start;
                align-items: center;
                white-space: nowrap;
            }
            .info-label {
                color: #4dabf7;      /* 蓝色标签 */
                font-weight: 500;
                text-shadow: 0 0 1px rgba(0, 0, 0, 0.3); 
                letter-spacing: -0.02em;
                text-rendering: optimizeLegibility;
            }
            .info-colon {
                color: #20c997;      /* 青色冒号 */
                margin-left: 2px;    /* 紧贴标签文字 */
            }
            /* 数值对齐：占据第二列 */
            .info-value {
                grid-column: 2;      /* 占据网格第二列 */
                color: #efeff1;
                /*font-weight: 600;*/
                /*font-family: 'Consolas', 'Monaco', monospace;*/ /* 等宽字体保证数值对齐美观 */
                text-align: left;
                text-shadow: 0 0 1px rgba(0, 0, 0, 0.3); 
                letter-spacing: -0.02em;
                text-rendering: optimizeLegibility;
            }
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translate(-50%, -10px); }
                15% { opacity: 1; transform: translate(-50%, 0); }
                85% { opacity: 1; transform: translate(-50%, 0); }
                100% { opacity: 0; transform: translate(-50%, -10px); }
            }
            .blacklist-error {
                background: linear-gradient(135deg, #ff6b6b, #c92a2a) !important;
                border: 2px solid #ff6b6b !important;
                color: white !important;
                font-weight: bold !important;
                padding: 15px !important;
                border-radius: 8px !important;
            }
            /* 新增：键盘反馈动画 */
            @keyframes keyFeedbackFlash {
                0% { transform: translateX(-50%) scale(0.9); opacity: 0; }
                15% { transform: translateX(-50%) scale(1.1); opacity: 1; }
                30% { transform: translateX(-50%) scale(1); opacity: 1; }
                85% { transform: translateX(-50%) scale(1); opacity: 1; }
                100% { transform: translateX(-50%) scale(0.9); opacity: 0; }
            }
            .key-feedback {
                animation: keyFeedbackFlash 1s ease;
            }
            /* 快捷键提示样式 */
            .shortcut-hint {
                position: absolute;
                top: 5px;
                right: 10px;
                background: rgba(0, 0, 0, 0.7);
                color: #aaa;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 11px;
                z-index: 10;
                cursor: help;
                transition: all 0.3s ease;
            }
            .shortcut-hint:hover {
                background: rgba(0, 0, 0, 0.9) !important;
                color: white;
                transform: scale(1.05);
            }
            /* 快捷键提示更新 */
            .shortcut-hint table tr td:first-child b {
                color: #4dabf7;
            }
            /* 搜索框聚焦样式 */
            .playlist-search:focus {
                border-color: #4dabf7 !important;
                box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.3) !important;
                outline: none !important;
            }
            /* 新增：搜索结果选中样式 */
            .playlist-item.selected {
                position: relative; /* 必须：作为伪元素的定位基准 */
                background: linear-gradient(180deg, #000000, #000000) !important;
                color: white !important;
                font-weight: bold !important;
                /*border-left: 4px solid #f59f00 !important;*/
                border-left: none !important; 
                outline: none !important; /* 彻底移除边框 */
                outline-offset: -2px;
            }
            .playlist-item.selected::before {
              content: "";
              position: absolute;
              left: 0;
              top: 0;
              bottom: 0;
              width: 4px; /* 侧边条宽度 */
              background: #f59f00;
              /* 可选：让侧边条稍微圆润一点 */
              border-radius: 2px 0 0 2px;
              /* 增加微弱的外发光 */
              box-shadow: 1px 0 4px rgba(0, 0, 0, 0.1);
            }    
            .playlist-item.selected:hover {
                background: linear-gradient(135deg, #339af0, #1864ab) !important;
            }
            /* 频道列表焦点状态 */
            #playlist-container:focus-within {
                border-color: #4dabf7;
            }
            .playlist-item:focus {
                outline: none !important; /* 彻底移除蓝色边框 */
                outline-offset: -2px;
            }
            /* 核心修复：确保容器有高度且允许滚动 */
            #playlist-container {
                overflow-y: auto !important; /* 强制开启垂直滚动 */
                scrollbar-width: thin;
                scrollbar-color: rgba(255, 255, 255, 0.5) transparent;
            }
            /* 音量极限状态提示 */
            @keyframes limitFlash {
                0% { transform: translateX(-50%) scale(1); }
                50% { transform: translateX(-50%) scale(1.1); background: rgba(255, 59, 48, 0.9); }
                100% { transform: translateX(-50%) scale(1); }
            }
            .volume-limit {
                animation: limitFlash 0.5s ease;
            }
            /* 新增：当前节目样式 */
            .current-program {
                display: block;
                font-size: 0.8em;
                color: #aaa;
                margin-top: 2px;
            }
            /* 新增：EPG弹出框样式 */
            .epg-popup {
                transition: opacity 0.2s ease, top 0.2s ease; /* 移除对 width 的过渡，防止跳动 */
                max-width: 340px;
                font-size: 12px;
                line-height: 1.2;
                box-sizing: border-box;
            }
            .epgpopup-row {
                display: flex;
                align-items: flex-start; /* 顶部对齐 */
                line-height: 1.2;
                margin-bottom: 5px;
                font-size: 12px; /* 根据需要调整 */
                width: 100%; /* 确保容器占满 */
            }
            .epgpopup-info-part {
                flex-shrink: 0; /* 防止时间部分被压缩 */
                margin-right: 5px;
                white-space: nowrap; /* 保证时间不换行 */
            }
            .epgpopup-title-part {
                flex: 1; /* 占据剩余空间 */
                word-break: break-all; /* 允许在长单词内换行 */
                border-bottom: 1px dashed rgba(255, 255, 255, 0.2);
                padding-bottom: 0px;
                text-shadow: 0 0 1px rgba(0, 0, 0, 0.3); 
                letter-spacing: -0.02em;
                text-rendering: optimizeLegibility;
            }
            /* 最后一个标题去掉下划线，保持清爽 */
            .epgpopup-row:last-of-type .epgpopup-title-part {
                border-bottom: none;
            }
            /* 跑马灯外层容器：负责位置和毛玻璃质感 */
            .epg-marquee-container {
                position: absolute;
                top: 15px;
                left: 50%;
                transform: translateX(-50%);
                width: 90%;
                max-width: 1200px;
                z-index: 1000;
                overflow: hidden; /* 必须保留，裁切溢出文字 */
                pointer-events: none;
                user-select: none;
                /* 胶囊风格外观 */
                background: rgba(59, 59, 68, 0.85);
                backdrop-filter: blur(12px) saturate(160%);
                -webkit-backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 50px; /* 彻底圆角化，更现代化 */
                /* 两端渐变遮罩：让文字进入和消失时产生“隐现”效果 */
                mask-image: linear-gradient(90deg, 
                    transparent 0%, 
                    black 5%, 
                    black 95%, 
                    transparent 100%
                );
                -webkit-mask-image: linear-gradient(90deg, 
                    transparent 0%, 
                    black 5%, 
                    black 95%, 
                    transparent 100%
                );
                opacity: 0;
                transition: opacity 0.4s ease;
            }
            .epg-marquee-container.active {
                opacity: 1;
            }
            /* 跑马灯内容：只负责文字样式，不负责布局占位 */
            .epg-marquee-content {
                display: inline-block;
                white-space: nowrap;
                padding: 8px 0; /* 垂直间距，通过 JS 动态计算也可以 */
                will-change: transform;
                font-weight: 500;
                color: #ffffff;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
                /* 强制重置起点坐标 */
                position: relative;
                left: 0;
            }
            /* 清理辅助类：将 JS 里的内联颜色统一到这里 */
            .epg-text-time { color: rgba(255, 255, 255, 0.6); font-size: 0.9em; }
            .epg-text-ch { color: #ffffff; font-weight: bold; padding: 0 5px; }
            .epg-text-normal { color: #ffffff; font-size: 0.9em; }
            .epg-text-playing { color: #00FF7F; } /* 正在播放：绿色 */
            .epg-text-next { color: #FFD700; }    /* 下一个：金色 */
            .epg-text-later { color: #FFA500; }   /* 稍后：橙色 */
            .epg-text-info { color: #AAAAAA; font-size: 0.9em; }
            /* Whisper 字幕：原文（金色）*/
            .whisper-orig {
                color: #FFD700;
                display: block;
            }
            /* Whisper 字幕：译文（浅蓝，稍小）*/
            .whisper-trans {
                color: #a0d0ff;
                font-size: 0.92em;
                display: block;
                margin-top: 4px;
            }
            /* HLS 字幕翻译样式（保持原样）*/
            .translated-subtitle {
                color: #a0d0ff;
                font-size: 0.92em;
                opacity: 0.92;
                display: block;
                margin-top: 4px;
            }
        `;
        document.head.appendChild(style);
    }
    function createDynamicUI() {
        UI.loudnessBtn = document.createElement("button");
        UI.loudnessBtn.className = "loudness-btn";
        UI.loudnessBtn.innerHTML = "<svg viewBox='0 0 24 24' width='18' height='18' fill='currentColor' style='vertical-align: middle;'><path d='M12 .99C5.92 .99 1 5.92 1 11.99C1 18.07 5.92 22.99 12 22.99C18.07 22.99 23 18.07 23 11.99C23 5.92 18.07 .99 12 .99ZM12 2.99C14.38 2.99 16.67 3.94 18.36 5.63C20.05 7.32 21 9.61 21 11.99C21 14.38 20.05 16.67 18.36 18.36C16.67 20.05 14.38 20.99 12 20.99C9.61 20.99 7.32 20.05 5.63 18.36C3.94 16.67 3 14.38 3 11.99C3 9.61 3.94 7.32 5.63 5.63C7.32 3.94 9.61 2.99 12 2.99ZM14 6.00C13.73 6.00 13.48 6.10 13.29 6.29C13.10 6.48 13 6.73 13 7.00V17.00C13 17.26 13.10 17.52 13.29 17.70C13.48 17.89 13.73 18.00 14 18.00C14.26 18.00 14.51 17.89 14.70 17.70C14.89 17.52 15 17.26 15 17.00V7.00C15 6.73 14.89 6.48 14.70 6.29C14.51 6.10 14.26 6.00 14 6.00ZM10 8.00C9.73 8.00 9.48 8.10 9.29 8.29C9.10 8.48 9 8.73 9 9.00V15.00C9 15.26 9.10 15.52 9.29 15.70C9.48 15.89 9.73 16.00 10 16.00C10.26 16.00 10.51 15.89 10.70 15.70C10.89 15.52 11 15.26 11 15.00V9.00C11 8.73 10.89 8.48 10.70 8.29C10.51 8.10 10.26 8.00 10 8.00ZM18 9.00C17.73 9.00 17.48 9.10 17.29 9.29C17.10 9.48 17 9.73 17 10.00V14.00C17 14.26 17.10 14.52 17.29 14.70C17.48 14.89 17.73 15.00 18 15.00C18.26 15.00 18.51 14.89 18.70 14.70C18.89 14.52 19 14.26 19 14.00V10.00C19 9.73 18.89 9.48 18.70 9.29C18.51 9.10 18.26 9.00 18 9.00ZM6 10.00C5.73 10.00 5.48 10.10 5.29 10.29C5.10 10.48 5 10.73 5 11.00V13.00C5 13.26 5.10 13.52 5.29 13.70C5.48 13.89 5.73 14.00 6 14.00C6.26 14.00 6.51 13.89 6.70 13.70C6.89 13.52 7 13.26 7 13.00V11.00C7 10.73 6.89 10.48 6.70 10.29C6.51 10.10 6.26 10.00 6 10.00Z'/></svg>";
        UI.loudnessBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_loudness'));
        UI.loudnessBtn.style.cssText = "background:none; border:none; color:#9CA3AF; cursor:pointer; margin-right:5px; display: flex; align-items: center; justify-content: center;";
        UI.volumeBtn.insertAdjacentElement("beforebegin", UI.loudnessBtn);
        setupButtonHoverEffects(UI.loudnessBtn);
        UI.loudnessBtn.onclick = toggleLoudnessEqualizer;
        // 新增：EPG按钮
        UI.epgBtn = document.createElement("button");
        UI.epgBtn.className = "epg-btn";
        UI.epgBtn.innerHTML = "🄴"; //ⓔ
        UI.epgBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_epg'));
        UI.epgBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.volumeContainer.insertAdjacentElement("afterend", UI.epgBtn);
        setupButtonHoverEffects(UI.epgBtn);
        UI.epgBtn.onclick = showEpgMarquee;
        UI.switchSourceBtn = document.createElement("button");
        UI.switchSourceBtn.className = "switch-source-btn";
        UI.switchSourceBtn.innerHTML = "⮁";
        UI.switchSourceBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_switch_source'));
        UI.switchSourceBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px; font-size:16px;";
        UI.epgBtn.insertAdjacentElement("afterend", UI.switchSourceBtn);
        setupButtonHoverEffects(UI.switchSourceBtn);
        // ─── 新增：进阶设置按钮 ───────────────────────────────
        UI.advancedBtn = document.createElement("button");
        UI.advancedBtn.innerHTML = "⛯";
        UI.advancedBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_advanced'));
        UI.advancedBtn.className = "control-btn advanced-btn";
        UI.advancedBtn.disabled = true;
        UI.switchSourceBtn.insertAdjacentElement("afterend", UI.advancedBtn);
        // Whisper 实时语音字幕按钮（紧跟在"多码率/音轨/字幕"按钮后面）
        UI.whisperBtn = document.createElement("button");
        UI.whisperBtn.id = "whisperBtn";
        UI.whisperBtn.innerHTML = "㏄";
        UI.whisperBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_whisper'));
        UI.whisperBtn.className = "control-btn whisperBtn";
        //UI.whisperBtn.disabled = true;   // 仅 HLS 流时启用
        UI.whisperBtn.disabled = false;
        UI.advancedBtn.insertAdjacentElement("afterend", UI.whisperBtn);
        setupButtonHoverEffects(UI.whisperBtn);
        UI.whisperBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            // 同步语言选择器到 state.whisper（面板打开/刷新逻辑在 js/soda-panel.js 里）
            const langSel = document.getElementById('soda-lang-select');
            if (langSel && state.whisper) state.whisper.language = langSel.value;
            const panel = document.getElementById('whisper-panel');
            if (panel) panel.classList.toggle('show');
        });
        // 进阶设置面板
        UI.advancedPanel = document.createElement("div");
        UI.advancedPanel.className = "advanced-panel";
        UI.advancedPanel.style.display = "none";
        UI.advancedPanel.innerHTML = `
            <div class="section quality-section">
                <div class="section-title">${i18n.t('player_quality_section_title')}</div>
                <div class="options" id="quality-options"></div>
            </div>
            <div class="section audio-section">
                <div class="section-title">${i18n.t('player_audio_section_title')}</div>
                <div class="options" id="audio-options"></div>
            </div>
            <div class="section subtitle-section">
                <div class="section-title">${i18n.t('player_subtitle_section_title')}</div>
                <div class="options" id="subtitle-options"></div>
            </div>
        `;
        UI.videoContainer.appendChild(UI.advancedPanel);
        UI.infoBtn = document.createElement("button");
        UI.infoBtn.className = "info-btn";
        UI.infoBtn.innerHTML = "ⓘ";
        UI.infoBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_info'));
        UI.infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
        UI.whisperBtn.insertAdjacentElement("afterend", UI.infoBtn);
        setupButtonHoverEffects(UI.infoBtn);
        UI.infoPanel = document.createElement("div");
        UI.infoPanel.className = "info-panel";
        UI.infoPanel.style.cssText = "display:none; position:absolute; bottom:65px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px; z-index: 20;";
        UI.videoContainer.appendChild(UI.infoPanel);
        // 添加快捷键提示
        const shortcutHint = document.createElement('div');
        shortcutHint.className = 'shortcut-hint';
        shortcutHint.innerHTML = i18n.t('player_shortcuts_title');
        shortcutHint.style.cssText = 'position:absolute; top:5px; right:10px; background:rgba(0,0,0,0.7); color:#aaa; padding:6px 12px; border-radius:6px; font-size:11px; z-index:10; cursor:help;';
        UI.videoContainer.appendChild(shortcutHint);
        // 鼠标悬停时显示完整快捷键列表
        shortcutHint.addEventListener('mouseenter', () => {
            shortcutHint.innerHTML = `
                <div style="font-weight:bold; margin-bottom:5px; border-bottom:1px solid #444; padding-bottom:3px;">${i18n.t('player_shortcuts_list_title')}</div>
                <table style="font-size:10px; line-height:1.6;">
                    <tr><td><b>PageUp</b></td><td>${i18n.t('player_kf_search_playlist')}</td></tr>
                    <tr><td><b>PageDown</b></td><td>${i18n.t('player_help_close_playlist')}</td></tr>
                    <tr><td><b>↑↓</b></td><td>${i18n.t('player_help_navigate_playlist')}</td></tr>
                    <tr><td><b>Enter</b></td><td>${i18n.t('player_help_play_selected')}</td></tr>
                    <tr><td><b>${i18n.t('player_help_space_key')}</b></td><td>${i18n.t('player_help_play_pause')}</td></tr>
                    <tr><td><b>↑↓</b></td><td>${i18n.t('player_help_volume')}</td></tr>
                    <tr><td><b>←→</b></td><td>${i18n.t('player_help_seek')}</td></tr>
                    <tr><td><b>f</b></td><td>${i18n.t('player_kf_fullscreen_toggle')}</td></tr>
                    <tr><td><b>m</b></td><td>${i18n.t('player_help_mute_toggle')}</td></tr>
                    <tr><td><b>p</b></td><td>${i18n.t('player_kf_playlist')}</td></tr>
                    <tr><td><b>[ ]</b></td><td>${i18n.t('player_help_prev_next_channel')}</td></tr>
                    <tr><td><b>s</b></td><td>${i18n.t('player_kf_switch_source')}</td></tr>
                    <tr><td><b>i</b></td><td>${i18n.t('player_kf_info_panel')}</td></tr>
                    <tr><td><b>e</b></td><td>${i18n.t('player_kf_program_info')}</td></tr>
                    <tr><td><b>L</b></td><td>${i18n.t('player_help_loudness')}</td></tr>
                    <tr><td><b>T</b></td><td>${i18n.t('player_help_ai_subtitle')}</td></tr>
                </table>
                <div style="margin-top:5px; font-size:9px; color:#aaa;">
                    ${i18n.t('player_shortcuts_tip')}
                </div>
            `;
            shortcutHint.style.width = '180px';
            shortcutHint.style.fontSize = '10px';
            shortcutHint.style.padding = '10px';
        });
        shortcutHint.addEventListener('mouseleave', () => {
            shortcutHint.innerHTML = i18n.t('player_shortcuts_title');
            shortcutHint.style.width = 'auto';
            shortcutHint.style.fontSize = '11px';
            shortcutHint.style.padding = '6px 12px';
        });
        // 给搜索框添加特殊类名以便CSS选择
        UI.playlistSearchInput.classList.add('playlist-search');
    }
    // ==================== 修复的 togglePlaylistUI 函数 ====================
    function togglePlaylistUI(show) {
        if (!state.isM3UPlaylist) {
            showNotification(i18n.t('player_not_playlist_mode'), 'warning', 2000);
            return;
        }
        const shouldShow = show !== undefined ? show : !UI.playlistContainer.classList.contains("hidden") === false;
        const currentlyVisible = !UI.playlistContainer.classList.contains("hidden");
        // 如果状态没有变化，直接返回
        if (shouldShow === currentlyVisible) return;
        UI.playlistContainer.classList.toggle("hidden", !shouldShow);
        if (shouldShow) {
            // 打开频道列表时，给频道列表容器添加一个焦点状态
            UI.playlistContainer.setAttribute('tabindex', '-1');
            UI.playlistContainer.classList.add('has-focus');
            // 如果有选中项，使其获得焦点
            setTimeout(() => {
                const selectedItem = UI.playlistItems.querySelector('.selected');
                if (selectedItem) {
                    selectedItem.focus();
                }
            }, 50);
            updateSearchPlaceholder();
            // 新增: 重新渲染以更新节目信息
            renderPlaylist(UI.playlistSearchInput.value);
            updatePlaylistHighlight("center"); //让正在播放的频道进入视野
        } else {
            // 如果当前焦点在频道列表内，强制让它失焦
            if (document.activeElement && document.activeElement.closest('#playlist-container')) {
                document.activeElement.blur();
            }
            // 如果关闭频道列表，确保移除焦点
            UI.playlistSearchInput.blur();
            UI.playlistSearchInput.style.border = "";
            UI.playlistSearchInput.style.boxShadow = "";
            // 清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }
    }
    function loadVolumeSettings() {
        chrome.storage.local.get(["volume", "loudnessEnabled"], function(result) {
            if (result.volume !== undefined) {
                UI.videoPlayer.volume = result.volume;
                UI.volumeProgress.style.width = result.volume * 100 + "%";
                updateVolumeIcon();
            }
            if (result.loudnessEnabled !== undefined && result.loudnessEnabled) {
                setTimeout(() => {
                    if (result.loudnessEnabled) toggleLoudnessEqualizer(true);
                }, 1000);
            }
        });
    }
    function switchToPrevChannel() {
        if (!state.isM3UPlaylist) {
            showNotification(i18n.t('player_not_playlist_mode'), 'warning', 2000);
            return;
        } else if (state.currentPlaylist.length === 0){
            showNotification(i18n.t('player_empty_playlist'), 'warning', 2000);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let prevIndex = state.currentPlaylistIndex - 1;
        if (prevIndex < 0) {
            prevIndex = state.currentPlaylist.length - 1;
        }
        console.log(`[频道切换] 切换到上一个频道: ${state.currentPlaylistIndex} → ${prevIndex}`);
        const item = state.currentPlaylist[prevIndex];
        if (item) {
            showNotification(i18n.t('player_switch_prev_channel', { NAME: item.title || i18n.t('player_channel_n', { N: prevIndex + 1 }) }), 1500);
        }
        playPlaylistItem(prevIndex);
    }
    function switchToNextChannel() {
        if (!state.isM3UPlaylist) {
            showNotification(i18n.t('player_not_playlist_mode'), 'warning', 2000);
            return;
        } else if (state.currentPlaylist.length === 0){
            showNotification(i18n.t('player_empty_playlist'), 'warning', 2000);
            return;
        }
        if (state.currentPlaylistIndex === -1) {
            state.currentPlaylistIndex = 0;
        }
        let nextIndex = state.currentPlaylistIndex + 1;
        if (nextIndex >= state.currentPlaylist.length) {
            nextIndex = 0;
        }
        console.log(`[频道切换] 切换到下一个频道: ${state.currentPlaylistIndex} → ${nextIndex}`);
        const item = state.currentPlaylist[nextIndex];
        if (item) {
            showNotification(i18n.t('player_switch_next_channel', { NAME: item.title || i18n.t('player_channel_n', { N: nextIndex + 1 }) }), 1500);
        }
        playPlaylistItem(nextIndex);
    }
    function parseInitialUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        const queryUrl = urlParams.get("url");
        const hashUrl = window.location.hash.substring(1);
        state.videoUrl = queryUrl || hashUrl;
        if (state.videoUrl) {
            UI.videoInfo.textContent = decodeURIComponent(state.videoUrl);
            try {
                const urlObj = new URL(state.videoUrl);
                state.baseUrl = urlObj.href.substring(0, urlObj.href.lastIndexOf("/") + 1);
                state.originalPlaylistUrl = state.videoUrl;
            } catch (e) {
                console.warn("基础URL解析失败:", e);
                state.baseUrl = "";
                state.originalPlaylistUrl = state.videoUrl;
            }
        }
    }
    function clearTimers(keys = []) {
        const targets = keys.length > 0 ? keys : ["load", "stall"];
        targets.forEach(key => {
            if (state.timers[key]) {
                clearTimeout(state.timers[key]);
                state.timers[key] = null;
            }
        });
    }
    function showLoading(show) {
        UI.loading.style.display = show ? "block" : "none";
    }
    function showError(message, isBlacklisted = false) {
        showLoading(false);
        UI.errorMessage.textContent = message;
        UI.errorMessage.style.display = "block";
        // 注意：黑名单错误的判定原先是靠在 message 里匹配"黑名单/拦截/禁止"这几个中文关键词，
        // 一旦文案换成英文（或其它语言）这个匹配就会失效。现在改成调用方显式传入
        // isBlacklisted，样式判断不再依赖文案内容，翻译成什么语言都不影响这段逻辑。
        if (isBlacklisted) {
            // 2. 如果是黑名单错误，添加样式
            UI.errorMessage.classList.add("blacklist-error");
            // 3. 只有黑名单错误才设置定时器自动隐藏（例如 10 秒后）
            setTimeout(() => {
                // 额外的保护：确保在隐藏前，消息依然是黑名单消息（防止期间被其他消息替换）
                if (UI.errorMessage.classList.contains("blacklist-error")) {
                    UI.errorMessage.style.display = "none";
                    UI.errorMessage.classList.remove("blacklist-error");
                }
            }, 10000);
        } else {
            // 4. 普通错误，移除样式且不设置定时器（会一直显示直到手动操作）
            UI.errorMessage.classList.remove("blacklist-error");
        }
    }
    function formatTime(seconds) {
        if (seconds === Infinity || isNaN(seconds)) return "Live";
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    function startVideoLoadProcess() {
        showLoading(true);
        UI.errorMessage.style.display = "none";
        UI.errorMessage.classList.remove("blacklist-error");
        checkAndInitPlayer(state.videoUrl);
    }
    // 新增：从 storage 加载用户设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'epgEnabled',
            'epgUrl',
            'marqueeSpeed',
            'marqueeColor',
            'marqueeFontSize',
            'headerRules'
        ], function(result) {
            // 更新 CONFIG（将用户友好的单位转换为毫秒）
            if (result.loadTimeout !== undefined) {
                CONFIG.LOAD_TIMEOUT_MS = result.loadTimeout;
            }
            if (result.stallTimeout !== undefined) {
                CONFIG.STALL_TIMEOUT_MS = result.stallTimeout;
            }
            if (result.maxRetryRounds !== undefined) {
                CONFIG.MAX_RETRY_ROUNDS = result.maxRetryRounds;
            }
            if (result.searchDebounce !== undefined) {
                CONFIG.SEARCH_DEBOUNCE_MS = result.searchDebounce;
            }
            if (result.playlistRefreshInterval !== undefined) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = result.playlistRefreshInterval;
            }
            if (result.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = result.autoRefreshEnabled;
            }
            if (result.epgEnabled !== undefined) {
                CONFIG.EPG_ENABLED = result.epgEnabled;
            }
            // storage 里没有 / 存的是旧版本固化下来的历史默认地址 → 用最新默认值
            CONFIG.EPG_URL = FmDefaults.resolveEpgUrl(result.epgUrl);
            if (result.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = result.marqueeSpeed;
            }
            if (result.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = result.marqueeColor;
            }
            if (result.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = result.marqueeFontSize;
            }
            if (result.headerRules !== undefined) {
                CONFIG.RULES = result.headerRules;
            }            
            console.log('[设置] 配置已从 storage 加载');
            console.log('[设置] 加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            console.log('[设置] 卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            console.log('[设置] 最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            console.log('[设置] 列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
            console.log('[设置] 自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
            console.log('[设置] EPG启用:', CONFIG.EPG_ENABLED);
            console.log('[设置] EPG URL:', CONFIG.EPG_URL);
            console.log('[设置] 跑马灯速度:', CONFIG.MARQUEE_SPEED, 's/char');
            console.log('[设置] 跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            console.log('[设置] 跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE, 'px');
            // 如果EPG启用，加载数据
            if (CONFIG.EPG_ENABLED && state.isM3UPlaylist) {
                loadEPG();
            }
        });
    }
    // 新增：监听设置更新消息
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'settingsUpdated') {
            console.log('[设置] 收到设置更新通知');
            // 更新 CONFIG
            if (message.config.loadTimeout) {
                CONFIG.LOAD_TIMEOUT_MS = message.config.loadTimeout;
                console.log('[设置] 更新加载超时:', CONFIG.LOAD_TIMEOUT_MS, 'ms');
            }
            if (message.config.stallTimeout) {
                CONFIG.STALL_TIMEOUT_MS = message.config.stallTimeout;
                console.log('[设置] 更新卡顿超时:', CONFIG.STALL_TIMEOUT_MS, 'ms');
            }
            if (message.config.maxRetryRounds) {
                CONFIG.MAX_RETRY_ROUNDS = message.config.maxRetryRounds;
                console.log('[设置] 更新最大重试轮次:', CONFIG.MAX_RETRY_ROUNDS);
            }
            if (message.config.searchDebounce) {
                CONFIG.SEARCH_DEBOUNCE_MS = message.config.searchDebounce;
                console.log('[设置] 更新搜索防抖:', CONFIG.SEARCH_DEBOUNCE_MS, 'ms');
            }
            if (message.config.playlistRefreshInterval) {
                CONFIG.PLAYLIST_REFRESH_INTERVAL = message.config.playlistRefreshInterval;
                console.log('[设置] 更新列表刷新间隔:', CONFIG.PLAYLIST_REFRESH_INTERVAL, 'ms');
                // 如果正在播放M3U列表，重启刷新定时器
                if (state.isM3UPlaylist && CONFIG.AUTO_REFRESH_ENABLED) {
                    if (state.timers.refreshPlaylist) {
                        clearTimeout(state.timers.refreshPlaylist);
                    }
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.autoRefreshEnabled !== undefined) {
                CONFIG.AUTO_REFRESH_ENABLED = message.config.autoRefreshEnabled;
                console.log('[设置] 更新自动刷新:', CONFIG.AUTO_REFRESH_ENABLED);
                if (!CONFIG.AUTO_REFRESH_ENABLED && state.timers.refreshPlaylist) {
                    clearTimeout(state.timers.refreshPlaylist);
                    state.timers.refreshPlaylist = null;
                } else if (CONFIG.AUTO_REFRESH_ENABLED && state.isM3UPlaylist) {
                    startPlaylistRefreshTimer();
                }
            }
            if (message.config.blacklist) {
                state.blacklist = message.config.blacklist;
                state.isBlacklistLoaded = true;
                console.log(`[设置] 黑名单已更新，${state.blacklist.length} 个关键词`);
            }
            if (message.config.headerRules) {
                CONFIG.RULES = message.config.headerRules;
                console.log(`[设置] headerRules已更新，${CONFIG.RULES.length} 条规则`);
            }            
            // 在 chrome.runtime.onMessage 监听器中，修改 EPG 相关部分为：
            if (message.config.epgEnabled !== undefined) {
                const oldEnabled = CONFIG.EPG_ENABLED;
                CONFIG.EPG_ENABLED = message.config.epgEnabled;
                console.log('[设置] 更新EPG启用:', CONFIG.EPG_ENABLED);
                if (CONFIG.EPG_ENABLED !== oldEnabled) {  // 只在启用状态真正变化时才操作
                    if (CONFIG.EPG_ENABLED && state.isM3UPlaylist) {
                        loadEPG();  // 启用时才加载
                    } else {
                        state.epgData = {};
                        state.channelMap = {};
                        state.epgExpiryTime = 0;
                        if (state.timers.epgRefresh) {
                            clearTimeout(state.timers.epgRefresh);
                            state.timers.epgRefresh = null;
                        }
                    }
                }
            }
            if (message.config.epgUrl) {
                const oldUrl = CONFIG.EPG_URL;
                CONFIG.EPG_URL = message.config.epgUrl;
                console.log('[设置] 更新EPG URL:', CONFIG.EPG_URL);
                // URL 改变且 EPG 已启用时，才重新加载
                if (CONFIG.EPG_ENABLED && oldUrl !== CONFIG.EPG_URL && state.isM3UPlaylist) {
                    loadEPG();
                }
            }
            if (message.config.marqueeSpeed !== undefined) {
                CONFIG.MARQUEE_SPEED = message.config.marqueeSpeed;
                console.log('[设置] 更新跑马灯速度:', CONFIG.MARQUEE_SPEED, 'px/s');
            }
            if (message.config.marqueeColor !== undefined) {
                CONFIG.MARQUEE_COLOR = message.config.marqueeColor;
                console.log('[设置] 更新跑马灯颜色:', CONFIG.MARQUEE_COLOR);
            }
            if (message.config.marqueeFontSize !== undefined) {
                CONFIG.MARQUEE_FONT_SIZE = message.config.marqueeFontSize;
                console.log('[设置] 更新跑马灯字体大小:', CONFIG.MARQUEE_FONT_SIZE, 'px');
            }
            // 更新信息面板
            updateInfoPanel();
            showNotification(i18n.t('settings_msg_settings_updated'), 'success',2000);
        }
    });
    // 修改后的 loadBlacklist 函数：优先从 storage，没有则从文件
    function loadBlacklist() {
        state.blacklist = [];
        state.isBlacklistLoaded = false;
        console.log('[黑名单] 开始加载黑名单...');
        // 1. 首先尝试从 storage 加载（用户自定义的）
        chrome.storage.local.get(['blacklist', 'blacklistContent'], function(result) {
            if (result.blacklist && Array.isArray(result.blacklist) && result.blacklist.length > 0) {
                // 从 storage 的数组加载成功
                state.blacklist = result.blacklist;
                console.log(`[黑名单] 从 storage 加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else if (result.blacklistContent) {
                // 从 storage 的字符串内容加载
                state.blacklist = result.blacklistContent.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                console.log(`[黑名单] 从 storage 内容加载 ${state.blacklist.length} 个关键词`);
                state.isBlacklistLoaded = true;
                if (state.videoUrl) startVideoLoadProcess();
            } else {
                // 2. storage 中没有，则从文件加载
                console.log('[黑名单] storage 中无黑名单，尝试从文件加载');
                fetch(CONFIG.BLACKLIST_URL)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return response.text();
                    })
                    .then(text => {
                        state.blacklist = text.split('\n')
                            .map(line => line.trim())
                            .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                            .filter(keyword => keyword.length > 0);
                        console.log(`[黑名单] 从文件加载 ${state.blacklist.length} 个关键词`);
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    })
                    .catch(error => {
                        console.warn('[黑名单] 文件加载失败，使用空黑名单:', error);
                        state.blacklist = [];
                        state.isBlacklistLoaded = true;
                        if (state.videoUrl) startVideoLoadProcess();
                    });
            }
        });
    }
    // 新增：为所有控制按钮添加统一的鼠标效果
    function addButtonHoverEffects() {
        const staticButtons = [
            UI.backBtn,
            UI.playPauseBtn,
            UI.prevChannelBtn,
            UI.nextChannelBtn,
            UI.volumeBtn,
            UI.fullscreenBtn,
            UI.playlistBtn,
            UI.closePlaylistBtn,
            UI.clearSearchBtn,
            UI.epgBtn // 新增
        ];
        staticButtons.forEach(button => {
            if (!button) return;
            setupButtonHoverEffects(button);
        });
    }
    function setupButtonHoverEffects(button) {
        if (!button) return;
        button.style.opacity = '1';
        button.style.transition = 'opacity 0.2s ease';
        button.addEventListener('mouseenter', () => {
            button.style.opacity = '0.85';
        });
        button.addEventListener('mouseleave', () => {
            button.style.opacity = '1';
        });
        button.addEventListener('mousedown', () => {
            button.style.opacity = '0.6';
        });
        button.addEventListener('mouseup', () => {
            button.style.opacity = '0.85';
        });
    }
    function checkUrlInBlacklist(url, urlType = "URL") {
        if (!url || typeof url !== 'string') {
            return false;
        }
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[黑名单] 等待黑名单加载完成...`);
            setTimeout(() => {
                checkUrlInBlacklist(url, urlType);
            }, 100);
            return false;
        }
        const lowerUrl = url.toLowerCase();
        for (const keyword of state.blacklist) {
            if (!keyword) continue;
            const lowerKeyword = keyword.toLowerCase();
            // 支持简单的通配符匹配
            if (lowerKeyword.includes('*')) {
                // 将通配符转换为正则表达式
                const pattern = lowerKeyword
                    .replace(/\./g, '\\.')
                    .replace(/\*/g, '.*');
                const regex = new RegExp(`^${pattern}$`);
                if (regex.test(lowerUrl)) {
                    console.warn(`[黑名单拦截] ${urlType} 匹配通配符模式: "${keyword}"`);
                    console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                    if(!state.isM3UPlaylist) {
                       showError(
                        i18n.t('player_blacklist_blocked_rule', {
                            RULE: keyword,
                            URL: url.substring(0, 80) + (url.length > 80 ? '...' : '')
                        }),
                        true
                       );
                    }   
                    handleBlacklistedInPlaylist(url, keyword);
                    return true;
                }
            } else if (lowerUrl.includes(lowerKeyword)) {
                console.warn(`[黑名单拦截] ${urlType} 包含黑名单关键词: "${keyword}"`);
                console.warn(`[黑名单拦截] 被拦截的URL: ${url}`);
                if(!state.isM3UPlaylist) {
                   showError(
                    i18n.t('player_blacklist_blocked_keyword', {
                        KEYWORD: keyword,
                        URL: url.substring(0, 80) + (url.length > 80 ? '...' : '')
                    }),
                    true
                   );
                }   
                handleBlacklistedInPlaylist(url, keyword);
                return true;
            }
        }
        return false;
    }
    // 新增：处理频道列表中被黑名单拦截的项目
    function handleBlacklistedInPlaylist(blockedUrl, keyword) {
        if (!state.isM3UPlaylist || state.currentPlaylistIndex === -1) {
            return;
        }
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item) return;
        // 从当前频道的URL列表中移除被拦截的URL
        if (item.urls && item.urls.length > 0) {
            const originalLength = item.urls.length;
            item.urls = item.urls.filter(url => url !== blockedUrl);
            if (item.urls.length < originalLength) {
                console.warn(`[黑名单] 从频道 "${item.title}" 中移除 ${originalLength - item.urls.length} 个被拦截的源`);
                // 更新当前频道信息
                if (state.currentChannelInfo.urls) {
                    state.currentChannelInfo.urls = state.currentChannelInfo.urls.filter(url => url !== blockedUrl);
                }
                // 如果当前正在播放被拦截的源，切换到下一个源
                if (item.currentUrlIndex !== undefined &&
                    item.urls.length > 0 &&
                    item.currentUrlIndex >= item.urls.length) {
                    item.currentUrlIndex = 0;
                    showNotification(i18n.t('player_source_blacklisted_switch'), 2000);
                    // 自动播放下一个源
                    const nextUrl = item.urls[0];
                    setTimeout(() => {
                        if (checkUrlInBlacklist(nextUrl, "下一个源")) {
                            return;
                        }
                        destroyPlayer();
                        showLoading(true);
                        UI.errorMessage.style.display = "none";
                        UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                        checkAndInitPlayer(nextUrl);
                    }, 1500);
                }
            }
            // 如果频道所有源都被拦截，跳过这个频道
            if (item.urls.length === 0) {
                console.warn(`[黑名单] 频道 "${item.title}" 所有源均被拦截，将跳过`);
                showNotification(i18n.t('player_channel_blocked', { NAME: item.title }), 3000);
                // 自动播放下一个频道
                setTimeout(() => {
                    let nextIndex = state.currentPlaylistIndex + 1;
                    while (nextIndex < state.currentPlaylist.length) {
                        const nextItem = state.currentPlaylist[nextIndex];
                        if (nextItem && nextItem.urls && nextItem.urls.length > 0) {
                            // 检查下一个频道的第一个URL是否在黑名单中
                            const firstUrl = nextItem.urls[0];
                            if (!checkUrlInBlacklist(firstUrl, "下一个频道URL")) {
                                playPlaylistItem(nextIndex);
                                return;
                            }
                        }
                        nextIndex++;
                    }
                    // 所有频道都被屏蔽
                    showError(i18n.t('player_all_channels_blacklisted'), true);
                }, 1500);
            }
        }
    }
    // 判断是否是 udpxy / rtp2httpd / msd_lite 这类"组播转单播"代理的地址：
    //   http://host:port/rtp/225.1.4.31:1060
    //   http://host:port/udp/239.0.0.1:5000?fcc=...
    // 这类地址输出的是裸 MPEG-TS，但路径里没有任何 .ts 之类的扩展名，原来只能靠探测
    // 响应头 Content-Type 来猜类型——服务器返回 application/octet-stream / text/html
    // 时会被误判成 HLS，探测失败时又会落到原生 <video>，都播不出来。所以直接按路径
    // 特征识别：只匹配路径（pathname，不含查询串）里 /rtp/ 或 /udp/ 后面紧跟组播
    // IPv4（224–239 段）加端口的形式，允许前面还有反向代理的路径前缀（如 /udpxy/rtp/…）。
    function isUdpProxyTsUrl(url) {
        let path = '';
        try {
            path = new URL(url).pathname;
        } catch (e) {
            path = String(url || '').split(/[?#]/)[0];
        }
        return /\/(?:rtp|udp)\/(?:22[4-9]|23\d)(?:\.\d{1,3}){3}:\d{1,5}(?:\/|$)/i.test(path);
    }
    function checkAndInitPlayer(url) {
        const thisRequestId = ++state.loadRequestId;
        // 等待黑名单加载完成
        if (!state.isBlacklistLoaded) {
            console.log(`[Req #${thisRequestId}] 等待黑名单加载...`);
            setTimeout(() => {
                if (thisRequestId === state.loadRequestId) {
                    checkAndInitPlayer(url);
                }
            }, 100);
            return;
        }
        // 检查URL是否在黑名单中（包括原始URL）
        if (checkUrlInBlacklist(url, "原始URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        // 带显式后缀（#m3u8 / #m3u / #ts / #flv），或者是 /rtp/、/udp/ 组播代理地址
        // （类型已经明确是 TS 裸流）时，不需要再探测重定向和 Content-Type。
        if (/(?:#m3u8|#m3u|#ts|#flv)$/i.test(lowerUrl) || isUdpProxyTsUrl(url)) {    
            if (thisRequestId === state.loadRequestId) {
                initPlayerWithUrl(url);
            }
        } else {
            console.log(`[Req #${thisRequestId}] 检测重定向及 Content-Type:`, url);
            new Promise(resolve => {
                chrome.runtime.sendMessage({
                    action: "checkRedirect",
                    url: url
                }, response => resolve(response));
            }).then(response => {
                if (thisRequestId !== state.loadRequestId) {
                    console.warn(`[Req #${thisRequestId}] 请求已过期 (当前ID: ${state.loadRequestId})，丢弃结果。`);
                    return;
                }
                if (response && response.success) {
                    console.log(`[Req #${thisRequestId}] 重定向成功: ${response.finalUrl}`);
                    // 检查重定向后的URL是否在黑名单中
                    if (checkUrlInBlacklist(response.finalUrl, "重定向URL")) {
                        return;
                    }
                    initPlayerWithUrl(response.finalUrl, response.contentType || "");
                } else {
                    console.warn(`[Req #${thisRequestId}] 重定向检测无响应或失败，尝试直连`);
                    initPlayerWithUrl(url);
                }
            });
        }
    }
    function destroyPlayer() {
        if (UI.subDisplay) UI.subDisplay.innerHTML = ''; // 清空字幕
        _resetHlsSubHistory();
        // 换台：清空翻译缓存和 SODA 识别状态（换台必须重新绑定新的 <video> 音频流）
        state.whisper.interimText = '';
        _whisperTransCache.clear();
        if (state.whisper.enabled) _stopSodaAsr();
        if (state.player) {
            if (typeof state.player.destroy === "function") {
                state.player.destroy();
            } else if (state.player instanceof Hls) {
                state.player.destroy();
            }
            state.player = null;
        }
        UI.videoPlayer.removeAttribute("src");
        UI.videoPlayer.load();
        state.isPlaying = false;
        clearTimers();
        // 进阶面板重置
        if (UI.advancedBtn) UI.advancedBtn.disabled = true;
        if (UI.advancedPanel) UI.advancedPanel.style.display = 'none';
        // Whisper 按钮禁用，且停止正在进行的字幕
        //if (UI.whisperBtn) UI.whisperBtn.disabled = true;
        if (state.whisper?.enabled) _stopSodaAsr();
        state.streamInfo = {
            resolution: "--",
            type: "--",
            codec: "--",
            bitrate: "--",
            bandwidthEstimate: 0
        };
    }
    function initPlayerWithUrl(url, contentType = "") {
        // 再次检查URL（以防万一）
        if (checkUrlInBlacklist(url, "播放URL")) {
            return;
        }
        const lowerUrl = url.toLowerCase();
        const ct = contentType.toLowerCase();
        const isHlsContent = ct.includes("mpegurl") || ct.includes("hls") || ct.includes("text/html") || ct.includes("text/plain") || ct.includes("application/octet-stream");
        const isTsContent = ct.includes("mp2t");
        // 1. 优先判定 Hash 锚点 (#m3u, #m3u8, #flv, #ts)
        if (/#m3u$/i.test(lowerUrl)) {
            initM3UPlaylist(url);
        } else if (/#m3u8$/i.test(lowerUrl)) {
            initHlsPlayer(url);
        } else if (/#(?:flv|ts)$/i.test(lowerUrl)) {
            initMpegtsPlayer(url, "");
        } else if (isUdpProxyTsUrl(url)) {
            // 1.5 udpxy / rtp2httpd 等组播转单播代理地址（/rtp/IP:端口、/udp/IP:端口）：
            //     输出的是裸 MPEG-TS，直接按 TS 处理，不依赖响应头。
            //     （显式写了 #m3u8 / #m3u 的仍然优先按上面的 Hash 锚点走。）
            initMpegtsPlayer(url, "TS");
        } 
        // 2. 其次判定文件扩展名 (.m3u, .m3u8, .flv, .ts) 及响应头
        else if (/\.m3u(?:[?#].*)?$/i.test(lowerUrl)) {
            initM3UPlaylist(url);
        } else if (/\.m3u8(?:[?#].*)?$/i.test(lowerUrl)) {
            initHlsPlayer(url);
        } else if (isTsContent || /\.(?:flv|ts)(?:[?#].*)?$/i.test(lowerUrl)) {
            const mCT = isTsContent ? "TS" : "";
            initMpegtsPlayer(url, mCT);
        } else if (isHlsContent) {
            initHlsPlayer(url);
        } else {
            initNativePlayer(url);
        }
    }
    /**
     * 使用 mpegts.js 初始化播放器
     * @param {string} url - 媒体流地址
     * @param {string} [mCT=""] - 内容类型提示，"TS" 表示 TS裸流，其他值（包括空字符串）视为 FLV
     */
    function initMpegtsPlayer(url, mCT = "") {
        const lowerUrl = url.toLowerCase();
        if (!mpegts.isSupported() || !mpegts.getFeatureList().mseLivePlayback) {
            return handleError(i18n.t('player_err_mpegts_unsupported'));
        }
        destroyPlayer();
        const isTsStream = mCT === "TS" || mCT.toUpperCase() === "TS" || /(?:\.ts([?#].*)?|#ts)$/i.test(lowerUrl);
        const mediaType = isTsStream ? "mpegts" : "flv";
        state.streamInfo.type = isTsStream ? "TS" : "FLV";
        const player = mpegts.createPlayer({
            type: mediaType,
            url: url,
            isLive: true,
        }, {
            enableWorker: true,
            fixAudioTimestampGap: true,
            enableStashBuffer: true,
            stashInitialSize: 512 * 1024,
        });
        player.attachMediaElement(UI.videoPlayer);
        player.load();
        player.on(mpegts.Events.MEDIA_INFO, (info) => {
            clearTimers(["load"]);
            if (info.width && info.height) {
                state.streamInfo.resolution = `${info.width}x${info.height}`;
            }
            if (info.videoCodec) {
                state.streamInfo.codec = formatCodecName(info.videoCodec);
            }
            updateInfoPanel();
        });
        player.on(mpegts.Events.ERROR, (errType, errDetail) => {
            console.error("mpegts Error:", errType, errDetail);
            handleError(i18n.t('player_err_playback', { TYPE: errType, DETAIL: errDetail }));
        });
        state.player = player;
        attachCommonVideoEvents();
    }
    function initHlsPlayer(url) {
        if (Hls.isSupported()) {
            destroyPlayer();
            state.streamInfo.type = "HLS";
            const player = new Hls({
                debug: false,
                //backBufferLength: 60,
                maxBufferLength: 30,
                maxMaxBufferLength: 60,
                capLevelToPlayerSize: true,
                autoLevelEnabled: true,
                fragLoadingMaxRetry: 1,
                fragLoadingRetryDelay: 500,
                xhrSetup: function (xhr, url) {
                    if (url.includes('.key') || url.includes('keyfile')) {
                        xhr.withCredentials = true;
                    }
                }
            });
            player.loadSource(url);
            player.attachMedia(UI.videoPlayer);

            // 注：实时字幕改用浏览器原生 SODA（SpeechRecognition，processLocally），
            // 直接从 <video> 元素抓音频流式识别，不再需要在这里监听
            // BUFFER_APPENDING/FRAG_BUFFERED 采集 fMP4 分片、拼 moov 解码。
            // 换台时仍需要重启 ASR（见 initHlsPlayer 调用处的 _stopSodaAsr）。

            // 使用支持翻译的新版 bindSubtitleEvents
            player.on(Hls.Events.SUBTITLE_TRACK_SWITCHED, () => {
                console.log("[AI Subtitle] 检测到字幕轨道切换，重置源语言检测状态");
                globalDetectedLang = null;
                detectionCount = 0;
                // 可选：清空翻译器缓存（如果不同轨道语言差异很大）
                translatorCache.clear();  // 如果想彻底清空缓存，取消注释这行
                _resetHlsSubHistory();
                bindSubtitleEvents();
                updateAdvancedPanel(player);
            });
            player.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, () => {
                console.log("[AI Subtitle] 字幕轨道列表更新，重置检测状态");
                globalDetectedLang = null;
                detectionCount = 0;
                _resetHlsSubHistory();
                bindSubtitleEvents();
                updateAdvancedPanel(player);
            });
            // 兜底：hls.js 1.7.x 起原生字幕轨道改为真正插入 <track> DOM 元素，
            // 浏览器把它加入 video.textTracks 列表是异步的，SUBTITLE_TRACKS_UPDATED/
            // SUBTITLE_TRACK_SWITCHED 事件里同步调用 bindSubtitleEvents() 遍历时，
            // 新 track 有可能还没出现在列表里，导致 oncuechange 漏绑（1.6.x 因为用
            // addTextTrack() 同步添加，没有这个问题）。这里用 addtrack 事件兜底，
            // 不管 track 是何时真正出现在列表里都能补上绑定。只需注册一次，不用随
            // 换台重复绑定（监听的是 TextTrackList 本身）。
            UI.videoPlayer.textTracks.addEventListener('addtrack', (e) => {
                const track = e.track;
                if (track && track.kind === 'subtitles') {
                    console.log("[AI Subtitle] addtrack 事件补挂 oncuechange:", track.label || track.language);
                    bindOneSubtitleTrack(track);
                }
            });
            // 最可靠：浏览器原生 textTracks change 事件
            UI.videoPlayer.textTracks.addEventListener('change', () => {
                console.log("[AI Subtitle] 原生 textTracks 'change' 事件触发");
                let activeTrack = null;
                for (let track of UI.videoPlayer.textTracks) {
                    if (track.mode === 'showing' && track.kind === 'subtitles') {
                        activeTrack = track;
                        break;
                    }
                }
                if (activeTrack) {
                    console.log("[AI Subtitle] 检测到新字幕轨道启用，重置源语言检测状态");
                    globalDetectedLang = null;
                    detectionCount = 0;
                    translatorCache.clear();  // 彻底清空缓存
                    _resetHlsSubHistory();
                }
            });
            player.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                clearTimers(["load"]);
                console.log("HLS Manifest Parsed");
                showLoading(false);
                updateAdvancedPanel(player);
                updateResolutionFromHls(player);
                attemptPlay();
            });
            player.on(Hls.Events.LEVEL_SWITCHED, (event, data) => { 
                updateAdvancedPanel(player); 
                updateResolutionFromHls(player);
                console.log("换码率后分辨率:", state.streamInfo.resolution);
            });
            player.on(Hls.Events.AUDIO_TRACK_SWITCHED, () => {
                updateAdvancedPanel(player);
                updateResolutionFromHls(player);
            });
            player.on(Hls.Events.SUBTITLE_TRACK_SWITCHED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.AUDIO_TRACKS_UPDATED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, () => updateAdvancedPanel(player));
            player.on(Hls.Events.BUFFER_CODECS, (event, data) => {
                console.log("[BUFFER_CODECS] 触发了！", data);
                let videoCodec = null;
                if (data?.video?.codec) {
                    videoCodec = data.video.codec;
                } else if (data?.tracks?.video?.codec) {
                    videoCodec = data.tracks.video.codec;
                }
                if (videoCodec) {
                    console.log("[BUFFER_CODECS] 成功获取视频编码:", videoCodec);
                    state.streamInfo.codec = formatCodecName(videoCodec);
                    updateInfoPanel();
                }
            });
            player.on(Hls.Events.FRAG_LOADED, () => {
                if (player.bandwidthEstimate > 0) {
                    state.streamInfo.bandwidthEstimate = player.bandwidthEstimate;
                    updateBitrateDisplay(player);
                    updateInfoPanel();
                }
            });
            player.on(Hls.Events.ERROR, (event, data) => {
                if (data.fatal) {
                    console.error("HLS Fatal Error:", data.type, data.details);
                    handleError(i18n.t('player_err_hls_playback', { DETAIL: data.details }));
                }
            });
            state.player = player;
            attachCommonVideoEvents();
        } else if (UI.videoPlayer.canPlayType("application/vnd.apple.mpegurl")) {
            destroyPlayer();
            UI.videoPlayer.src = url;
            attachCommonVideoEvents();
        } else {
            handleError(i18n.t('player_err_hls_unsupported'));
        }
    }
    /**
     * 简单通配符匹配：支持 * （转换为 .* 正则）
     * @param {string} url      - 当前请求的完整 URL
     * @param {string} pattern  - 如 '*.abc.com' 或 'https://cdn.*.com/path/*'
     * @returns {boolean}
     */
    function matchesPattern(url, pattern) {
        const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
        const regex = new RegExp(`^${escaped}$`, 'i');
        return regex.test(url);
    }
    // ────────────────────────────────────────────────
    //  更新进阶设置面板（核心功能）
    // ────────────────────────────────────────────────
    function updateAdvancedPanel(hls) {
        if (!hls) return;
        const hasQuality   = hls.levels?.length > 1;
        const hasAudio     = hls.audioTracks?.length > 1;
        const hasSubtitle  = hls.subtitleTracks?.length > 0;
        UI.advancedBtn.disabled = !(hasQuality || hasAudio || hasSubtitle);
        // Whisper 字幕只支持 HLS，只要 HLS 播放器就绪就启用
        if (UI.whisperBtn) UI.whisperBtn.disabled = false;
        // 码率
        const qContainer = document.getElementById('quality-options');
        qContainer.innerHTML = '';
        if (hasQuality) {
            hls.levels.forEach((level, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = levelToText(level);
                if (idx === hls.currentLevel) item.classList.add('active');
                item.onclick = () => {
                    hls.currentLevel = idx;
                    hls.autoLevelEnabled = false;
                    updateAdvancedPanel(hls);
                    showNotification(i18n.t('player_bitrate_label', { LEVEL: levelToText(level) }), 1500);
                };
                qContainer.appendChild(item);
            });
        } else {
            qContainer.innerHTML = `<div class="option-item disabled">${i18n.t('player_no_quality_options')}</div>`;
        }
        // 音轨
        const aContainer = document.getElementById('audio-options');
        aContainer.innerHTML = '';
        if (hasAudio) {
            hls.audioTracks.forEach((track, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = track.name || track.lang || i18n.t('player_audio_track_n', { N: idx + 1 });
                if (hls.audioTrack === idx) item.classList.add('active');
                item.onclick = () => {
                    hls.audioTrack = idx;
                    updateAdvancedPanel(hls);
                    showNotification(i18n.t('player_audio_track_label', { NAME: track.name || track.lang || i18n.t('player_unknown') }), 1500);
                };
                aContainer.appendChild(item);
            });
        } else {
            aContainer.innerHTML = `<div class="option-item disabled">${i18n.t('player_no_audio_options')}</div>`;
        }
        // 字幕
        const sContainer = document.getElementById('subtitle-options');
        sContainer.innerHTML = '';
        const offItem = document.createElement('div');
        offItem.className = 'option-item' + (hls.subtitleTrack < 0 ? ' active' : '');
        offItem.textContent = i18n.t('player_subtitle_off');
        offItem.onclick = () => {
            hls.subtitleTrack = -1;
            UI.subDisplay.innerHTML = '';
            _resetHlsSubHistory();
            updateAdvancedPanel(hls);
        };
        sContainer.appendChild(offItem);
        if (hasSubtitle) {
            hls.subtitleTracks.forEach((track, idx) => {
                const item = document.createElement('div');
                item.className = 'option-item';
                item.textContent = track.name || track.lang || i18n.t('player_subtitle_track_n', { N: idx + 1 });
                if (hls.subtitleTrack === idx) item.classList.add('active');
                item.onclick = () => {
                    hls.subtitleTrack = idx;
                    updateAdvancedPanel(hls);
                    showNotification(i18n.t('player_subtitle_track_label', { NAME: track.name || track.lang || i18n.t('player_unknown') }), 1500);
                };
                sContainer.appendChild(item);
            });
        }
    }
    function levelToText(level) {
        if (!level) return '未知';
        if (level.height) {
            let txt = level.height + 'p';
            if (level.bitrate) txt += ` (${formatBitrate(level.bitrate)})`;
            return txt;
        }
        if (level.bitrate) return formatBitrate(level.bitrate);
        return 'Level ' + (level.idx ?? '?');
    }
    // 格式化 codec 显示，更友好
    function formatCodecName(codec) {
        if (!codec) return "未知";
        if (codec.includes("avc1")) return "H.264";
        if (codec.includes("hvc1") || codec.includes("hev1")) return "H.265/HEVC";
        if (codec.includes("av01")) return "AV1";
        if (codec.includes("vp9")) return "VP9";
        if (codec.includes("mp4a")) return "AAC"; // 音频
        return codec.split('.')[0].toUpperCase(); // fallback
    }
    // 专门更新码率显示（避免重复逻辑）
    function updateBitrateDisplay(hls) {
        if (!hls) return;
        const currentLevel = hls.levels[hls.currentLevel];
        if (currentLevel?.bitrate > 0) {
            state.streamInfo.bitrate = formatBitrate(currentLevel.bitrate);
        } else if (hls.bandwidthEstimate > 10000) { // 避免太小不显示
            state.streamInfo.bitrate = formatBitrate(hls.bandwidthEstimate) + " " + i18n.t('player_bitrate_estimated_suffix');
        }
    }
    // 友好显示码率（kbps / Mbps）
    function formatBitrate(bitsPerSecond) {
        if (!bitsPerSecond || isNaN(bitsPerSecond)) return "未知";
        if (bitsPerSecond >= 1000000) {
            return (bitsPerSecond / 1000000).toFixed(1) + " Mbps";
        }
        return Math.round(bitsPerSecond / 1000) + " kbps";
    }
    function initNativePlayer(url) {
        destroyPlayer();
        state.streamInfo.type = i18n.t('player_stream_type_native');
        const lower = url.toLowerCase();
        if (lower.includes(".mp4")) state.streamInfo.type = "MP4";
        else if (lower.includes(".webm")) state.streamInfo.type = "WebM";
        else if (lower.includes(".ogg") || lower.includes(".ogv")) state.streamInfo.type = "OGG";
        UI.videoPlayer.src = url;
        attachCommonVideoEvents();
    }
    // seek（后退/前进，包括拖拽进度条）之后统一要做的清理：
    //   1. SODA 实时字幕：清掉未定稿文本 + 定稿字幕历史（state.whisper.subtitles）。
    //      定稿历史是按 showAt/hideAt 这个基于 video.currentTime 的时间窗口来判断
    //      "现在要不要显示"的，seek 后 currentTime 跳变，旧位置定稿的字幕只要窗口
    //      跟新位置重叠就会被重新判定为"应该显示"，跟新识别出来的实时字幕同时出现，
    //      就是"历史字幕和实时字幕重复"这个问题的根源。
    //   2. HLS 内嵌字幕：同理清空 hlsSubHistory（_resetHlsSubHistory）。
    // attachCommonVideoEvents() 和 bindSubtitleEvents() 都会把 UI.videoPlayer.onseeked
    // 指向这同一个函数引用——两边都用属性赋值而不是 addEventListener，一是避免其中一个
    // 覆盖另一个（属性赋值只能存一个处理函数），二是避免每次换台/切换字幕轨道时重复调用
    // 这两个绑定函数导致监听器不断叠加。
    function handleVideoSeeked() {
        state.whisper.interimText = '';
        state.whisper.subtitles = [];
        _resetHlsSubHistory();
    }
    function attachCommonVideoEvents() {
        UI.videoPlayer.onloadedmetadata = function() {
            clearTimers(["load"]);
            showLoading(false);
            updateVideoInfoFromElement();
            attemptPlay();
        };
        UI.videoPlayer.onloadeddata = function() {
            updateVideoInfoFromElement();
        };
        UI.videoPlayer.onerror = function() {
            if (!UI.videoPlayer.getAttribute("src") && !UI.videoPlayer.currentSrc) return;
            handleError(i18n.t('player_err_video_load_failed'));
        };
        UI.videoPlayer.onplay = () => {
            state.isPlaying = true;
            UI.playPauseBtn.textContent = "❚❚";
            //UI.playPauseBtn.title = "暂停(空格键)";
            UI.playPauseBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_pause'));
        };
        UI.videoPlayer.onpause = () => {
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            //UI.playPauseBtn.title = "播放(空格键)";
            UI.playPauseBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_play'));
        };
        UI.videoPlayer.onseeked = handleVideoSeeked;
        UI.videoPlayer.ontimeupdate = updateProgress;
        UI.videoPlayer.onvolumechange = updateVolumeIcon;
        UI.videoPlayer.onended = () => {
            if (state.isM3UPlaylist) {
                const item = state.currentPlaylist[state.currentPlaylistIndex];
                if (item && item.urls && item.currentUrlIndex < item.urls.length - 1) {
                    item.currentUrlIndex++;
                    console.log(`当前源播放结束，切换至本频道下一个源: ${item.currentUrlIndex + 1}/${item.urls.length}`);
                    showNotification(i18n.t('player_playback_ended_switch', { CUR: item.currentUrlIndex + 1, TOTAL: item.urls.length }), 1500);
                    const nextUrl = item.urls[item.currentUrlIndex];
                    destroyPlayer();
                    showLoading(true);
                    UI.errorMessage.style.display = "none";
                    UI.videoInfo.textContent = item.title || decodeURIComponent(nextUrl);
                    checkAndInitPlayer(nextUrl);
                    if (state.timers.load) clearTimeout(state.timers.load);
                    state.timers.load = setTimeout(() => {
                        console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
                        tryNextRedundantUrl();
                    }, CONFIG.LOAD_TIMEOUT_MS);
                    return;
                }
                if (state.currentPlaylistIndex < state.currentPlaylist.length - 1) {
                    playPlaylistItem(state.currentPlaylistIndex + 1);
                }
            }
        };
        UI.videoPlayer.onwaiting = () => {
            if (state.isM3UPlaylist && state.isPlaying) {
                console.warn(`卡顿检测: 启动超时计时器 (${CONFIG.STALL_TIMEOUT_MS}ms)`);
                if (state.timers.stall) clearTimeout(state.timers.stall);
                state.timers.stall = setTimeout(() => {
                    console.error("播放停滞超时，尝试切换线路。");
                    tryNextRedundantUrl();
                }, CONFIG.STALL_TIMEOUT_MS);
            }
        };
        UI.videoPlayer.onplaying = () => {
            if (state.timers.stall) {
                clearTimeout(state.timers.stall);
                state.timers.stall = null;
            }
        };
    }
    function handleError(msg) {
        if (state.isM3UPlaylist) {
            console.warn(`捕获错误: ${msg} -> 尝试下一个源`);
            tryNextRedundantUrl();
        } else {
            showError(msg);
        }
    }
    let isFirstPlay = true;
    function attemptPlay() {
        const promise = UI.videoPlayer.play();
        if (promise !== undefined) {
            promise.then(() => {
                state.isPlaying = true;
                UI.playPauseBtn.textContent = "❚❚";
                //UI.playPauseBtn.title = "暂停(空格键)";
                UI.playPauseBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_pause'));
                if (isFirstPlay && !document.fullscreenElement) {
                    isFirstPlay = false;
                }
            }).catch(error => {
                console.error("自动播放被阻止或失败:", error);
                state.isPlaying = false;
                UI.playPauseBtn.textContent = "▶";
                //UI.playPauseBtn.title = "播放(空格键)";
                UI.playPauseBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_play'));
            });
        }
    }
    function initM3UPlaylist(url) {
        state.isM3UPlaylist = true;
        state.streamInfo.type = "M3U";
        const parser = new M3UParser;
        parser.parseFromUrl(url).then(playlist => {
            if (!playlist || playlist.length === 0) {
                throw new Error(i18n.t('player_err_playlist_empty'));
            }
            const processedPlaylist = playlist.map(item => {
                if (!item.tvgId && item.attributes) {
                    item.tvgId = item.attributes['tvg-id'];
                }
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                throw new Error(i18n.t('player_err_no_valid_items'));
            }
            if (state.currentPlaylist.length === 0) {
                state.currentPlaylist = processedPlaylist;
                renderPlaylist();
                playPlaylistItem(0);
                togglePlaylistUI(true);
                if (CONFIG.AUTO_REFRESH_ENABLED) {
                    startPlaylistRefreshTimer();
                }
            } else {
                refreshPlaylist(processedPlaylist);
            }
        }).catch(err => {
            console.error("M3U解析失败:", err);
            showError(i18n.t('player_err_parse_playlist_failed', { MSG: err.message }));
        });
        if (CONFIG.EPG_ENABLED) {
            loadEPG();
        }
    }
    function startPlaylistRefreshTimer() {
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            state.timers.refreshPlaylist = null;
        }
        if (!CONFIG.AUTO_REFRESH_ENABLED) {
            console.log('[定时刷新] 自动刷新已禁用');
            return;
        }
        if (CONFIG.PLAYLIST_REFRESH_INTERVAL <= 0) {
            console.log('[定时刷新] 刷新间隔为0，不启用定时刷新');
            return;
        }
        state.timers.refreshPlaylist = setTimeout(() => {
            console.log(`[定时刷新] 开始刷新频道列表...`);
            refreshM3UPlaylist();
        }, CONFIG.PLAYLIST_REFRESH_INTERVAL);
        console.log(`[定时刷新] 已设置定时器，${Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL/1000)}秒后刷新`);
    }
    function refreshM3UPlaylist() {
        if (!state.isM3UPlaylist || !state.originalPlaylistUrl) {
            console.warn("[定时刷新] 当前不是M3U频道列表或缺少原始URL");
            startPlaylistRefreshTimer();
            return;
        }
        console.log(`[定时刷新] 刷新频道列表: ${state.originalPlaylistUrl}`);
        const parser = new M3UParser;
        parser.parseFromUrl(state.originalPlaylistUrl).then(playlist => {
            if (!playlist || playlist.length === 0) {
                console.warn("[定时刷新] 刷新的频道列表为空");
                startPlaylistRefreshTimer();
                return;
            }
            const processedPlaylist = playlist.map(item => {
                const rawUrls = item.urls && item.urls.length > 0 ? item.urls : [item.url];
                const validUrls = rawUrls.filter(u => u).map(u => {
                    if (!u.startsWith("http") && !u.startsWith("//")) {
                        return M3UParser.resolveUrl(state.baseUrl, u);
                    }
                    return u;
                });
                item.urls = validUrls;
                return item;
            }).filter(item => item.urls.length > 0);
            if (processedPlaylist.length === 0) {
                console.warn("[定时刷新] 解析后无有效项目");
                startPlaylistRefreshTimer();
                return;
            }
            refreshPlaylist(processedPlaylist);
            startPlaylistRefreshTimer();
        }).catch(err => {
            console.error("[定时刷新] M3U解析失败:", err);
            startPlaylistRefreshTimer();
        });
    }
    function refreshPlaylist(newPlaylist) {
        console.log('[定时刷新] 开始刷新频道列表...');
        const oldIndex = state.currentPlaylistIndex;
        const oldItem = oldIndex >= 0 ? state.currentPlaylist[oldIndex] : null;
        if (oldItem) {
            state.currentChannelInfo = {
                title: oldItem.title || "",
                originalIndex: oldIndex,
                urls: [...oldItem.urls],
                currentUrlIndex: oldItem.currentUrlIndex || 0,
                currentRound: oldItem.currentRound || 1
            };
            console.log(`[定时刷新] 保存当前频道: "${state.currentChannelInfo.title}"`);
        }
        const oldPlaylist = [...state.currentPlaylist];
        state.currentPlaylist = newPlaylist;
        let newIndex = -1;
        if (state.currentChannelInfo.title) {
            newIndex = state.currentPlaylist.findIndex(item =>
                item.title === state.currentChannelInfo.title
            );
            if (newIndex === -1 && state.currentChannelInfo.urls.length > 0) {
                newIndex = state.currentPlaylist.findIndex(item =>
                    item.urls && item.urls.some(url =>
                        state.currentChannelInfo.urls.includes(url)
                    )
                );
            }
        }
        if (newIndex === -1) {
            console.log(`[定时刷新] 当前频道在新列表中不存在，继续播放原频道`);
            if (oldItem) {
                const preservedItem = {
                    ...oldItem,
                    title: oldItem.title ? `${oldItem.title}${i18n.t('player_old_list_suffix')}` : i18n.t('player_old_list_channel_name'),
                    isFromOldList: true,
                };
                state.currentPlaylist.push(preservedItem);
                newIndex = state.currentPlaylist.length - 1;
                state.currentPlaylistIndex = newIndex;
            }
        } else {
            console.log(`[定时刷新] 在新列表中找到当前频道，位置: ${newIndex}`);
            state.currentPlaylistIndex = newIndex;
            const newItem = state.currentPlaylist[newIndex];
            if (newItem.urls && newItem.urls.length > 0) {
                newItem.currentUrlIndex = oldItem ? oldItem.currentUrlIndex || 0 : 0;
                newItem.currentRound = oldItem ? oldItem.currentRound || 1 : 1;
            }
        }
        renderPlaylist(UI.playlistSearchInput.value);
        updatePlaylistHighlight("center");
        if (!UI.playlistContainer.classList.contains("hidden")) {
            const currentSearch = UI.playlistSearchInput.value;
            if (currentSearch) {
                renderPlaylist(currentSearch);
            }
            addRefreshIndicator();
        }
        showNotification(i18n.t('player_playlist_refreshed', { OLD: oldPlaylist.length, NEW: newPlaylist.length }),'success', 3000);
        console.log(`[定时刷新] 频道列表刷新完成: ${oldPlaylist.length} → ${newPlaylist.length} 个频道`);
    }
    function addRefreshIndicator() {
        const oldIndicator = UI.playlistContainer.querySelector('.refresh-indicator');
        if (oldIndicator) {
            oldIndicator.remove();
        }
        const indicator = document.createElement('div');
        indicator.className = 'refresh-indicator';
        indicator.textContent = i18n.t('player_refreshing');
        indicator.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 100, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 1002;
        `;
        UI.playlistContainer.appendChild(indicator);
        setTimeout(() => {
            if (indicator.parentNode) {
                indicator.parentNode.removeChild(indicator);
            }
        }, 1500);
    }
    function manualSwitchToNextSource() {
        if (!state.isM3UPlaylist) {
            showNotification(i18n.t('player_not_playlist_mode'), 'warning', 2000);
            return;
        }    
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError(i18n.t('player_err_no_source_available'));
            return;
        }
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        if (item.currentRound === undefined) item.currentRound = 1;
        const nextIndex = (item.currentUrlIndex + 1) % item.urls.length;
        if (nextIndex === 0) {
            if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
                item.currentRound++;
            }
        }
        console.log(`[手动换源] 从源 ${item.currentUrlIndex + 1} 切换到源 ${nextIndex + 1} (轮次: ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS})`);
        item.currentUrlIndex = nextIndex;
        const nextUrl = item.urls[nextIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "手动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => manualSwitchToNextSource(), 500);
            return;
        }
        showLoading(true);
        UI.errorMessage.style.display = "none";
        showNotification(i18n.t('player_switch_source', { CUR: nextIndex + 1, TOTAL: item.urls.length }), 2000);
        destroyPlayer();
        checkAndInitPlayer(nextUrl);
        if (state.timers.load) clearTimeout(state.timers.load);
        state.timers.load = setTimeout(() => {
            console.error(`[手动换源] 加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，触发自动换源逻辑。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
        setTimeout(updateInfoPanel, 500);
    }
    /**
     * 通知组件
     * 优点：无需外部 CSS，逻辑完全闭环，动画与销毁精准同步
     */
    function showNotification(message, type = 'info', duration = 2000) {
        const typeStyles = {
            'info': 'rgba(0, 100, 200, 0.9)',
            'success': 'rgba(40, 167, 69, 0.9)',
            'warning': 'rgba(255, 152, 0, 0.9)'
        };
        const backgroundColor = typeStyles[type] || typeStyles['info'];
        let notification = playerContainer.querySelector('.source-notification');
        // 1. 获取或创建元素
        if (!notification) {
            notification = document.createElement("div");
            notification.className = "source-notification";
            Object.assign(notification.style, {
                position: 'absolute',
                top: '20px',
                left: '50%',
                transform: 'translateX(-50%)',
                color: 'white',
                padding: '10px 15px',
                borderRadius: '5px',
                zIndex: '1000',
                fontSize: '14px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                pointerEvents: 'none',
                //whiteSpace: 'nowrap' // 防止内容换行抖动
                whiteSpace: 'pre'
            });
            playerContainer.appendChild(notification);
        }
        // 2. 更新属性
        notification.textContent = message;
        notification.style.background = backgroundColor;
        // 3. 核心：WAAPI 动画控制
        // 如果已有动画正在运行（包括淡出），立即取消它
        if (notification.currentAnim) {
            notification.currentAnim.cancel();
        }
        // 定义关键帧：入场(0-10%) -> 停留(10-90%) -> 离场(90-100%)
        const animation = notification.animate([
            { opacity: 0, transform: 'translateX(-50%) translateY(-20px)' }, // 起点：上方隐身
            { opacity: 1, transform: 'translateX(-50%) translateY(0)', offset: 0.1 }, // 10% 时间点入场完成
            { opacity: 1, transform: 'translateX(-50%) translateY(0)', offset: 0.9 }, // 保持到 90%
            { opacity: 0, transform: 'translateX(-50%) translateY(-10px)' } // 终点：略微上移消失
        ], {
            duration: duration,
            easing: 'ease-out',
            fill: 'forwards'
        });
        notification.currentAnim = animation;
        // 4. 精准销毁：动画真正结束时才移除 DOM
        animation.onfinish = () => {
            // 只有当动画确实播完（不是被 cancel）才移除
            if (animation.playState === 'finished' && notification.parentNode) {
                notification.remove();
            }
        };
    }
    function tryNextRedundantUrl() {
        if (state.currentPlaylistIndex === -1) return;
        const item = state.currentPlaylist[state.currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0) {
            showError(i18n.t('player_err_playlist_data_error'));
            return;
        }
        if (item.currentRound === undefined) item.currentRound = 1;
        if (item.currentUrlIndex === undefined) item.currentUrlIndex = 0;
        const nextIndex = item.currentUrlIndex + 1;
        if (nextIndex < item.urls.length) {
            item.currentUrlIndex = nextIndex;
        } else if (item.currentRound < CONFIG.MAX_RETRY_ROUNDS) {
            item.currentUrlIndex = 0;
            item.currentRound++;
            console.warn(`频道 [${item.title}] 开启第 ${item.currentRound}/${CONFIG.MAX_RETRY_ROUNDS} 轮尝试...`);
            showNotification(i18n.t('player_retry_round', { CUR: item.currentRound, TOTAL: CONFIG.MAX_RETRY_ROUNDS }), 2000);
        } else {
            if (state.timers.load) {
                clearTimeout(state.timers.load);
                state.timers.load = null;
            }
            destroyPlayer();
            state.isPlaying = false;
            UI.playPauseBtn.textContent = "▶";
            //UI.playPauseBtn.title = "播放";
            UI.playPauseBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_play_simple'));
            showError(i18n.t('player_err_channel_unplayable', { NAME: item.title || i18n.t('player_unknown') }));
            return;
        }
        const nextUrl = item.urls[item.currentUrlIndex];
        // 检查黑名单
        if (checkUrlInBlacklist(nextUrl, "自动换源URL")) {
            // 如果被拦截，继续尝试下一个
            setTimeout(() => tryNextRedundantUrl(), 500);
            return;
        }
        console.warn(`自动换源 (轮次:${item.currentRound}, 索引:${item.currentUrlIndex}): ${nextUrl}`);
        showNotification(i18n.t('player_auto_switch_source', { CUR: item.currentUrlIndex + 1, TOTAL: item.urls.length }), 1500);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
        state.timers.load = setTimeout(() => {
            console.error(`加载超时 (${CONFIG.LOAD_TIMEOUT_MS}ms)，切换线路。`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function playPlaylistItem(index) {
        if (index < 0 || index >= state.currentPlaylist.length) return;
        const item = state.currentPlaylist[index];
        state.currentPlaylistIndex = index;  // 先更新索引，视觉上先高亮
        // 寻找第一个未被黑名单拦截的源
        let validUrlIndex = -1;
        for (let i = 0; i < item.urls.length; i++) {
            if (!checkUrlInBlacklist(item.urls[i], "频道初始URL")) {
                validUrlIndex = i;
                break;
            }
        }
        if (validUrlIndex === -1) {
            // 所有源都被拦截
            showNotification(i18n.t('player_channel_all_sources_blacklisted', { NAME: item.title || i18n.t('player_unknown_channel') }), 5000);
            // 自动尝试下一个频道（递归，但加保护防止无限循环）
            /*const nextIndex = index + 1;
            if (nextIndex < state.currentPlaylist.length) {
                setTimeout(() => playPlaylistItem(nextIndex), 800); // 稍延时避免太快闪屏
            } else {
                showError(i18n.t('player_err_all_remaining_blacklisted'), true);
                destroyPlayer();
                showLoading(false);
            }*/
            return;
        }
        if (validUrlIndex > 0) {
            showNotification(i18n.t('player_skip_blacklisted_sources', { COUNT: validUrlIndex, INDEX: validUrlIndex + 1 }), 3000);
        }
        // 有可用源，开始播放
        item.currentUrlIndex = validUrlIndex;
        item.currentRound = 1;
        updatePlaylistHighlight();
        UI.videoInfo.textContent = item.title || decodeURIComponent(item.urls[validUrlIndex]);
        destroyPlayer();
        showLoading(true);
        UI.errorMessage.style.display = "none";
        checkAndInitPlayer(item.urls[validUrlIndex]);
        // 加载超时保护
        state.timers.load = setTimeout(() => {
            console.error(`加载超时，尝试频道内/下一个源`);
            tryNextRedundantUrl();
        }, CONFIG.LOAD_TIMEOUT_MS);
    }
    function renderPlaylist(searchTerm = "") {
        UI.playlistItems.innerHTML = "";
        const lowerTerm = searchTerm.toLowerCase();
        const fragment = document.createDocumentFragment();
        state.currentPlaylist.forEach((item, index) => {
            const channelName = item.title || i18n.t('player_item_n', { N: index + 1 });
            // 创建元素
            const el = document.createElement("div");
            el.className = "playlist-item";
            el.setAttribute('tabindex', '-1');
            if (index === state.currentPlaylistIndex) el.classList.add("active");
            el.textContent = channelName;  // 显示只用频道名
            el.dataset.index = index;
            // 新增：准备可搜索的完整文本（频道名 + 节目名）
            let searchText = channelName.toLowerCase();
            // 如果 EPG 启用且有当前节目，加入节目名
            if (CONFIG.EPG_ENABLED) {
                const chId = getChannelId(item);
                const programs = state.epgData[chId] || [];
                const current = getCurrentProgram(programs);
                if (current) {
                    // 创建显示用的 span（保持原样）
                    const span = document.createElement('span');
                    span.className = 'current-program';
                    span.textContent = `${i18n.t('player_epg_current_label')} ${current.title}`;
                    el.appendChild(span);
                    // 加入节目名到搜索文本（加空格分隔，便于搜索）
                    searchText += ` ${current.title.toLowerCase()}`;
                }
            }
            // 存到 data-search-text 属性，用于后续过滤
            el.setAttribute('data-search-text', searchText);
            // 搜索过滤：用 data-search-text 判断是否匹配
            if (searchTerm && !el.getAttribute('data-search-text').includes(lowerTerm)) {
                return;  // 不匹配就跳过
            }
            // 后续原有逻辑（onclick、EPG popup、事件绑定等）
            el.onclick = () => {
                playPlaylistItem(index);
                maintainPlaylistFocus();
            };
            setupButtonHoverEffects(el);
            el.addEventListener('mouseenter', () => showEpgPopup(el, item));
            el.addEventListener('mouseleave', hideEpgPopup);
            el.addEventListener('focus', () => showEpgPopup(el, item));
            el.addEventListener('blur', hideEpgPopup);
            fragment.appendChild(el);
        });
        UI.playlistItems.appendChild(fragment);
    }
    /**
     * 更新播放列表高亮并滚动到视野
     * @param {string} blockScroll - 滚动对齐方式，可选 "nearest", "center", "start", "end"。默认为 "nearest"。
     */
    function updatePlaylistHighlight(blockScroll = "nearest") {
        const items = UI.playlistItems.children;
        const container = UI.playlistItems; // 假设这是滚动的父容器
        const currentIndex = state.currentPlaylistIndex;
        for (let el of items) {
            if (parseInt(el.dataset.index) === currentIndex) {
                el.classList.add("active");
                if (blockScroll === "center") {
                    // --- 手动计算居中逻辑 ---
                    // 目标元素相对于容器顶部的距离 + 元素高度的一半 - 容器高度的一半
                    const elementTop = el.offsetTop;
                    const elementHeight = el.offsetHeight;
                    const containerHeight = container.clientHeight;
                    container.scrollTo({
                        top: elementTop - (containerHeight / 2) + (elementHeight / 2),
                        behavior: "instant"
                    });
                } else if (blockScroll === "nearest") {
                    // nearest 模式下原生方法通常表现良好
                    el.scrollIntoView({ behavior: "instant", block: "nearest" });
                }
            } else {
                el.classList.remove("active");
            }
        }
    }
    function handlePlaylistSearch(e) {
        const term = e.target.value;
        if (term) UI.clearSearchBtn.classList.add("visible");
        else UI.clearSearchBtn.classList.remove("visible");
        if (state.timers.searchDebounce) clearTimeout(state.timers.searchDebounce);
        state.timers.searchDebounce = setTimeout(() => {
            renderPlaylist(term);
            // 搜索后清除选中项
            const selectedItem = UI.playlistItems.querySelector('.selected');
            if (selectedItem) {
                selectedItem.classList.remove('selected');
            }
        }, CONFIG.SEARCH_DEBOUNCE_MS);
    }
    function clearSearch() {
        UI.playlistSearchInput.value = "";
        UI.clearSearchBtn.classList.remove("visible");
        renderPlaylist("");
        // 清除选中项
        const selectedItem = UI.playlistItems.querySelector('.selected');
        if (selectedItem) {
            selectedItem.classList.remove('selected');
        }
    }
    function updateSearchPlaceholder() {
        if (UI.playlistSearchInput) {
            if (CONFIG.EPG_ENABLED) {
                UI.playlistSearchInput.placeholder = i18n.t('player_search_placeholder_epg');
            } else {
                UI.playlistSearchInput.placeholder = i18n.t('player_search_placeholder');
            }
        }
    }
    function updateVideoInfoFromElement() {
        if (UI.videoPlayer.videoWidth && UI.videoPlayer.videoHeight) {
            state.streamInfo.resolution = `${UI.videoPlayer.videoWidth}x${UI.videoPlayer.videoHeight}`;
        }
        updateInfoPanel();
    }
    function updateResolutionFromHls(hls) {
        if (!hls?.levels?.length) return;
        let idx = hls.currentLevel;
        // 自动模式下优先使用最近一次自适应结果
        if (idx < 0 && hls.autoLevelEnabled) {
            idx = hls.autoLevelLast >= 0 ? hls.autoLevelLast :
                  hls.nextLoadLevel >= 0   ? hls.nextLoadLevel : 0;
        }
        // 防止索引越界（虽然正常情况下不应该发生，但防御性编程）
        idx = Math.max(0, Math.min(idx, hls.levels.length - 1));
        const level = hls.levels[idx];
        if (level?.width > 0 && level?.height > 0) {
            state.streamInfo.resolution = `${level.width}×${level.height}`;
        }
        // 可选：增加 video 元素 fallback（最保险）
        else if (hls.media?.videoWidth > 0 && hls.media?.videoHeight > 0) {
            state.streamInfo.resolution = `${hls.media.videoWidth}×${hls.media.videoHeight}(ｖ)`;
        }
        updateInfoPanel();
    }
    /**
     * 更新信息面板
     * 采用声明式数据结构，确保冒号贴合文字且数值垂直对齐
     */
    function updateInfoPanel() {
        if (!UI.infoPanel) return;
        // 1. 构造结构化数据数组 (Label/Value 分离)
        const infoItems = [
            { label: i18n.t('player_info_label_type'), value: state.streamInfo.type },
            { label: i18n.t('player_info_label_resolution'), value: state.streamInfo.resolution }
        ];
        // HLS 特有信息
        if (state.streamInfo.type === "HLS") {
            infoItems.push({ label: i18n.t('player_info_label_bitrate'), value: state.streamInfo.bitrate });
        }
        // 编码格式支持判断
        const codecSupported = ["HLS", "TS", "FLV"];
        if (codecSupported.includes(state.streamInfo.type)) {
            infoItems.push({ label: i18n.t('player_info_label_codec'), value: state.streamInfo.codec });
        }
        // 播放列表与源信息
        if (state.isM3UPlaylist && state.currentPlaylist && state.currentPlaylistIndex >= 0) {
            const item = state.currentPlaylist[state.currentPlaylistIndex];
            if (item) {
                const totalUrls = Array.isArray(item.urls) ? item.urls.length : 0;
                if (totalUrls >= 1) {
                    const currentIndex = (Number(item.currentUrlIndex) || 0) + 1;
                    infoItems.push({ label: i18n.t('player_info_label_source'), value: `${currentIndex}/${totalUrls}` });
                }
                infoItems.push({ 
                    label: i18n.t('player_playlist_title'), 
                    value: `${state.currentPlaylistIndex + 1}/${state.currentPlaylist.length}` 
                });
                // 自动刷新配置
                if (CONFIG.AUTO_REFRESH_ENABLED && state.timers?.refreshPlaylist) {
                    const refreshMin = Math.round(CONFIG.PLAYLIST_REFRESH_INTERVAL / 60000);
                    infoItems.push({ label: i18n.t('player_info_label_refresh'), value: `${refreshMin} ${i18n.t('player_info_label_refreshMin')}` });
                }
                // 状态标签
                //if (item.title && String(item.title).includes("(旧列表)")) {
                //    infoItems.push({ label: '状态', value: '来自旧列表' });
                //}
                // 状态标签：用显式的 isFromOldList 标记判断，不能靠匹配标题文本里
                // 有没有"(旧列表)"这几个字——文案换成英文之后这个匹配就会失效。
                if (item.isFromOldList) {
                    infoItems.push({ label: i18n.t('player_info_label_status'), value: i18n.t('player_info_status_from_old_list') });
                }
            }
        }
        // 黑名单信息
        if (Array.isArray(state.blacklist) && state.blacklist.length > 0) {
            infoItems.push({ label: i18n.t('player_info_label_blacklist'), value: i18n.t('player_info_rule_count', { N: state.blacklist.length }) });
        }
        // 2. 渲染 HTML (使用 CSS Grid 结构)
        // 过滤掉空值，映射为标准网格行
        UI.infoPanel.innerHTML = infoItems
            .filter(item => item.value !== undefined && item.value !== null && item.value !== '')
            .map(item => `
                <div class="info-row">
                    <div class="info-label-group">
                        <span class="info-label">${item.label}</span>
                        <span class="info-colon">:</span>
                    </div>
                    <div class="info-value">${item.value}</div>
                </div>
            `).join('');
    }
    function toggleVideoInfo() {
        updateInfoPanel();
        const currentDisplay = UI.infoPanel.style.display;
        UI.infoPanel.style.display = currentDisplay === "none" ? "block" : "none";
    }
    function updateProgress() {
        const { currentTime, duration } = UI.videoPlayer;
        if (duration && !isNaN(duration) && duration !== Infinity) {
            const percent = currentTime / duration * 100;
            UI.progressBar.style.width = percent + "%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / ${formatTime(duration)}`;
        } else {
            UI.progressBar.style.width = "100%";
            UI.timeDisplay.textContent = `${formatTime(currentTime)} / Live`;
        }
    }
    function seek(e) {
        if (!UI.videoPlayer.duration || UI.videoPlayer.duration === Infinity) return;
        const rect = UI.progress.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        UI.videoPlayer.currentTime = pos * UI.videoPlayer.duration;
    }
    function adjustVolume(e) {
        const rect = UI.volumeSlider.getBoundingClientRect();
        let volume = (e.clientX - rect.left) / rect.width;
        volume = Math.max(0, Math.min(1, volume));
        UI.videoPlayer.volume = volume;
        UI.volumeProgress.style.width = volume * 100 + "%";
        updateVolumeIcon();
        chrome.storage.local.set({
            volume: volume
        });
    }
    function updateVolumeIcon() {
        const v = UI.videoPlayer.volume;
        if (UI.videoPlayer.muted || v === 0) { UI.volumeBtn.textContent = "🔇"; UI.volumeBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_unmute')); }
        else if (v < .5) { UI.volumeBtn.textContent = "🔉"; UI.volumeBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_mute')); }
        else { UI.volumeBtn.textContent = "🔊"; UI.volumeBtn.setAttribute("data-tooltip", i18n.t('player_tooltip_mute')); }
    }
    function toggleMute() {
        UI.videoPlayer.muted = !UI.videoPlayer.muted;
        updateVolumeIcon();
    }
    function toggleFullscreen() {
        const container = document.querySelector(".player-container");
        if (!document.fullscreenElement) {
            (container.requestFullscreen || container.webkitRequestFullscreen || container.msRequestFullscreen).call(container);
        } else {
            (document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen).call(document);
        }
    }
    /**
     * 响度均衡 和 实时字幕(SODA) 共用的音频抽取图。
     *
     * 背景：AudioContext.createMediaElementSource() 对同一个 <video> 元素
     * 在其整个 DOM 生命周期内只能成功调用一次——这是浏览器级限制，换成
     * 新的 AudioContext 也没用。之前响度均衡和 soda-asr.js 各自独立
     * new AudioContext() + createMediaElementSource(video)，谁先调用谁
     * 成功，后调用的必定抛 InvalidStateError（响度均衡这边这个异常被
     * try/catch 悄悄吞掉，UI 却仍提示"已开启"，实际完全不生效；SODA
     * 那边会弹出"启动失败"提示）。
     *
     * 现在改成两边共用同一个 sourceNode：谁先用到就在这里建立，之后
     * 都从这里拿，不再各自 createMediaElementSource。
     */
    function _ensureSharedAudioGraph() {
        if (state.audioContext && state.sourceNode) {
            return { audioContext: state.audioContext, sourceNode: state.sourceNode };
        }
        try {
            state.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            state.sourceNode = state.audioContext.createMediaElementSource(UI.videoPlayer);
            state.dynamicsCompressor = state.audioContext.createDynamicsCompressor();
            // 配置压缩器以实现响度均衡
            state.dynamicsCompressor.threshold.setValueAtTime(-24, state.audioContext.currentTime);
            state.dynamicsCompressor.knee.setValueAtTime(30, state.audioContext.currentTime);
            state.dynamicsCompressor.ratio.setValueAtTime(12, state.audioContext.currentTime);
            state.dynamicsCompressor.attack.setValueAtTime(0.003, state.audioContext.currentTime);
            state.dynamicsCompressor.release.setValueAtTime(0.25, state.audioContext.currentTime);
            // 初始连接（不经过压缩器），保证一建好图就有声音
            state.sourceNode.connect(state.audioContext.destination);
        } catch (e) {
            console.error('Web Audio API 初始化失败:', e);
            state.audioContext = null;
            state.sourceNode = null;
        }
        return { audioContext: state.audioContext, sourceNode: state.sourceNode };
    }
    function initAudioContext() {
        _ensureSharedAudioGraph();
    }

    /**
     * 供实时字幕(SODA) 使用：从共享 sourceNode 上再接一路到
     * MediaStreamDestination，取得可以喂给 SpeechRecognition.start(track)
     * 的 MediaStreamTrack。这一路连接是独立、常驻的分支，不受响度均衡开关
     * 时 _reconnectAudioGraph() 里"可听输出"支路的断开/重连影响
     * （见该函数里改成只断开自己管理的两条连接，不再整体 disconnect()）。
     * 只建立一次，之后重复调用直接复用。
     */
    function _ensureSodaAudioTrack() {
        const { audioContext, sourceNode } = _ensureSharedAudioGraph();
        if (!audioContext || !sourceNode) return null;
        if (!state.sodaDestNode) {
            state.sodaDestNode = audioContext.createMediaStreamDestination();
            sourceNode.connect(state.sodaDestNode);
        }
        const track = state.sodaDestNode.stream.getAudioTracks()[0];
        return track ? { audioContext, track } : null;
    }

    /**
     * 统一重建音频图，根据响度均衡开关决定是否插入 dynamicsCompressor。
     *
     *   响度关闭：sourceNode ──────────────────── destination
     *   响度开启：sourceNode → dynamicsCompressor → destination
     *
     * 调用时机：切换响度均衡时。
     *
     * 注意：sourceNode 上可能还挂着喂给 SODA 实时字幕用的那一路
     * （见 _ensureSodaAudioTrack），这里只能断开"可听输出"这条支路自己
     * 管理的连接（destination / compressor），不能对 sourceNode 整体调用
     * 不带参数的 disconnect()，否则会把 SODA 那一路也一起断掉，导致
     * 字幕跟着响度均衡的开关状态莫名其妙地失效。
     */
    function _reconnectAudioGraph() {
        const ctx        = state.audioContext;
        const src        = state.sourceNode;
        const compressor = state.dynamicsCompressor;
        if (!ctx || !src) return;

        // 只断开自己管理的两条连接，SODA 挂在 sourceNode 上的那一路不受影响
        try { src.disconnect(compressor); }        catch (_) {}
        try { src.disconnect(ctx.destination); }    catch (_) {}
        try { compressor.disconnect(ctx.destination); } catch (_) {}

        // 重建主音频链路
        if (state.isLoudnessEnabled) {
            src.connect(compressor);
            compressor.connect(ctx.destination);
        } else {
            src.connect(ctx.destination);
        }
    }

    function toggleLoudnessEqualizer(forceState) {
        if (!state.audioContext) initAudioContext();
        if (!state.audioContext) return;
        // 修复：如果是点击事件触发，forceState 会是 Event 对象，此时应视为 undefined
        const actualForceState = (typeof forceState === 'boolean') ? forceState : undefined;
        if (actualForceState !== undefined) {
            state.isLoudnessEnabled = actualForceState;
        } else {
            state.isLoudnessEnabled = !state.isLoudnessEnabled;
        }
        // 保存状态到 storage
        chrome.storage.local.set({ loudnessEnabled: state.isLoudnessEnabled });
        // 统一重建音频图（响度均衡开关）
        _reconnectAudioGraph();
        if (state.isLoudnessEnabled) {
            UI.loudnessBtn.style.color = '#1E90FF';
            showNotification(i18n.t('player_loudness_on'), 'success', 1500);
        } else {
            UI.loudnessBtn.style.color = '#9CA3AF';
            showNotification(i18n.t('player_loudness_off'), 1500);
        }
        if (state.audioContext.state === 'suspended') {
            state.audioContext.resume();
        }
    }
    function togglePlayPause() {
        if (UI.videoPlayer.paused) attemptPlay();
        else UI.videoPlayer.pause();
    }
    function showControls() {
        UI.controls.classList.remove("hidden");
        if (state.timers.controls) clearTimeout(state.timers.controls);
        state.timers.controls = setTimeout(() => {
            if (state.isPlaying) {
                UI.controls.classList.add("hidden");
            }
        }, 10000);
    }
    function initGlobalEvents() {
        document.addEventListener("mousemove", showControls);
        document.addEventListener("click", showControls);
        document.addEventListener("keydown", handleKeyDown);
        // 进阶面板开关
        UI.advancedBtn.onclick = (e) => {
            e.stopPropagation();
            showControls();
            const isVisible = UI.advancedPanel.style.display !== 'none';
            UI.advancedPanel.style.display = isVisible ? 'none' : 'block';
        };
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.advanced-btn') &&
                !e.target.closest('.advanced-panel')) {
                if (UI.advancedPanel) UI.advancedPanel.style.display = 'none';
            }
        });
        UI.playPauseBtn.onclick = togglePlayPause;
        UI.prevChannelBtn.onclick = function(e) {
            e.stopPropagation();
            showControls();
            switchToPrevChannel();
        };
        UI.nextChannelBtn.onclick = function(e) {
            e.stopPropagation();
            showControls();
            switchToNextChannel();
        };
        UI.volumeBtn.onclick = toggleMute;
        //─────────── 音量条拖动支持 ───────────────────────────────────
        let isDraggingVolume = false;
        const volumeTooltip = document.getElementById('volume-tooltip');
        function updateVolumeFromMouse(e) {
            if (!isDraggingVolume) return;
            const rect = UI.volumeSlider.getBoundingClientRect();
            let volume = (e.clientX - rect.left) / rect.width;
            volume = Math.max(0, Math.min(1, volume));
            UI.videoPlayer.volume = volume;
            UI.volumeProgress.style.width = `${volume * 100}%`;
            updateVolumeIcon();
            // ─── 新增：实时更新音量数值提示 ────────────────────────
            if (volumeTooltip) {
                const percent = Math.round(volume * 100);
                volumeTooltip.textContent = `${percent}%`;
                volumeTooltip.classList.remove('hidden');
            }
        }
        UI.volumeSlider.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            isDraggingVolume = true;
            updateVolumeFromMouse(e);   // 按下时立即显示
            e.preventDefault();
        });
        document.addEventListener('mousemove', updateVolumeFromMouse);
        document.addEventListener('mouseup', (e) => {
            if (e.button !== 0) return;
            if (isDraggingVolume) {
                isDraggingVolume = false;
                chrome.storage.local.set({ volume: UI.videoPlayer.volume });
                // ─── 松开后隐藏提示（可加淡出效果） ────────────────────────
                if (volumeTooltip) {
                    volumeTooltip.classList.add('hidden');
                }
            }
        });
        // 鼠标离开音量条区域也隐藏（可选）
        //UI.volumeSlider.addEventListener('mouseleave', () => {
        //    isDraggingVolume = false;
        //    if (volumeTooltip) {
        //        volumeTooltip.classList.add('hidden');
        //    }
        //});
        // ──────进度条拖动 + 悬浮/拖动时显示时间提示 + 拖动时智能暂停/恢复────────────────────────
        let isDraggingProgress = false;
        let wasPlayingBeforeDrag = false;  // 新增：记录拖动前的播放状态
        const progressTooltip = document.getElementById('progress-tooltip');
        // 计算位置并更新 tooltip 的核心函数（保持不变）
        function updateProgressTooltip(e) {
            if (!UI.videoPlayer.duration || isNaN(UI.videoPlayer.duration) || UI.videoPlayer.duration === Infinity) {
                if (progressTooltip) progressTooltip.classList.add('hidden');
                return;
            }
            const rect = UI.progress.getBoundingClientRect();
            const isOverProgress = (
                e.clientX >= rect.left &&
                e.clientX <= rect.right &&
                e.clientY >= rect.top &&
                e.clientY <= rect.bottom
            );
            if (!isOverProgress) {
                if (progressTooltip) progressTooltip.classList.add('hidden');
                return;
            }
            let pos = (e.clientX - rect.left) / rect.width;
            pos = Math.max(0, Math.min(1, pos));
            const time = pos * UI.videoPlayer.duration;
            if (progressTooltip) {
                progressTooltip.textContent = formatTime(time);
                // 或者更完整：`${formatTime(time)} / ${formatTime(UI.videoPlayer.duration)}`
                const tooltipX = e.clientX - rect.left;
                progressTooltip.style.left = `${tooltipX}px`;
                progressTooltip.classList.remove('hidden');
            }
        }
        // 拖动时更新进度 + tooltip（保持不变）
        function updateProgressFromMouse(e) {
            if (!isDraggingProgress) return;
            const rect = UI.progress.getBoundingClientRect();
            let pos = (e.clientX - rect.left) / rect.width;
            pos = Math.max(0, Math.min(1, pos));
            if (UI.videoPlayer.duration && !isNaN(UI.videoPlayer.duration) && UI.videoPlayer.duration !== Infinity) {
                UI.videoPlayer.currentTime = pos * UI.videoPlayer.duration;
                UI.progressBar.style.width = `${pos * 100}%`;
                UI.timeDisplay.textContent = `${formatTime(UI.videoPlayer.currentTime)} / ${formatTime(UI.videoPlayer.duration)}`;
            }
            // 拖动时也更新 tooltip
            updateProgressTooltip(e);
        }
        // 按下鼠标开始拖动（新增暂停逻辑）
        UI.progress.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            // 记录拖动前的播放状态
            wasPlayingBeforeDrag = !UI.videoPlayer.paused;
            // 如果正在播放，则暂停（拖动期间画面不继续动）
            if (wasPlayingBeforeDrag) {
                UI.videoPlayer.pause();
            }
            isDraggingProgress = true;
            updateProgressFromMouse(e);
            updateProgressTooltip(e);
            e.preventDefault();
        });
        // 鼠标移动（全局监听，但内部判断）
        document.addEventListener('mousemove', (e) => {
            if (isDraggingProgress) {
                updateProgressFromMouse(e);
            } else {
                updateProgressTooltip(e); // 只在进度条区域内显示
            }
        });
        // 松开鼠标结束拖动（新增恢复播放逻辑）
        document.addEventListener('mouseup', (e) => {
            if (e.button !== 0) return;
            if (isDraggingProgress) {
                isDraggingProgress = false;
                // 如果拖动前正在播放，则恢复播放
                if (wasPlayingBeforeDrag) {
                    setTimeout(() => {
                        UI.videoPlayer.play().catch(err => console.warn("恢复播放失败:", err));
                    }, 100);  // 100ms 延迟
                }
                // 松开后延迟隐藏 tooltip（更自然）
                if (progressTooltip) {
                    setTimeout(() => progressTooltip.classList.add('hidden'), 200);
                }
            }
        });
        // 离开进度条区域强制隐藏（保持不变）
        UI.progress.addEventListener('mouseleave', () => {
            if (progressTooltip) {
                progressTooltip.classList.add('hidden');
            }
            // 注意：这里不强制结束拖动状态（isDraggingProgress），因为鼠标可能只是短暂离开
            // 如果你希望离开就结束拖动，可加：isDraggingProgress = false;
        });
        // ─────────────────────────────────────────────────────────────
        UI.fullscreenBtn.onclick = toggleFullscreen;
        UI.backBtn.onclick = () => window.close();
        UI.infoBtn.onclick = toggleVideoInfo;
        UI.playlistBtn.onclick = () => togglePlaylistUI();
        UI.closePlaylistBtn.onclick = () => togglePlaylistUI(false);
        UI.playlistSearchInput.oninput = handlePlaylistSearch;
        UI.clearSearchBtn.onclick = clearSearch;
        UI.switchSourceBtn.onclick = function(e) {
            e.stopPropagation();
            showControls();
            manualSwitchToNextSource();
        };
        UI.playlistContainer.onmouseleave = () => {
            if (document.activeElement !== UI.playlistSearchInput) {
                state.timers.hidePlaylist = setTimeout(() => togglePlaylistUI(false), 300);
            }
        };
        UI.playlistContainer.onmouseenter = () => {
            if (state.timers.hidePlaylist) clearTimeout(state.timers.hidePlaylist);
        };
    }
    window.addEventListener('beforeunload', function() {
        _stopSodaAsr();
        if (state.timers.refreshPlaylist) {
            clearTimeout(state.timers.refreshPlaylist);
            console.log('[清理] 频道列表刷新定时器已清理');
        }
        if (state.timers.load) {
            clearTimeout(state.timers.load);
            console.log('[清理] 加载定时器已清理');
        }
        if (state.timers.stall) {
            clearTimeout(state.timers.stall);
            console.log('[清理] 卡顿定时器已清理');
        }
        if (state.timers.epgRefresh) {
            clearTimeout(state.timers.epgRefresh);
            console.log('[清理] EPG刷新定时器已清理');
        }
    });
    // ════════════════════════════════════════════════════════════════
    //  实时字幕（浏览器原生 SODA 离线语音识别）
    //
    //  核心设计：
    //    ┌─ AudioContext.createMediaElementSource(video) 直接抽取播放器
    //    │    自身的音频轨（同页面同源，无需 tabCapture/offscreen，
    //    │    也不会触发麦克风权限弹窗）
    //    └─ SpeechRecognition({processLocally:true}).start(track)
    //         浏览器内部完成 VAD/分片/推理，onresult 里拿 interim/final
    //         两态文本，实时渲染，不再有分片时间戳对齐的问题
    //
    //  语言可用性 / 模型下载：由 js/soda-panel.js 负责面板 UI，
    //  js/soda-asr.js 里的 SodaAsr.checkAvailability / installLang 探测与下载。
    // ════════════════════════════════════════════════════════════════

    let _sodaAsr = null;

    function _ensureSodaAsr() {
        if (_sodaAsr) return _sodaAsr;
        if (typeof window.SodaAsr !== 'function') {
            console.error('[SodaAsr] js/soda-asr.js 未加载');
            return null;
        }
        _sodaAsr = new window.SodaAsr({
            videoEl: UI.videoPlayer,
            // 复用响度均衡那边已经建立/将会建立的共享音频图，不再自己
            // createMediaElementSource——见 _ensureSharedAudioGraph() 的说明
            getAudioTrack: _ensureSodaAudioTrack,
            onInterim: (text) => {
                state.whisper.interimText = text;
            },
            onFinal: (text) => {
                state.whisper.interimText = '';
                _onFinalTranscript(text);
            },
            onStatus: (st, msg) => {
                _setWhisperUIStatus(st, msg || '');
                if (st === 'running') showNotification(i18n.t('player_caption_enabled'), 'success', 2000);
            },
            onError: (msg) => {
                _setWhisperUIStatus('error', msg);
                showNotification('🎙 ' + msg, 'warning', 5000);
                // 引擎其实没有真正进入运行状态（比如启动失败/语言不可用），
                // 而 UI 却已经乐观地显示"已开启"——这里做自愈复位，
                // 避免下次点击"停止字幕"时因 state.whisper.enabled 状态
                // 不一致而失效，导致界面卡死。
                if (state.whisper.enabled && _sodaAsr && !_sodaAsr.enabled) {
                    _stopSodaAsr();
                }
            },
        });
        return _sodaAsr;
    }

    // 定稿文本入队渲染（SODA 没有 chunk 级时间戳，一条 final 结果显示固定时长）
    // 清洗字幕原文，只保留给总结模型看的纯文本：
    //   · state.whisper.subtitles 里存的是 {text, showAt, hideAt} 对象，showAt/hideAt
    //     是给渲染层用的时间戳，不是字幕内容本身，绝不能被当成文本拼进总结材料里；
    //   · 万一 text 里意外混入 HTML（理论上 SODA 结果是纯文本，但保险起见）也一并去掉；
    //   · 合并多余空白/换行，掐头去尾。
    // 用于总结的原文缓冲区（state.summary.pendingTexts）从一开始就只存清洗后的
    // 纯字符串，不存对象，这样后面拼总结材料时不需要再额外处理。
    function cleanCaptionTextForSummary(text) {
        if (!text) return '';
        return String(text)
            .replace(/<[^>]*>/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    }
    function _onFinalTranscript(text) {
        if (!text) return;
        const now = UI.videoPlayer.currentTime || 0;
        // 按字数粗略估算展示时长，最短 2s，最长 8s
        let hideAt = now + Math.min(8, Math.max(2, text.length / 6));
        state.whisper.subtitles = state.whisper.subtitles || [];
        // 规则同原生字幕：新字幕的消失时间不能早于上一条（更旧）字幕，
        // 避免字数少的新句子比还在显示中的长句子先消失，出现堆叠错位。
        const prev = state.whisper.subtitles[state.whisper.subtitles.length - 1];
        if (prev && hideAt < prev.hideAt) hideAt = prev.hideAt;
        state.whisper.subtitles.push({ text, showAt: now, hideAt });
        if (state.whisper.subtitles.length > 50) {
            state.whisper.subtitles.splice(0, state.whisper.subtitles.length - 50);
        }
        // 视频总结：只在开启时才累积——展示用的 whisper.subtitles 会被裁剪到最近 50 条，
        // 不适合当总结素材的来源，这里用一个完全独立、不裁剪（每轮总结后清空）的纯文本缓冲区。
        if (state.summary.enabled) {
            const cleaned = cleanCaptionTextForSummary(text);
            if (cleaned) state.summary.pendingTexts.push(cleaned);
        }
    }

    // ==================== 视频内容总结（Summarizer API） ====================
    // 参考：https://developer.chrome.com/docs/ai/summarizer-api
    // Summarizer 实际支持作为输出语言的集合非常有限（浏览器控制台报错列出的是
    // [de, en, es, fr, ja]，中文等其余语言直接会被拒绝：
    // "Unsupported Summarizer API languages were specified, and the request was aborted."）。
    // 所以这里分两种语言概念：
    //   · targetLang     —— 最终想要展示给用户的语言（浏览器本地语言）；
    //   · summarizerLang —— 实际喂给 Summarizer 的 outputLanguage：如果 targetLang
    //                        在支持列表里就直接用 targetLang，否则退化成用英文总结。
    // summarizerLang !== targetLang 时（比如目标是中文），总结完成后再调用已有的
    // Translator API（跟字幕翻译共用同一套基础设施）把英文总结译成 targetLang。
    const SUMMARIZER_OUTPUT_LANGS = ['en', 'ja', 'es', 'de', 'fr'];
    function _notifySummaryUpdate() {
        if (typeof state.summary.onUpdate === 'function') {
            try { state.summary.onUpdate(); } catch (e) { /* 面板未打开等原因导致的渲染异常，忽略 */ }
        }
    }
    async function _getSummarizerInstance() {
        if (state.summary.summarizer) return state.summary.summarizer;
        if (!('Summarizer' in self)) {
            console.warn('[VideoSummary] 浏览器不支持 Summarizer API');
            _setSummaryStatusText(i18n.t('player_summary_unsupported'));
            return null;
        }
        const targetLang     = getSubtitleTargetLang();
        const summarizerLang = SUMMARIZER_OUTPUT_LANGS.includes(targetLang) ? targetLang : 'en';
        const createOptions = {
            type: 'key-points',
            format: 'plain-text',
            length: 'medium',
            outputLanguage: summarizerLang,
            sharedContext: i18n.locale === 'zh_CN'
                ? '这是一段视频/直播的实时语音识别字幕原文，请据此总结这段时间视频里发生的主要内容。'
                : 'This is a live speech-recognition transcript of a video/livestream. Summarize the main content that happened during this period.',
            monitor(m) {
                m.addEventListener('downloadprogress', (e) => {
                    const pct = Math.round((e.loaded || 0) * 100);
                    console.log(`[VideoSummary] 总结模型下载中: ${pct}%`);
                    _setSummaryStatusText(i18n.t('player_summary_downloading_model', { PCT: pct }));
                });
            }
        };
        try {
            // 跟 checkTranslatorSupport() 一样做分层探测：优先带完整参数，
            // 不行就退化成不带参数，尽量兼容不同浏览器版本对 availability() 参数的支持差异。
            let availability;
            try {
                availability = await Summarizer.availability({
                    type: createOptions.type,
                    format: createOptions.format,
                    length: createOptions.length,
                    outputLanguage: summarizerLang
                });
            } catch (e) {
                availability = await Summarizer.availability();
            }
            if (availability === 'unavailable') {
                console.warn('[VideoSummary] Summarizer 不可用');
                _setSummaryStatusText(i18n.t('player_summary_unsupported'));
                return null;
            }
            const summarizer = await Summarizer.create(createOptions);
            state.summary.summarizer     = summarizer;
            state.summary.summarizerLang = summarizerLang;
            state.summary.outputLang     = targetLang;
            _setSummaryStatusText('');
            return summarizer;
        } catch (err) {
            console.error('[VideoSummary] 创建 Summarizer 失败:', err);
            _setSummaryStatusText(i18n.t('player_summary_unsupported'));
            return null;
        }
    }
    function _setSummaryStatusText(text) {
        const el = document.getElementById('summary-status-text');
        if (el) el.textContent = text || '';
    }
    function _formatSummaryRangeLabel(startSec, endSec) {
        return `${formatTime(startSec)} - ${formatTime(endSec)}`;
    }
    // 每个总结周期结束时触发一次：取出这段时间新增的字幕原文，清空缓冲区
    // （下一轮只统计"这次之后"新产生的内容，不重复总结），流式喂给 Summarizer；
    // 如果 Summarizer 不支持目标语言（比如中文），总结完成后再整体翻译一次。
    async function _runSummaryCycle() {
        if (!state.summary.enabled || state.summary.running) return;
        // 这一轮开始执行的这一刻，就是下一轮倒计时的起点——不管这一轮最终有没有
        // 产出总结（比如这段时间没有新字幕），倒计时都要正常往下一轮排。
        state.summary.nextSummaryAt = Date.now() + state.summary.intervalMinutes * 60 * 1000;
        const texts = state.summary.pendingTexts;
        const startTime = state.summary.cycleStartTime;
        const endTime = UI.videoPlayer.currentTime || startTime;
        state.summary.pendingTexts   = [];
        state.summary.cycleStartTime = endTime;
        if (!texts.length) {
            // 这段时间没有新字幕（比如中间在静音/暂停），跳过，不产生空总结条目
            return;
        }
        const rawText = texts.join('\n');
        state.summary.running = true;
        // phase: 'summarizing' -> ('translating' 可选) -> 'done' | 'error'
        const entry = { rangeLabel: _formatSummaryRangeLabel(startTime, endTime), text: '', phase: 'summarizing', error: false };
        state.summary.results.push(entry);
        if (state.summary.results.length > 30) {
            state.summary.results.splice(0, state.summary.results.length - 30);
        }
        _notifySummaryUpdate();
        try {
            const summarizer = await _getSummarizerInstance();
            if (!summarizer) {
                entry.phase = 'error';
                entry.error = true;
                _notifySummaryUpdate();
                return;
            }
            const needsTranslation = state.summary.summarizerLang !== state.summary.outputLang;
            // 需要再翻译一轮的情况下，流式生成的原文先攒在本地变量里，不直接塞进
            // entry.text——避免用户先看到一段原文，紧接着又被整体替换成译文，体验很跳。
            // needsTranslation 为 false 时（summarizerLang === outputLang，理论上 Summarizer
            // 应该已经直接产出目标语言）才边生成边乐观展示；下面生成结束后还会再校验一次
            // 实际产出的语言，如果校验发现不对，这段乐观展示的内容会被译文覆盖掉。
            let buffer = '';
            const stream = summarizer.summarizeStreaming(rawText);
            for await (const chunk of stream) {
                buffer += chunk;
                if (!needsTranslation) {
                    entry.text = buffer; // 边生成边展示
                    _notifySummaryUpdate();
                }
            }
            // 不能完全信任 create() 时声明的 outputLanguage 参数一定被浏览器忠实执行——
            // 实测过 Edge 的 Summarizer 会静默忽略这个参数、按输入文本语言产出，Chrome
            // 上也不排除出现类似"声称支持但实际不生效"的静默降级（跟这个项目里已经
            // 踩过好几次的"available()/start() 结果不一致"是同一类问题）。所以这里复用
            // 字幕那边现成的多层语言检测基础设施 getDetectedResult()，对生成完毕的实际
            // 文本做一次校验，而不是只看 summarizerLang === outputLang 这个创建时的
            // "声明"就认定输出语言一定正确。
            let actualNeedsTranslation = needsTranslation;
            let actualSourceLang = state.summary.summarizerLang;
            if (!needsTranslation && buffer.trim()) {
                try {
                    // 阈值比字幕源语言锁定用的 CONFIDENCE_THRESHOLD(0.80) 更低：这里只是要
                    // 抓出"明显对不上"的情况，不是要锁定一个永久生效的语言判断，宁可稍微
                    // 敏感一点也不要漏判。
                    const detected = await getDetectedResult(null, buffer);
                    const detectedLang = detected && detected.detectedLanguage
                        ? detected.detectedLanguage.split('-')[0].toLowerCase()
                        : null;
                    if (detected && detected.confidence >= 0.6 && detectedLang && detectedLang !== state.summary.outputLang) {
                        console.warn(`[VideoSummary] Summarizer 声称已生成 ${state.summary.outputLang}，但实际检测结果是 ${detectedLang}（置信度 ${detected.confidence.toFixed(2)}），改走翻译兜底`);
                        actualNeedsTranslation = true;
                        actualSourceLang = detectedLang;
                    }
                } catch (e) {
                    console.warn('[VideoSummary] 总结产出语言校验失败，按原判断继续:', e);
                }
            }
            if (actualNeedsTranslation) {
                entry.phase = 'translating';
                _notifySummaryUpdate();
                try {
                    // 复用字幕翻译那套 Translator 基础设施：source 用上面校验出的
                    // actualSourceLang（原本认为不需要翻译时就是 summarizerLang，一旦语言
                    // 校验发现产出实际是别的语言，就改用检测到的真实语言，保证 source→target
                    // 传给 Translator 的组合是对的），target 固定是 getSubtitleTargetLang()。
                    const translator = await getTranslatorForSource(actualSourceLang);
                    const translated = translator ? await translator.translate(buffer) : null;
                    entry.text = (translated && translated.trim()) ? translated.trim() : buffer;
                } catch (e) {
                    console.warn('[VideoSummary] 总结译文翻译失败，展示原始生成内容:', e);
                    entry.text = buffer; // 翻译失败就退回原始生成内容，好歹有内容可看
                }
            }
            entry.phase = 'done';
            _notifySummaryUpdate();
        } catch (err) {
            console.error('[VideoSummary] 总结失败:', err);
            entry.phase = 'error';
            entry.error = true;
            _notifySummaryUpdate();
        } finally {
            state.summary.running = false;
        }
    }
    // 打开/关闭视频总结开关。只有实时字幕已开启时才允许打开（由调用方——面板 UI——
    // 保证 checkbox 在字幕关闭时是 disabled 的，这里再兜底判断一次）。
    function _setVideoSummaryEnabled(enabled) {
        enabled = !!enabled && !!state.whisper.enabled;
        if (enabled === state.summary.enabled) return;
        state.summary.enabled = enabled;
        if (state.summary.timerId) {
            clearInterval(state.summary.timerId);
            state.summary.timerId = null;
        }
        if (enabled) {
            state.summary.pendingTexts   = [];
            state.summary.cycleStartTime = UI.videoPlayer.currentTime || 0;
            state.summary.timerId = setInterval(_runSummaryCycle, state.summary.intervalMinutes * 60 * 1000);
            state.summary.nextSummaryAt = Date.now() + state.summary.intervalMinutes * 60 * 1000;
            // 尽早（还在用户点开关这次操作的调用链里）触发一次 Summarizer 创建/模型下载，
            // 不要等到第一次定时器触发时才创建——那时候已经脱离了用户手势上下文，
            // 如果模型还没下载过，create() 可能因为缺少 user activation 被拒绝。
            // 这里不 await，创建结果被缓存到 state.summary.summarizer，
            // 真正到了第一次 _runSummaryCycle() 时直接复用。
            _getSummarizerInstance();
        } else {
            state.summary.pendingTexts  = [];
            state.summary.nextSummaryAt = 0;
        }
        _notifySummaryUpdate();
    }
    function _setSummaryIntervalMinutes(minutes) {
        minutes = parseInt(minutes, 10);
        if (![5, 10].includes(minutes)) return;
        state.summary.intervalMinutes = minutes;
        // 只是改变以后的节奏，不影响当前已经累积的素材；如果总结正在运行中，
        // 用新的间隔重新排定时器即可，倒计时也要跟着从现在重新起算。
        if (state.summary.timerId) {
            clearInterval(state.summary.timerId);
            state.summary.timerId = setInterval(_runSummaryCycle, minutes * 60 * 1000);
            state.summary.nextSummaryAt = Date.now() + minutes * 60 * 1000;
        }
        _notifySummaryUpdate();
    }
    // 彻底重置视频总结状态（换台/重新开启字幕时调用），避免上一段视频的总结历史
    // 残留到新的一段。会顺带销毁已缓存的 Summarizer 实例——不同视频没有复用它的必要，
    // 也避免占用内存跑一整场直播下来越攒越多。
    function _resetVideoSummary() {
        if (state.summary.timerId) {
            clearInterval(state.summary.timerId);
            state.summary.timerId = null;
        }
        if (state.summary.summarizer && typeof state.summary.summarizer.destroy === 'function') {
            try { state.summary.summarizer.destroy(); } catch (e) { /* 忽略 */ }
        }
        state.summary.enabled        = false;
        state.summary.pendingTexts   = [];
        state.summary.cycleStartTime = 0;
        state.summary.nextSummaryAt  = 0;
        state.summary.summarizer     = null;
        state.summary.summarizerLang = null;
        state.summary.outputLang     = null;
        state.summary.running        = false;
        state.summary.results        = [];
        _notifySummaryUpdate();
    }

    // rAF 字幕渲染循环：定稿文本按 showAt/hideAt 显示，同时叠加当前未定稿的 interim 文本
    const _whisperTransCache = new Map();

    async function _translateWhisperSeg(entry) {
        const text = entry.text;
        const cached = _whisperTransCache.get(text);
        if (cached !== undefined) return cached;
        _whisperTransCache.set(text, 'pending');
        try {
            const srcLang = (state.whisper.language || 'zh-CN').split('-')[0];
            if (srcLang === getSubtitleTargetLang()) { _whisperTransCache.set(text, 'same'); return 'same'; }
            const trans = await getTranslatorForSource(srcLang);
            if (!trans) { _whisperTransCache.set(text, 'same'); return 'same'; }
            const contextTexts = _getContextTextsFor(state.whisper.subtitles, entry, WHISPER_TRANSLATION_CONTEXT_LENGTH);
            const translated = contextTexts.length
                ? await _translateWithContext(trans, contextTexts, text)
                : await trans.translate(text);
            const result = (translated && translated.trim() && translated.trim() !== text)
                ? 'OK:' + translated.trim() : 'same';
            _whisperTransCache.set(text, result);
            return result;
        } catch (e) {
            _whisperTransCache.delete(text);
            return 'same';
        }
    }

    function _startWhisperRaf() {
        if (state.whisper.rafId) return;
        // finals 的渲染状态（含译文）与 interim 分开维护：
        // interim 几乎每帧都在变，如果和 finals 用同一个 key 判重，
        // 会导致 interim 一变就整体重绘，把已经渲染好的译文打回原文，
        // 等新一轮翻译 Promise resolve 后才补回来——这就是"译文闪烁"的根因。
        // 现在只有 finals 真正变化时才重新触发翻译；interim 变化只是
        // 复用已缓存的 finals 译文 HTML，拼接新的 interim 再渲染。
        let _lastFinalsKey  = '';
        let _lastFinalsHtml = '';
        let _lastCombined   = '';

        function render(el, interim) {
            const interimHtml = interim ? `<span class="whisper-orig" style="opacity:.55">${interim}</span>` : '';
            const combined = _lastFinalsHtml + interimHtml;
            if (combined !== _lastCombined) {
                _lastCombined = combined;
                el.innerHTML = combined;
            }
        }

        // 按段生成 HTML：优先同步查缓存，缓存里已经有结果就直接带译文渲染，
        // 不存在或还在 'pending' 就先显示原文（不阻塞，不整体等待）
        function segHtml(text) {
            const cached = _whisperTransCache.get(text);
            if (cached && cached !== 'pending' && cached !== 'same') {
                return `<span class="whisper-orig">${text}</span><span class="whisper-trans">${cached.slice(3)}</span>`;
            }
            return `<span class="whisper-orig">${text}</span>`;
        }

        function tick() {
            if (!state.whisper.enabled) {
                state.whisper.rafId = null;
                return;
            }
            const now = UI.videoPlayer.currentTime;
            const finals = (state.whisper.subtitles || []).filter(
                s => s.showAt <= now && s.hideAt >= now
            );
            const interim = state.whisper.interimText || '';
            const el = document.getElementById('whisper-subtitle-display');

            if (el) {
                if (finals.length === 0 && !interim) {
                    if (_lastCombined !== '') {
                        el.style.display = 'none';
                        el.innerHTML = '';
                        _lastFinalsKey = _lastFinalsHtml = _lastCombined = '';
                    }
                } else {
                    el.style.display = 'block';

                    const finalsKey = finals.map(s => s.text).join('\n');
                    if (finalsKey !== _lastFinalsKey) {
                        _lastFinalsKey = finalsKey;

                        if (state.isSubtitleTranslationEnabled && translatorSupported && finals.length) {
                            // 逐段同步查缓存：已经翻译好的段落（比如上一段还在显示期内、
                            // 早就翻译完了）立刻带译文渲染，不会因为新加入了一段
                            // 还没翻译的文本就把整体打回原文重来。
                            _lastFinalsHtml = finals.map(s => segHtml(s.text)).join('');

                            const pending = finals.filter(s => _whisperTransCache.get(s.text) === undefined);
                            if (pending.length) {
                                const capturedKey = finalsKey;
                                Promise.all(pending.map(s => _translateWhisperSeg(s))).then(() => {
                                    // finals 在等待翻译期间已经变了（比如下一句字幕出现），
                                    // 这次翻译结果过期了，丢弃，不要覆盖新内容
                                    if (_lastFinalsKey !== capturedKey) return;
                                    _lastFinalsHtml = finals.map(s => segHtml(s.text)).join('');
                                    render(el, state.whisper.interimText || '');
                                });
                            }
                        } else {
                            _lastFinalsHtml = finals.map(s => `<span class="whisper-orig">${s.text}</span>`).join('');
                        }
                    }
                    render(el, interim);
                }
            }
            state.whisper.rafId = requestAnimationFrame(tick);
        }
        state.whisper.rafId = requestAnimationFrame(tick);
    }

    function _stopWhisperRaf() {
        if (state.whisper.rafId) {
            cancelAnimationFrame(state.whisper.rafId);
            state.whisper.rafId = null;
        }
    }

    function _setWhisperUIStatus(st, msg) {
        const el = document.getElementById('whisper-status-text');
        if (el) el.textContent = msg || '';
    }

    function _resetWhisperToggleUI() {
        const toggleBtn  = document.getElementById('whisper-toggle-btn');
        const whisperBtn = document.getElementById('whisperBtn');
        if (toggleBtn) {
            toggleBtn.textContent = i18n.t('soda_btn_start_caption');
            toggleBtn.classList.remove('active');
        }
        if (whisperBtn) whisperBtn.classList.remove('active');
    }

    // 开启
    function _startSodaAsr() {
        if (state.whisper.enabled) return;
        const asr = _ensureSodaAsr();
        if (!asr) return;
        state.whisper.enabled     = true;
        state.whisper.subtitles   = [];
        state.whisper.interimText = '';
        _resetVideoSummary(); // 新的字幕会话，视频总结的开关/历史/累积素材都要跟着重新开始
        _startWhisperRaf();
        const el = document.getElementById('whisper-subtitle-display');
        if (el) el.style.display = 'none';
        asr.start(state.whisper.language).catch(() => {});
    }

    // 停止
    function _stopSodaAsr() {
        if (!state.whisper.enabled) return;
        state.whisper.enabled = false;
        _resetVideoSummary(); // 字幕都关了，总结自然也不能继续开着
        _whisperTransCache.clear();
        _stopWhisperRaf();
        if (_sodaAsr) _sodaAsr.stop();

        const el = document.getElementById('whisper-subtitle-display');
        if (el) { el.style.display = 'none'; el.textContent = ''; }
        _setWhisperUIStatus('idle', '');
        _resetWhisperToggleUI();
    }

    // 对外接口（供 UI 按钮调用）
    function toggleWhisper() {
        if (state.whisper.enabled) _stopSodaAsr();
        else _startSodaAsr();
    }

    // 把控制函数暴露到 window，供 js/soda-panel.js 调用
    window._startSodaAsr = _startSodaAsr;
    window._stopSodaAsr  = _stopSodaAsr;
    window.toggleWhisper  = toggleWhisper;
    // 视频总结相关控制函数
    window._setVideoSummaryEnabled   = _setVideoSummaryEnabled;
    window._setSummaryIntervalMinutes = _setSummaryIntervalMinutes;
    // state 也暴露出去，供 soda-panel.js 读取 state.whisper.enabled / state.summary.*
    window.state = state;

    init();
});