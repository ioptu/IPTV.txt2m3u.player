'use strict';
/**
 * js/defaults.js
 *
 * 扩展里"会随版本更新而变化"的默认值的唯一来源，settings / player 共用。
 *
 * 为什么需要它：
 *   以前 settings.js 点"保存"时会把界面上所有字段（包括用户根本没改过、
 *   只是默认值的 epgUrl）原样写进 chrome.storage.local，于是旧默认值被当成
 *   "用户自己的设置"永久固化；之后扩展更新了新的默认地址，也会被缓存里的旧值盖住。
 *
 * 现在的规则：
 *   1. 保存时，如果值等于默认值（或历史默认值），就不写入 storage（并删除已有的 key），
 *      读取时没有 key 就用这里的最新默认值——这样以后改默认值，没自定义过的用户自动生效。
 *   2. 已经被旧版本固化进缓存的"历史默认值"，读取时同样视为默认值（见 LEGACY_EPG_URLS）。
 *
 * 以后更换默认 EPG 地址时：把新地址写进 DEFAULT_EPG_URL，
 * 并把旧的默认地址追加到 LEGACY_EPG_URLS，其他地方都不用改。
 */
(function (root) {
    const DEFAULT_EPG_URL = 'https://gh-proxy.org/raw.githubusercontent.com/kuke31/xmlgz/main/e.xml.gz';
    // 历史上出现过的默认地址（旧版本可能已把它们写进了用户的 storage）
    const LEGACY_EPG_URLS = [
        'https://e.erw.cc/e.xml.gz'
    ];

    function normalize(u) {
        return String(u == null ? '' : u).trim();
    }
    // 空值、当前默认值、历史默认值，都算"没有自定义"
    function isDefaultEpgUrl(u) {
        const v = normalize(u);
        return v === '' || v === DEFAULT_EPG_URL || LEGACY_EPG_URLS.indexOf(v) !== -1;
    }
    // 把 storage 里读到的值（可能是 undefined / 旧默认值 / 用户自定义）解析成实际要用的地址
    function resolveEpgUrl(stored) {
        return isDefaultEpgUrl(stored) ? DEFAULT_EPG_URL : normalize(stored);
    }

    root.FmDefaults = {
        EPG_URL: DEFAULT_EPG_URL,
        isDefaultEpgUrl: isDefaultEpgUrl,
        resolveEpgUrl: resolveEpgUrl
    };
})(window);