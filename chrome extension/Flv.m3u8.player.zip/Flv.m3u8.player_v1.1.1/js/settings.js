// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", function() {
    // DOM 元素
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const backBtn = document.querySelector('.back-btn');
    const saveBtn = document.getElementById('saveBtn');
    const resetBtn = document.getElementById('resetBtn');
    const blacklistInput = document.getElementById('blacklistInput');
    const addKeywordBtn = document.getElementById('addKeywordBtn');
    const blacklistItems = document.getElementById('blacklistItems');
    const testEpgBtn = document.getElementById('testEpgBtn');
    // 默认配置（用户友好的单位）
    const DEFAULT_CONFIG = {
        loadTimeout: 10, // 秒
        stallTimeout: 10, // 秒
        maxRetryRounds: 2, // 轮
        searchDebounce: 300, // 毫秒
        playlistRefreshInterval: 30, // 分钟
        autoRefreshEnabled: true, //频道列表自动刷新启用状态
        epgEnabled: false, // EPG启用状态
        epgUrl: 'http://e.erw.cc/e.xml.gz', // EPG数据源
        marqueeSpeed: 100, // 像素/秒
        marqueeColor: '#ffd700', // 跑马灯颜色
        marqueeFontSize: '18', // 跑马灯字体大小(px)
        blacklist: [], // 黑名单关键词数组
        headerRules: [] // 自定义 header 规则
    };
    // 当前配置（用户友好的单位）
    let currentConfig = { ...DEFAULT_CONFIG };
    // 初始化标签页切换
    function initTabs() {
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.getAttribute('data-tab');
                // 更新标签状态
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                // 更新内容显示
                tabContents.forEach(content => {
                    content.classList.remove('active');
                });
                const targetTab = document.getElementById(`${tabId}-tab`);
                if (targetTab) {
                    targetTab.classList.add('active');
                }
            });
        });
    }
    // 初始化颜色选择器
    function initColorPicker() {
        const colorPicker = document.getElementById('marqueeColor');
        const colorText = document.getElementById('marqueeColorText');
        if (colorPicker && colorText) {
            // 同步颜色值和文本
            colorPicker.addEventListener('input', (e) => {
                colorText.value = e.target.value;
            });
            colorText.addEventListener('input', (e) => {
                const value = e.target.value;
                if (/^#[0-9A-F]{6}$/i.test(value)) {
                    colorPicker.value = value;
                }
            });
            colorText.addEventListener('blur', (e) => {
                let value = e.target.value.trim();
                if (!value.startsWith('#')) {
                    value = '#' + value;
                }
                if (/^#[0-9A-F]{6}$/i.test(value)) {
                    colorPicker.value = value;
                    colorText.value = value;
                } else {
                    // 重置为默认值
                    colorText.value = colorPicker.value;
                }
            });
        }
    }
    // 加载设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'epgEnabled',
            'epgUrl',
            'marqueeSpeed',
            'marqueeColor',
            'marqueeFontSize',
            'blacklist',
            'headerRules'
        ], function(result) {
            console.log('从存储加载的设置:', result);
            // 获取输入元素
            const loadTimeoutInput = document.getElementById('loadTimeout');
            const stallTimeoutInput = document.getElementById('stallTimeout');
            const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
            const searchDebounceInput = document.getElementById('searchDebounce');
            const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
            const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
            const epgEnabledInput = document.getElementById('epgEnabled');
            const epgUrlInput = document.getElementById('epgUrl');
            const marqueeSpeedInput = document.getElementById('marqueeSpeed');
            const marqueeColorInput = document.getElementById('marqueeColor');
            const marqueeColorText = document.getElementById('marqueeColorText');
            const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
            // 设置输入框值 - 如果有存储值就转换，否则使用默认值
            if (loadTimeoutInput) {
                loadTimeoutInput.value = result.loadTimeout !== undefined
                    ? Math.round(result.loadTimeout / 1000)
                    : DEFAULT_CONFIG.loadTimeout;
            }
            if (stallTimeoutInput) {
                stallTimeoutInput.value = result.stallTimeout !== undefined
                    ? Math.round(result.stallTimeout / 1000)
                    : DEFAULT_CONFIG.stallTimeout;
            }
            if (maxRetryRoundsInput) {
                maxRetryRoundsInput.value = result.maxRetryRounds !== undefined
                    ? result.maxRetryRounds
                    : DEFAULT_CONFIG.maxRetryRounds;
            }
            if (searchDebounceInput) {
                searchDebounceInput.value = result.searchDebounce !== undefined
                    ? result.searchDebounce
                    : DEFAULT_CONFIG.searchDebounce;
            }
            if (playlistRefreshIntervalInput) {
                playlistRefreshIntervalInput.value = result.playlistRefreshInterval !== undefined
                    ? Math.round(result.playlistRefreshInterval / 60000)
                    : DEFAULT_CONFIG.playlistRefreshInterval;
            }
            if (autoRefreshEnabledInput) {
                autoRefreshEnabledInput.checked = result.autoRefreshEnabled !== undefined
                    ? result.autoRefreshEnabled
                    : DEFAULT_CONFIG.autoRefreshEnabled;
            }
            // EPG相关设置
            if (epgEnabledInput) {
                epgEnabledInput.checked = result.epgEnabled !== undefined
                    ? result.epgEnabled
                    : DEFAULT_CONFIG.epgEnabled;
            }
            if (epgUrlInput) {
                epgUrlInput.value = result.epgUrl !== undefined
                    ? result.epgUrl
                    : DEFAULT_CONFIG.epgUrl;
            }
            if (marqueeSpeedInput) {
                marqueeSpeedInput.value = result.marqueeSpeed !== undefined
                    ? result.marqueeSpeed
                    : DEFAULT_CONFIG.marqueeSpeed;
            }
            if (marqueeColorInput && marqueeColorText) {
                const colorValue = result.marqueeColor !== undefined
                    ? result.marqueeColor
                    : DEFAULT_CONFIG.marqueeColor;
                marqueeColorInput.value = colorValue;
                marqueeColorText.value = colorValue;
            }
            if (marqueeFontSizeInput) {
                marqueeFontSizeInput.value = result.marqueeFontSize !== undefined
                    ? result.marqueeFontSize
                    : DEFAULT_CONFIG.marqueeFontSize;
            }
            // 更新当前配置（使用用户友好的单位）
            currentConfig.loadTimeout = loadTimeoutInput ? parseInt(loadTimeoutInput.value) : DEFAULT_CONFIG.loadTimeout;
            currentConfig.stallTimeout = stallTimeoutInput ? parseInt(stallTimeoutInput.value) : DEFAULT_CONFIG.stallTimeout;
            currentConfig.maxRetryRounds = maxRetryRoundsInput ? parseInt(maxRetryRoundsInput.value) : DEFAULT_CONFIG.maxRetryRounds;
            currentConfig.searchDebounce = searchDebounceInput ? parseInt(searchDebounceInput.value) : DEFAULT_CONFIG.searchDebounce;
            currentConfig.playlistRefreshInterval = playlistRefreshIntervalInput ? parseInt(playlistRefreshIntervalInput.value) : DEFAULT_CONFIG.playlistRefreshInterval;
            currentConfig.autoRefreshEnabled = autoRefreshEnabledInput ? autoRefreshEnabledInput.checked : DEFAULT_CONFIG.autoRefreshEnabled;
            currentConfig.epgEnabled = epgEnabledInput ? epgEnabledInput.checked : DEFAULT_CONFIG.epgEnabled;
            currentConfig.epgUrl = epgUrlInput ? epgUrlInput.value : DEFAULT_CONFIG.epgUrl;
            currentConfig.marqueeSpeed = marqueeSpeedInput ? parseFloat(marqueeSpeedInput.value) : DEFAULT_CONFIG.marqueeSpeed;
            currentConfig.marqueeColor = marqueeColorInput ? marqueeColorInput.value : DEFAULT_CONFIG.marqueeColor;
            currentConfig.marqueeFontSize = marqueeFontSizeInput ? marqueeFontSizeInput.value : DEFAULT_CONFIG.marqueeFontSize;
            console.log('当前配置:', currentConfig);
            // 加载黑名单
            if (result.blacklist && Array.isArray(result.blacklist)) {
                currentConfig.blacklist = result.blacklist;
                console.log('从存储加载黑名单:', currentConfig.blacklist.length, '个关键词');
            } else {
                // 如果 storage 中没有黑名单，尝试从文件加载
                console.log('存储中没有黑名单，尝试从文件加载');
                loadBlacklistFromFile();
            }
            renderBlacklist();
            // 加载 headerRules
            if (result.headerRules && Array.isArray(result.headerRules)) {
                currentConfig.headerRules = result.headerRules;
            } else {
                currentConfig.headerRules = [];
            }
            renderHeaderRules();
            // 根据EPG启用状态更新UI
            updateEpgUIState();
        });
    }
    // 更新EPG相关UI状态
    function updateEpgUIState() {
        const epgEnabledInput = document.getElementById('epgEnabled');
        if (!epgEnabledInput) return;
        const isEpgEnabled = epgEnabledInput.checked;
        const epgUrlInput = document.getElementById('epgUrl');
        const marqueeSpeedInput = document.getElementById('marqueeSpeed');
        const marqueeColorContainer = document.querySelector('.color-picker-container');
        const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
        const testEpgBtn = document.getElementById('testEpgBtn');
        // 启用或禁用EPG相关输入框
        [epgUrlInput, marqueeSpeedInput, marqueeFontSizeInput].forEach(input => {
            if (input) {
                input.disabled = !isEpgEnabled;
                input.style.opacity = isEpgEnabled ? '1' : '0.6';
            }
        });
        if (marqueeColorContainer) {
            const inputs = marqueeColorContainer.querySelectorAll('input');
            inputs.forEach(input => {
                input.disabled = !isEpgEnabled;
            });
            marqueeColorContainer.style.opacity = isEpgEnabled ? '1' : '0.6';
        }
        if (testEpgBtn) {
            testEpgBtn.disabled = !isEpgEnabled;
            testEpgBtn.style.opacity = isEpgEnabled ? '1' : '0.6';
        }
    }
    // 从文件加载黑名单
    function loadBlacklistFromFile() {
        fetch(chrome.runtime.getURL('blacklist.txt'))
            .then(response => response.text())
            .then(text => {
                const keywords = text.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                currentConfig.blacklist = keywords;
                console.log('从文件加载黑名单:', keywords.length, '个关键词');
                renderBlacklist();
            })
            .catch(error => {
                console.warn('无法加载黑名单文件:', error);
                currentConfig.blacklist = [];
                renderBlacklist();
            });
    }
    // 渲染黑名单列表
    function renderBlacklist() {
        if (!blacklistItems) return;
        blacklistItems.innerHTML = '';
        if (currentConfig.blacklist.length === 0) {
            blacklistItems.innerHTML = `
                <div class="empty-state">
                    <div>📝</div>
                    <p>暂无黑名单规则</p>
                    <p class="tip">添加关键词以过滤不需要的内容</p>
                </div>
            `;
            return;
        }
        currentConfig.blacklist.forEach((keyword, index) => {
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            item.innerHTML = `
                <div class="blacklist-keyword">${escapeHtml(keyword)}</div>
                <div class="blacklist-actions">
                    <button class="edit-btn" data-index="${index}">✏️</button>
                    <button class="delete-btn" data-index="${index}">🗑️</button>
                </div>
            `;
            blacklistItems.appendChild(item);
        });
        // 添加事件监听器
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                editKeyword(index);
            });
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                deleteKeyword(index);
            });
        });
    }
    // 渲染 header rules
    function renderHeaderRules() {
        const container = document.getElementById('headerRulesItems');
        if (!container) return;
        container.innerHTML = '';
        if (currentConfig.headerRules.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div>🔐</div>
                    <p>暂无自定义 Header 规则</p>
                    <p class="tip">添加规则以针对不同域名/路径设置专属 headers</p>
                </div>
            `;
            return;
        }
        currentConfig.headerRules.forEach((rule, index) => {
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            const headersStr = Object.entries(rule.headers || {})
                .map(([k, v]) => `${k}: ${v}`)
                .join('; ');
            item.innerHTML = `
                <div class="blacklist-keyword">
                    <strong>pattern:</strong> ${escapeHtml(rule.pattern)}<br>
                    <strong>headers:</strong> ${escapeHtml(headersStr)}
                </div>
                <div class="blacklist-actions">
                    <button class="edit-btn" data-index="${index}">✏️</button>
                    <button class="delete-btn" data-index="${index}">🗑️</button>
                </div>
            `;
            container.appendChild(item);
        });
        container.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', e => {
                const index = parseInt(e.target.dataset.index);
                editHeaderRule(index);
            });
        });
        container.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', e => {
                const index = parseInt(e.target.dataset.index);
                if (confirm('确定删除这条 Header 规则吗？')) {
                    currentConfig.headerRules.splice(index, 1);
                    renderHeaderRules();
                    showMessage('规则已删除');
                }
            });
        });
    }
    // 添加关键词
    function addKeyword() {
        if (!blacklistInput) return;
        const keyword = blacklistInput.value.trim();
        if (!keyword) {
            alert('请输入关键词');
            return;
        }
        if (currentConfig.blacklist.includes(keyword)) {
            alert('该关键词已存在');
            return;
        }
        currentConfig.blacklist.push(keyword);
        blacklistInput.value = '';
        renderBlacklist();
        showMessage('关键词已添加');
    }
    // 编辑关键词
    function editKeyword(index) {
        const oldKeyword = currentConfig.blacklist[index];
        const newKeyword = prompt('编辑关键词:', oldKeyword);
        if (newKeyword !== null) {
            const trimmedKeyword = newKeyword.trim();
            if (trimmedKeyword && !currentConfig.blacklist.includes(trimmedKeyword)) {
                currentConfig.blacklist[index] = trimmedKeyword;
                renderBlacklist();
                showMessage('关键词已更新');
            } else if (!trimmedKeyword) {
                alert('关键词不能为空');
            } else {
                alert('该关键词已存在');
            }
        }
    }
    // 删除关键词
    function deleteKeyword(index) {
        if (confirm('确定要删除这个关键词吗？')) {
            currentConfig.blacklist.splice(index, 1);
            renderBlacklist();
            showMessage('关键词已删除');
        }
    }
    // 解析 headers 的健壮函数，支持引号和转义
    function parseHeaders(str) {
        const headers = {};
        let i = 0;
        const len = str.length;
        while (i < len) {
            // 跳过空白
            while (i < len && /\s/.test(str[i])) i++;
            if (i >= len) break;
            // 读取 key
            let keyStart = i;
            while (i < len && str[i] !== ':') i++;
            let key = str.substring(keyStart, i).trim();
            if (i < len) i++; // 跳过 :
            // 跳过空白
            while (i < len && /\s/.test(str[i])) i++;
            let value = '';
            if (i < len && (str[i] === '"' || str[i] === "'")) {
                const quote = str[i];
                i++; // 跳过开引号
                let start = i;
                let escapedValue = '';
                while (i < len) {
                    if (str[i] === '\\') {
                        i++; // 跳过 \
                        if (i < len) {
                            escapedValue += str[i];
                            i++;
                        }
                        continue;
                    }
                    if (str[i] === quote) {
                        value = escapedValue;
                        i++; // 跳过闭引号
                        break;
                    }
                    escapedValue += str[i];
                    i++;
                }
            } else {
                // 无引号，读到 ;
                let start = i;
                while (i < len && str[i] !== ';') i++;
                value = str.substring(start, i).trim();
            }
            if (key) {
                headers[key] = value;
            }
            // 跳过 ; 和空白
            while (i < len && (str[i] === ';' || /\s/.test(str[i]))) i++;
        }
        return headers;
    }
    // 添加 header rule
    function addHeaderRule() {
        const patternInput = document.getElementById('rulePatternInput');
        const headersInput = document.getElementById('ruleHeadersInput');
        if (!patternInput || !headersInput) return;
        const pattern = patternInput.value.trim();
        const headersStr = headersInput.value.trim();
        if (!pattern) {
            alert('请输入 pattern');
            return;
        }
        if (!headersStr) {
            alert('请输入 headers（格式：Key1: value1; Key2: value2）');
            return;
        }
        const headers = parseHeaders(headersStr);
        if (Object.keys(headers).length === 0) {
            alert('没有解析到有效的 header 键值对');
            return;
        }
        currentConfig.headerRules.push({ pattern, headers });
        patternInput.value = '';
        headersInput.value = '';
        renderHeaderRules();
        showMessage('Header 规则已添加');
    }
    // 编辑 header rule
    function editHeaderRule(index) {
        const rule = currentConfig.headerRules[index];
        if (!rule) return;
        const headersStr = Object.entries(rule.headers)
            .map(([k, v]) => `${k}: ${v}`)
            .join('; ');
        const newInput = prompt('编辑规则（格式：pattern | headers）', `${rule.pattern} | ${headersStr}`);
        if (newInput === null) return;
        const [newPatternPart, newHeadersPart] = newInput.split('|').map(s => s.trim());
        if (!newPatternPart || !newHeadersPart) {
            alert('格式错误，应为：pattern | key1: val1; key2: val2');
            return;
        }
        const newHeaders = parseHeaders(newHeadersPart);
        if (Object.keys(newHeaders).length === 0) {
            alert('没有有效的 header');
            return;
        }
        currentConfig.headerRules[index] = {
            pattern: newPatternPart,
            headers: newHeaders
        };
        renderHeaderRules();
        showMessage('规则已更新');
    }
    // 测试EPG数据源
    function testEpgDataSource() {
        const epgUrlInput = document.getElementById('epgUrl');
        const epgTestResult = document.getElementById('epgTestResult');
        const epgPreview = document.getElementById('epgPreview');
        if (!epgUrlInput || !epgUrlInput.value.trim()) {
            showMessage('请输入EPG数据源URL', false);
            return;
        }
        const url = epgUrlInput.value.trim();
        epgTestResult.textContent = '正在测试EPG数据源...';
        epgTestResult.style.color = '#2196F3';
        // 显示加载状态
        epgPreview.innerHTML = `
            <div class="empty-state">
                <div>⏳</div>
                <p>正在加载EPG数据...</p>
                <p class="tip">请稍候</p>
            </div>
        `;
        // 发送消息到background页面进行测试
        chrome.runtime.sendMessage({
            action: 'testEpgUrl',
            url: url
        }, function(response) {
            if (chrome.runtime.lastError) {
                epgTestResult.textContent = '测试失败：' + chrome.runtime.lastError.message;
                epgTestResult.style.color = '#f44336';
                showMessage('EPG测试失败', false);
                epgPreview.innerHTML = `
                    <div class="empty-state">
                        <div>❌</div>
                        <p>EPG数据加载失败</p>
                        <p class="tip">${chrome.runtime.lastError.message}</p>
                    </div>
                `;
                return;
            }
            if (response && response.success) {
                epgTestResult.textContent = 'EPG数据源测试成功！';
                epgTestResult.style.color = '#4CAF50';
                showMessage('EPG数据源测试成功');
                // 显示预览数据
                if (response.data && response.data.length > 0) {
                    let previewHTML = '<div style="margin-bottom: 10px; color: #666; font-size: 12px;">';
                    previewHTML += `已加载 ${response.data.length} 个节目</div>`;
                    // 显示前5个节目作为预览
                    response.data.slice(0, 5).forEach(item => {
                        const startTime = item.start ? new Date(item.start).toLocaleTimeString('zh-CN', {
                            hour: '2-digit',
                            minute: '2-digit'
                        }) : '--:--';
                        const endTime = item.stop ? new Date(item.stop).toLocaleTimeString('zh-CN', {
                            hour: '2-digit',
                            minute: '2-digit'
                        }) : '--:--';
                        previewHTML += `
                            <div class="epg-preview-item">
                                <div class="epg-preview-time">${startTime} - ${endTime}</div>
                                <div class="epg-preview-title">${escapeHtml(item.title || '未知节目')}</div>
                            </div>
                        `;
                    });
                    if (response.data.length > 5) {
                        previewHTML += `<div style="text-align: center; color: #666; font-size: 12px; margin-top: 10px;">
                            还有 ${response.data.length - 5} 个节目未显示...
                        </div>`;
                    }
                    epgPreview.innerHTML = previewHTML;
                } else {
                    epgPreview.innerHTML = `
                        <div class="empty-state">
                            <div>📺</div>
                            <p>EPG数据加载成功</p>
                            <p class="tip">但未找到节目信息</p>
                        </div>
                    `;
                }
            } else {
                const errorMsg = response && response.error ? response.error : '未知错误';
                epgTestResult.textContent = 'EPG数据源测试失败：' + errorMsg;
                epgTestResult.style.color = '#f44336';
                showMessage('EPG测试失败: ' + errorMsg, false);
                epgPreview.innerHTML = `
                    <div class="empty-state">
                        <div>❌</div>
                        <p>EPG数据加载失败</p>
                        <p class="tip">${errorMsg}</p>
                    </div>
                `;
            }
        });
    }
    // 保存设置
    function saveSettings() {
        // 获取表单元素
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        const epgEnabledInput = document.getElementById('epgEnabled');
        const epgUrlInput = document.getElementById('epgUrl');
        const marqueeSpeedInput = document.getElementById('marqueeSpeed');
        const marqueeColorInput = document.getElementById('marqueeColor');
        const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
        if (!loadTimeoutInput || !stallTimeoutInput || !maxRetryRoundsInput ||
            !searchDebounceInput || !playlistRefreshIntervalInput || !autoRefreshEnabledInput ||
            !epgEnabledInput || !epgUrlInput || !marqueeSpeedInput || !marqueeColorInput || !marqueeFontSizeInput) {
            showMessage('表单元素缺失，请刷新页面重试', false);
            return;
        }
        // 获取输入值并验证
        const loadTimeout = parseInt(loadTimeoutInput.value);
        const stallTimeout = parseInt(stallTimeoutInput.value);
        const maxRetryRounds = parseInt(maxRetryRoundsInput.value);
        const searchDebounce = parseInt(searchDebounceInput.value);
        const playlistRefreshInterval = parseInt(playlistRefreshIntervalInput.value);
        const autoRefreshEnabled = autoRefreshEnabledInput.checked;
        const epgEnabled = epgEnabledInput.checked;
        const epgUrl = epgUrlInput.value.trim();
        const marqueeSpeed = parseFloat(marqueeSpeedInput.value);
        const marqueeColor = marqueeColorInput.value.trim();
        const marqueeFontSize = marqueeFontSizeInput.value.trim();
        // 验证输入
        if (isNaN(loadTimeout) || loadTimeout < 1) {
            alert('加载超时时间必须大于等于1秒');
            loadTimeoutInput.focus();
            return;
        }
        if (isNaN(stallTimeout) || stallTimeout < 1) {
            alert('卡顿检测时间必须大于等于1秒');
            stallTimeoutInput.focus();
            return;
        }
        if (isNaN(maxRetryRounds) || maxRetryRounds < 1) {
            alert('最大重试轮次必须大于等于1');
            maxRetryRoundsInput.focus();
            return;
        }
        if (isNaN(searchDebounce) || searchDebounce < 100) {
            alert('搜索防抖延迟必须大于等于100毫秒');
            searchDebounceInput.focus();
            return;
        }
        if (isNaN(playlistRefreshInterval) || playlistRefreshInterval < 5) {
            alert('频道列表刷新间隔必须大于等于5分钟');
            playlistRefreshIntervalInput.focus();
            return;
        }
        // EPG相关验证
        if (epgEnabled && !epgUrl) {
            alert('启用EPG功能必须设置EPG数据源URL');
            epgUrlInput.focus();
            return;
        }
        if (marqueeSpeed < 50 || marqueeSpeed > 500) {
            alert('跑马灯速度必须在50-500像素/秒之间');
            marqueeSpeedInput.focus();
            return;
        }
        if (!/^#[0-9A-F]{6}$/i.test(marqueeColor)) {
            alert('请选择有效的颜色值（如：#ffd700）');
            marqueeColorInput.focus();
            return;
        }
        if (!/^\d+$/i.test(marqueeFontSize)) {
            alert('请输入有效的数字（字体大小,如：18）');
            marqueeFontSizeInput.focus();
            return;
        }
        // 准备保存的配置（转换为存储单位：毫秒）
        const configToSave = {
            loadTimeout: loadTimeout * 1000,
            stallTimeout: stallTimeout * 1000,
            maxRetryRounds: maxRetryRounds,
            searchDebounce: searchDebounce,
            playlistRefreshInterval: playlistRefreshInterval * 60000,
            autoRefreshEnabled: autoRefreshEnabled,
            epgEnabled: epgEnabled,
            epgUrl: epgUrl,
            marqueeSpeed: marqueeSpeed,
            marqueeColor: marqueeColor,
            marqueeFontSize: marqueeFontSize,
            blacklist: [...currentConfig.blacklist], // 深拷贝数组
            headerRules: currentConfig.headerRules.map(r => ({ ...r, headers: { ...r.headers } })) // 深拷贝
        };
        console.log('保存的配置:', configToSave);
        // 保存到 storage
        chrome.storage.local.set(configToSave, function() {
            if (chrome.runtime.lastError) {
                console.error('保存设置失败:', chrome.runtime.lastError);
                showMessage('保存失败: ' + chrome.runtime.lastError.message, false);
            } else {
                showMessage('设置已保存！', true);
                console.log('设置保存成功');
                // 更新当前配置（用户友好单位）
                currentConfig.loadTimeout = loadTimeout;
                currentConfig.stallTimeout = stallTimeout;
                currentConfig.maxRetryRounds = maxRetryRounds;
                currentConfig.searchDebounce = searchDebounce;
                currentConfig.playlistRefreshInterval = playlistRefreshInterval;
                currentConfig.autoRefreshEnabled = autoRefreshEnabled;
                currentConfig.epgEnabled = epgEnabled;
                currentConfig.epgUrl = epgUrl;
                currentConfig.marqueeSpeed = marqueeSpeed;
                currentConfig.marqueeColor = marqueeColor;
                currentConfig.marqueeFontSize = marqueeFontSize;
                // 通知所有打开的播放器页面
                try {
                    chrome.runtime.sendMessage({
                        action: 'settingsUpdated',
                        config: configToSave
                    });
                    console.log('已发送设置更新消息');
                } catch (error) {
                    console.warn('发送设置更新消息失败:', error);
                }
                // 通知 background 更新 DNR 规则
                chrome.runtime.sendMessage({
                    action: 'updateHeaderRules'
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.error('更新 DNR 规则失败:', chrome.runtime.lastError);
                    } else {
                        console.log('DNR 规则更新成功');
                    }
                });
            }
        });
    }
    // 恢复默认设置
    function resetSettings() {
        if (!confirm('确定要恢复默认设置吗？这将清除所有自定义设置。')) {
            return;
        }
        // 获取表单元素
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        const epgEnabledInput = document.getElementById('epgEnabled');
        const epgUrlInput = document.getElementById('epgUrl');
        const marqueeSpeedInput = document.getElementById('marqueeSpeed');
        const marqueeColorInput = document.getElementById('marqueeColor');
        const marqueeColorText = document.getElementById('marqueeColorText');
        const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
        // 重置表单值为默认值
        if (loadTimeoutInput) loadTimeoutInput.value = DEFAULT_CONFIG.loadTimeout;
        if (stallTimeoutInput) stallTimeoutInput.value = DEFAULT_CONFIG.stallTimeout;
        if (maxRetryRoundsInput) maxRetryRoundsInput.value = DEFAULT_CONFIG.maxRetryRounds;
        if (searchDebounceInput) searchDebounceInput.value = DEFAULT_CONFIG.searchDebounce;
        if (playlistRefreshIntervalInput) playlistRefreshIntervalInput.value = DEFAULT_CONFIG.playlistRefreshInterval;
        if (autoRefreshEnabledInput) autoRefreshEnabledInput.checked = DEFAULT_CONFIG.autoRefreshEnabled;
        if (epgEnabledInput) epgEnabledInput.checked = DEFAULT_CONFIG.epgEnabled;
        if (epgUrlInput) epgUrlInput.value = DEFAULT_CONFIG.epgUrl;
        if (marqueeSpeedInput) marqueeSpeedInput.value = DEFAULT_CONFIG.marqueeSpeed;
        if (marqueeColorInput) marqueeColorInput.value = DEFAULT_CONFIG.marqueeColor;
        if (marqueeColorText) marqueeColorText.value = DEFAULT_CONFIG.marqueeColor;
        if (marqueeFontSizeInput) marqueeFontSizeInput.value = DEFAULT_CONFIG.marqueeFontSize;
        // 重置黑名单
        currentConfig.blacklist = [...DEFAULT_CONFIG.blacklist];
        renderBlacklist();
        // 重置 headerRules
        currentConfig.headerRules = [];
        renderHeaderRules();
        updateEpgUIState();
        // 清除 storage 中的设置
        chrome.storage.local.clear(function() {
            if (chrome.runtime.lastError) {
                console.error('清除设置失败:', chrome.runtime.lastError);
                showMessage('恢复默认设置失败', false);
            } else {
                showMessage('已恢复默认设置');
                console.log('设置已恢复为默认值');
            }
        });
    }
    // 显示消息
    function showMessage(message, isSuccess = true) {
        // 移除现有消息
        const existingMessage = document.querySelector('.message-toast');
        if (existingMessage) {
            existingMessage.remove();
        }
        // 创建新消息
        const messageDiv = document.createElement('div');
        messageDiv.className = `message-toast ${isSuccess ? 'success' : 'info'}`;
        messageDiv.textContent = message;
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 24px;
            background: ${isSuccess ? '#4CAF50' : '#2196F3'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        document.body.appendChild(messageDiv);
        // 3秒后自动移除
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 3000);
        // 添加动画样式
        if (!document.querySelector('#message-styles')) {
            const style = document.createElement('style');
            style.id = 'message-styles';
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                @keyframes slideOut {
                    from { transform: translateX(0); opacity: 1; }
                    to { transform: translateX(100%); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }
    }
    // HTML 转义
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    // 添加输入验证
    function addInputValidation() {
        const numberInputs = document.querySelectorAll('input[type="number"]');
        numberInputs.forEach(input => {
            input.addEventListener('change', function() {
                const min = parseFloat(this.min) || 1;
                const max = parseFloat(this.max) || 9999;
                let value = parseFloat(this.value);
                if (isNaN(value)) {
                    this.value = min;
                } else if (value < min) {
                    this.value = min;
                } else if (value > max) {
                    this.value = max;
                }
            });
        });
    }
    // 导出设置
    function exportSettings() {
        const data = JSON.stringify(currentConfig);
        const blob = new Blob([data], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.download = 'fmplayer_settings.json';
        a.href = url;
        a.click();
        URL.revokeObjectURL(url);
        showMessage('设置已导出');
    }
    // 导入设置
    function importSettings() {
        const importInput = document.getElementById('importSettingsInput');
        const file = importInput.files[0];
        if (!file) {
            showMessage('请先选择文件', false);
            return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedConfig = JSON.parse(e.target.result);
                currentConfig = {...DEFAULT_CONFIG, ...importedConfig};
                // 手动更新 UI
                document.getElementById('loadTimeout').value = currentConfig.loadTimeout;
                document.getElementById('stallTimeout').value = currentConfig.stallTimeout;
                document.getElementById('maxRetryRounds').value = currentConfig.maxRetryRounds;
                document.getElementById('searchDebounce').value = currentConfig.searchDebounce;
                document.getElementById('playlistRefreshInterval').value = currentConfig.playlistRefreshInterval;
                document.getElementById('autoRefreshEnabled').checked = currentConfig.autoRefreshEnabled;
                document.getElementById('epgEnabled').checked = currentConfig.epgEnabled;
                document.getElementById('epgUrl').value = currentConfig.epgUrl;
                document.getElementById('marqueeSpeed').value = currentConfig.marqueeSpeed;
                document.getElementById('marqueeColor').value = currentConfig.marqueeColor;
                document.getElementById('marqueeColorText').value = currentConfig.marqueeColor;
                document.getElementById('marqueeFontSize').value = currentConfig.marqueeFontSize;
                renderBlacklist();
                renderHeaderRules();
                updateEpgUIState();
                showMessage('设置已导入，请点击"保存设置"以保存并使生效');
            } catch (err) {
                showMessage('导入失败: 无效的JSON文件', false);
            }
        };
        reader.readAsText(file);
    }
    // 初始化
    function init() {
        console.log('初始化设置页面...');
        // 确保必要元素存在
        if (tabs.length === 0) {
            console.error('未找到标签页元素');
            return;
        }
        if (tabContents.length === 0) {
            console.error('未找到标签内容元素');
            return;
        }
        // 初始化各个功能
        initTabs();
        initColorPicker();
        addInputValidation();
        loadSettings();
        // 安全地添加事件监听器
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                window.close();
            });
        }
        if (saveBtn) {
            saveBtn.addEventListener('click', saveSettings);
        }
        if (resetBtn) {
            resetBtn.addEventListener('click', resetSettings);
        }
        if (addKeywordBtn) {
            addKeywordBtn.addEventListener('click', addKeyword);
        }
        if (testEpgBtn) {
            testEpgBtn.addEventListener('click', testEpgDataSource);
        }
        if (blacklistInput) {
            blacklistInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    addKeyword();
                }
            });
        }
        const addRuleBtn = document.getElementById('addRuleBtn');
        if (addRuleBtn) {
            addRuleBtn.addEventListener('click', addHeaderRule);
        }
        // EPG启用状态变化时更新UI
        const epgEnabledInput = document.getElementById('epgEnabled');
        if (epgEnabledInput) {
            epgEnabledInput.addEventListener('change', updateEpgUIState);
        }
        // 导入导出事件
        const exportBtn = document.getElementById('exportSettingsBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', exportSettings);
        }
        const importBtn = document.getElementById('importSettingsBtn');
        if (importBtn) {
            importBtn.addEventListener('click', importSettings);
        }
        // 监听来自其他页面的消息
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.action === 'updateBlacklist') {
                currentConfig.blacklist = message.blacklist || [];
                renderBlacklist();
                showMessage('黑名单已更新');
            }
            if (message.action === 'settingsUpdated') {
                // 重新加载设置
                loadSettings();
                showMessage('设置已更新');
            }
        });
        console.log('设置页面初始化完成');
    }
    // 如果DOM还未加载完成，等待加载完成后再初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
});