class M3UParser {
    /**
     * @param {Object}  [options]
     * @param {boolean} [options.mergeSameChannels=true] 是否合并"同组同名"频道的 urls
     */
    constructor(options = {}) {
        this.playlist = [];
        this.globalEpgUrl = "";
        this.mergeSameChannels = options.mergeSameChannels !== false;
    }
    /**
     * 合并同组（groupTitle）同名（title）的频道：
     *  - 保留首次出现的位置和属性，后面重复条目的 urls 追加到第一条的 urls 末尾
     *  - 同一频道内重复的 url 自动去重
     *  - 如果首条没有台标，用后面重复条目的台标补上
     */
    static mergePlaylist(playlist) {
        const merged = [];
        const indexByKey = new Map();
        for (const item of playlist) {
            const key = item.groupTitle + "\u0000" + item.title;
            if (!indexByKey.has(key)) {
                indexByKey.set(key, merged.length);
                merged.push({ ...item, urls: [...item.urls] });
                continue;
            }
            const target = merged[indexByKey.get(key)];
            for (const url of item.urls) {
                if (!target.urls.includes(url)) {
                    target.urls.push(url);
                }
            }
            if (!target.tvgLogo && item.tvgLogo) {
                target.tvgLogo = item.tvgLogo;
            }
        }
        return merged;
    }
    parse(content) {
        this.playlist = [];
        this.globalEpgUrl = "";
        const lines = content.split(/\r?\n/);
        let currentItem = null;
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            if (line.startsWith("#EXTM3U")) {
                const epgMatch = line.match(/x-tvg-url="([^"]+)"/);
                if (epgMatch) {
                    this.globalEpgUrl = epgMatch[1].trim();
                }
                continue;
            }
            if (line.startsWith("#EXTINF:")) {
                if (currentItem && currentItem.urls.length > 0) {
                    this.playlist.push(currentItem);
                }
                currentItem = {
                    duration: -1,
                    title: "",
                    tvgName: "",
                    groupTitle: "",
                    tvgLogo: "",
                    urls: []
                };
                const tvgNameMatch = line.match(/tvg-name="([^"]+)"/);
                if (tvgNameMatch) {
                    currentItem.tvgName = tvgNameMatch[1].trim();
                }
                const groupTitleMatch = line.match(/group-title="([^"]+)"/);
                if (groupTitleMatch) {
                    currentItem.groupTitle = groupTitleMatch[1].trim();
                }
                const tvgLogoMatch = line.match(/tvg-logo="([^"]+)"/);
                if (tvgLogoMatch) {
                    currentItem.tvgLogo = tvgLogoMatch[1].trim();
                }
                const durationMatch = line.match(/#EXTINF:(-?\d+(\.\d+)?)/);
                if (durationMatch) {
                    currentItem.duration = parseFloat(durationMatch[1]);
                }
                const lastCommaIndex = line.lastIndexOf(",");
                if (lastCommaIndex !== -1) {
                    currentItem.title = line.substring(lastCommaIndex + 1).trim();
                } else {
                    currentItem.title = i18n.t("player_item_n", { N: this.playlist.length + 1 });
                }
                if (currentItem.tvgName) {
                    currentItem.title = currentItem.tvgName;
                }
            } else if (!line.startsWith("#") && line) {
                if (!currentItem) {
                    currentItem = {
                        duration: -1,
                        title: i18n.t("player_item_n", { N: this.playlist.length + 1 }),
                        tvgName: "",
                        groupTitle: "",
                        tvgLogo: "",
                        urls: []
                    };
                }
                currentItem.urls.push(line);
            }
        }
        if (currentItem && currentItem.urls.length > 0) {
            this.playlist.push(currentItem);
        }
        if (this.mergeSameChannels) {
            this.playlist = M3UParser.mergePlaylist(this.playlist);
        }
        return this.playlist;
    }
    async parseFromUrl(url) {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const content = await response.text();
            return this.parse(content);
        } catch (error) {
            console.error("解析 M3U 文件失败:", error);
            throw error;
        }
    }
    static resolveUrl(baseUrl, relativeUrl) {
        if (/^(https?:)?\/\//i.test(relativeUrl)) {
            return relativeUrl;
        }
        try {
            return new URL(relativeUrl, baseUrl).href;
        } catch (e) {
            console.error("URL 解析错误:", e);
            return relativeUrl;
        }
    }
}