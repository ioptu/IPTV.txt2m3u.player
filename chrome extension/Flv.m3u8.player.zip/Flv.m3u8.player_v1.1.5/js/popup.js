document.addEventListener("DOMContentLoaded", function() {
    const videoUrlInput = document.getElementById("videoUrl");
    const playBtn = document.getElementById("playBtn");
    const settingsBtn = document.getElementById("settingsBtn");
    // const epgToggle = document.getElementById("epgToggle");  // 新增
    // 尝试自动填充上次播放的URL
    // chrome.storage.local.get(['lastVideoUrl'], function(result) {
    //     if (result.lastVideoUrl) {
    //         videoUrlInput.value = result.lastVideoUrl;
    //     }
    // });
    // 新增：加载 EPG 开关状态
    function loadEpgState() {
        chrome.storage.local.get(null, function(result) {  // 获取所有配置
            const enabled = result.epgEnabled !== undefined ? result.epgEnabled : false;  // 默认 false，与 settings 默认一致
            epgToggle.checked = enabled;
        });
    }
    // 新增：保存 EPG 状态并模拟 settings 保存（即时生效）
    function saveEpgState(enabled) {
        // 先获取当前所有配置
        chrome.storage.local.get(null, function(currentConfig) {
            // 更新 epgEnabled（其他字段保持不变）
            const updatedConfig = {
                ...currentConfig,
                epgEnabled: enabled
            };
            // 保存整个更新后的 config 到 storage
            chrome.storage.local.set(updatedConfig, function() {
                if (chrome.runtime.lastError) {
                    console.error('保存 EPG 状态失败:', chrome.runtime.lastError);
                    return;
                }
                // 发送与 settings.js 相同的消息，带整个 config（让 player 等页面即时更新）
                try {
                    chrome.runtime.sendMessage({
                        action: 'settingsUpdated',
                        config: updatedConfig
                    });
                } catch (error) {
                    console.warn('发送设置更新消息失败:', error);
                }
            });
        });
    }
    // 新增：初始化加载状态
    loadEpgState();
    // 新增：开关变化时立即保存并通知
    const epgToggle = document.getElementById("epgToggle");
    if (epgToggle) {
        epgToggle.addEventListener('change', function() {
            saveEpgState(this.checked);
        });
    }
    // 监听输入框的粘贴事件（自动播放链接）
    videoUrlInput.addEventListener('paste', function(e) {
        setTimeout(() => {
            const text = videoUrlInput.value.trim();
            if (text && (text.includes('.flv') || text.includes('.ts') || text.includes('.m3u8') || text.includes('.m3u'))) {
                playVideo(text);
            }
        }, 100);
    });
    // 监听输入框的回车键
    videoUrlInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const url = videoUrlInput.value.trim();
            if (url) {
                playVideo(url);
            }
        }
    });
    playBtn.addEventListener("click", function() {
        const url = videoUrlInput.value.trim();
        if (url) {
            playVideo(url);
        } else {
            alert("请输入有效的视频链接");
        }
    });
    function playVideo(url) {
        // 保存URL到storage
        // chrome.storage.local.set({ lastVideoUrl: url });
        chrome.tabs.create({
            url: chrome.runtime.getURL("player.html") + "?url=" + encodeURIComponent(url)
        });
    }
    settingsBtn.addEventListener("click", () => {
      if (chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
        window.close();  // 可选：关闭 popup
      } else {
        // 回退
        chrome.tabs.create({ url: chrome.runtime.getURL("settings.html") });
      }
    });
    // 从 manifest.json 读取版本号并显示
    const versionElement = document.querySelector('.version');
    if (versionElement) {
        try {
            const manifest = chrome.runtime.getManifest();
            if (manifest && manifest.version) {
                versionElement.textContent = `${manifest.version}`;
            } else {
                versionElement.textContent = "0.1"; // 默认值
            }
        } catch (error) {
            console.warn('无法读取manifest版本号:', error);
            versionElement.textContent = "0.1"; // 默认值
        }
    }
});