// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", function() {
    // DOM 元素
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const backBtn = document.querySelector('.back-btn');
    const saveBtn = document.getElementById('saveBtn');
    const resetBtn = document.getElementById('resetBtn');
    const blacklistInput = document.getElementById('blacklistInput');
    const addKeywordBtn = document.getElementById('addKeywordBtn');
    const blacklistItems = document.getElementById('blacklistItems');
    const testEpgBtn = document.getElementById('testEpgBtn');
    // 默认配置（用户友好的单位）
    const DEFAULT_CONFIG = {
        loadTimeout: 10, // 秒
        stallTimeout: 10, // 秒
        maxRetryRounds: 1, // 轮
        searchDebounce: 300, // 毫秒
        playlistRefreshInterval: 30, // 分钟
        autoRefreshEnabled: true,
        epgEnabled: false,
        epgUrl: 'http://e.erw.cc/e.xml.gz',
        marqueeSpeed: 100,
        marqueeColor: '#ffd700',
        marqueeFontSize: '20',
        blacklist: [],
        headerRules: []
    };
    let currentConfig = { ...DEFAULT_CONFIG };
    // ==================== 新增：自动刷新频道列表 UI 控制 ====================
    function updateAutoRefreshUIState() {
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        if (!autoRefreshEnabledInput) return;
        const isEnabled = autoRefreshEnabledInput.checked;
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        if (playlistRefreshIntervalInput) {
            playlistRefreshIntervalInput.disabled = !isEnabled;
            playlistRefreshIntervalInput.style.opacity = isEnabled ? '1' : '0.6';
        }
    }
    // ==================== 原有 EPG UI 控制 ====================
    function updateEpgUIState() {
        const epgEnabledInput = document.getElementById('epgEnabled');
        if (!epgEnabledInput) return;
        const isEpgEnabled = epgEnabledInput.checked;
        const epgUrlInput = document.getElementById('epgUrl');
        const marqueeSpeedInput = document.getElementById('marqueeSpeed');
        const marqueeColorContainer = document.querySelector('.color-picker-container');
        const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
        const testEpgBtn = document.getElementById('testEpgBtn');
        [epgUrlInput, marqueeSpeedInput, marqueeFontSizeInput].forEach(input => {
            if (input) {
                input.disabled = !isEpgEnabled;
                input.style.opacity = isEpgEnabled ? '1' : '0.6';
            }
        });
        if (marqueeColorContainer) {
            const inputs = marqueeColorContainer.querySelectorAll('input');
            inputs.forEach(input => { input.disabled = !isEpgEnabled; });
            marqueeColorContainer.style.opacity = isEpgEnabled ? '1' : '0.6';
        }
        if (testEpgBtn) {
            testEpgBtn.disabled = !isEpgEnabled;
            testEpgBtn.style.opacity = isEpgEnabled ? '1' : '0.6';
        }
    }
    // 初始化标签页切换
    function initTabs() {
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.getAttribute('data-tab');
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                tabContents.forEach(content => content.classList.remove('active'));
                const targetTab = document.getElementById(`${tabId}-tab`);
                if (targetTab) targetTab.classList.add('active');
            });
        });
    }
    // 初始化颜色选择器
    function initColorPicker() {
        const colorPicker = document.getElementById('marqueeColor');
        const colorText = document.getElementById('marqueeColorText');
        if (colorPicker && colorText) {
            colorPicker.addEventListener('input', (e) => { colorText.value = e.target.value; });
            colorText.addEventListener('input', (e) => {
                const value = e.target.value;
                if (/^#[0-9A-F]{6}$/i.test(value)) colorPicker.value = value;
            });
            colorText.addEventListener('blur', (e) => {
                let value = e.target.value.trim();
                if (!value.startsWith('#')) value = '#' + value;
                if (/^#[0-9A-F]{6}$/i.test(value)) {
                    colorPicker.value = value;
                    colorText.value = value;
                } else {
                    colorText.value = colorPicker.value;
                }
            });
        }
    }
    // 加载设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout', 'stallTimeout', 'maxRetryRounds', 'searchDebounce',
            'playlistRefreshInterval', 'autoRefreshEnabled', 'epgEnabled', 'epgUrl',
            'marqueeSpeed', 'marqueeColor', 'marqueeFontSize', 'blacklist', 'headerRules'
        ], function(result) {
            const loadTimeoutInput = document.getElementById('loadTimeout');
            const stallTimeoutInput = document.getElementById('stallTimeout');
            const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
            const searchDebounceInput = document.getElementById('searchDebounce');
            const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
            const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
            const epgEnabledInput = document.getElementById('epgEnabled');
            const epgUrlInput = document.getElementById('epgUrl');
            const marqueeSpeedInput = document.getElementById('marqueeSpeed');
            const marqueeColorInput = document.getElementById('marqueeColor');
            const marqueeColorText = document.getElementById('marqueeColorText');
            const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
            if (loadTimeoutInput) loadTimeoutInput.value = result.loadTimeout !== undefined ? Math.round(result.loadTimeout / 1000) : DEFAULT_CONFIG.loadTimeout;
            if (stallTimeoutInput) stallTimeoutInput.value = result.stallTimeout !== undefined ? Math.round(result.stallTimeout / 1000) : DEFAULT_CONFIG.stallTimeout;
            if (maxRetryRoundsInput) maxRetryRoundsInput.value = result.maxRetryRounds !== undefined ? result.maxRetryRounds : DEFAULT_CONFIG.maxRetryRounds;
            if (searchDebounceInput) searchDebounceInput.value = result.searchDebounce !== undefined ? result.searchDebounce : DEFAULT_CONFIG.searchDebounce;
            if (playlistRefreshIntervalInput) playlistRefreshIntervalInput.value = result.playlistRefreshInterval !== undefined ? Math.round(result.playlistRefreshInterval / 60000) : DEFAULT_CONFIG.playlistRefreshInterval;
            if (autoRefreshEnabledInput) autoRefreshEnabledInput.checked = result.autoRefreshEnabled !== undefined ? result.autoRefreshEnabled : DEFAULT_CONFIG.autoRefreshEnabled;
            if (epgEnabledInput) epgEnabledInput.checked = result.epgEnabled !== undefined ? result.epgEnabled : DEFAULT_CONFIG.epgEnabled;
            if (epgUrlInput) epgUrlInput.value = result.epgUrl !== undefined ? result.epgUrl : DEFAULT_CONFIG.epgUrl;
            if (marqueeSpeedInput) marqueeSpeedInput.value = result.marqueeSpeed !== undefined ? result.marqueeSpeed : DEFAULT_CONFIG.marqueeSpeed;
            if (marqueeColorInput && marqueeColorText) {
                const colorValue = result.marqueeColor !== undefined ? result.marqueeColor : DEFAULT_CONFIG.marqueeColor;
                marqueeColorInput.value = colorValue;
                marqueeColorText.value = colorValue;
            }
            if (marqueeFontSizeInput) marqueeFontSizeInput.value = result.marqueeFontSize !== undefined ? result.marqueeFontSize : DEFAULT_CONFIG.marqueeFontSize;
            currentConfig.loadTimeout = loadTimeoutInput ? parseInt(loadTimeoutInput.value) : DEFAULT_CONFIG.loadTimeout;
            currentConfig.stallTimeout = stallTimeoutInput ? parseInt(stallTimeoutInput.value) : DEFAULT_CONFIG.stallTimeout;
            currentConfig.maxRetryRounds = maxRetryRoundsInput ? parseInt(maxRetryRoundsInput.value) : DEFAULT_CONFIG.maxRetryRounds;
            currentConfig.searchDebounce = searchDebounceInput ? parseInt(searchDebounceInput.value) : DEFAULT_CONFIG.searchDebounce;
            currentConfig.playlistRefreshInterval = playlistRefreshIntervalInput ? parseInt(playlistRefreshIntervalInput.value) : DEFAULT_CONFIG.playlistRefreshInterval;
            currentConfig.autoRefreshEnabled = autoRefreshEnabledInput ? autoRefreshEnabledInput.checked : DEFAULT_CONFIG.autoRefreshEnabled;
            currentConfig.epgEnabled = epgEnabledInput ? epgEnabledInput.checked : DEFAULT_CONFIG.epgEnabled;
            currentConfig.epgUrl = epgUrlInput ? epgUrlInput.value : DEFAULT_CONFIG.epgUrl;
            currentConfig.marqueeSpeed = marqueeSpeedInput ? parseFloat(marqueeSpeedInput.value) : DEFAULT_CONFIG.marqueeSpeed;
            currentConfig.marqueeColor = marqueeColorInput ? marqueeColorInput.value : DEFAULT_CONFIG.marqueeColor;
            currentConfig.marqueeFontSize = marqueeFontSizeInput ? marqueeFontSizeInput.value : DEFAULT_CONFIG.marqueeFontSize;
            if (result.blacklist && Array.isArray(result.blacklist)) {
                currentConfig.blacklist = result.blacklist;
            } else {
                loadBlacklistFromFile();
            }
            renderBlacklist();
            if (result.headerRules && Array.isArray(result.headerRules)) {
                currentConfig.headerRules = result.headerRules;
            } else {
                currentConfig.headerRules = [];
            }
            renderHeaderRules();
            updateEpgUIState();
            updateAutoRefreshUIState();   // 新增调用
        });
    }
    // 从文件加载黑名单
    function loadBlacklistFromFile() {
        fetch(chrome.runtime.getURL('blacklist.txt'))
            .then(response => response.text())
            .then(text => {
                const keywords = text.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                currentConfig.blacklist = keywords;
                renderBlacklist();
            })
            .catch(error => {
                console.warn('无法加载黑名单文件:', error);
                currentConfig.blacklist = [];
                renderBlacklist();
            });
    }
    // 渲染黑名单列表
    function renderBlacklist() {
        if (!blacklistItems) return;
        blacklistItems.innerHTML = '';
        if (currentConfig.blacklist.length === 0) {
            blacklistItems.innerHTML = `<div class="empty-state"><div>📝</div><p>暂无黑名单规则</p><p class="tip">添加关键词以过滤不需要的内容</p></div>`;
            return;
        }
        currentConfig.blacklist.forEach((keyword, index) => {
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            item.innerHTML = `<div class="blacklist-keyword">${escapeHtml(keyword)}</div><div class="blacklist-actions"><button class="edit-btn" data-index="${index}">✏️</button><button class="delete-btn" data-index="${index}">🗑️</button></div>`;
            blacklistItems.appendChild(item);
        });
        document.querySelectorAll('.edit-btn').forEach(btn => btn.addEventListener('click', e => editKeyword(parseInt(e.target.getAttribute('data-index')))));
        document.querySelectorAll('.delete-btn').forEach(btn => btn.addEventListener('click', e => deleteKeyword(parseInt(e.target.getAttribute('data-index')))));
    }
    // 渲染 header rules
    function renderHeaderRules() {
        const container = document.getElementById('headerRulesItems');
        if (!container) return;
        container.innerHTML = '';
        if (currentConfig.headerRules.length === 0) {
            container.innerHTML = `<div class="empty-state"><div>🔐</div><p>暂无自定义 Header 规则</p><p class="tip">添加规则以针对不同域名/路径设置专属 headers</p></div>`;
            return;
        }
        currentConfig.headerRules.forEach((rule, index) => {
            const headersStr = Object.entries(rule.headers || {}).map(([k, v]) => `${k}: ${v}`).join('; ');
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            item.innerHTML = `<div class="blacklist-keyword"><strong>pattern:</strong> ${escapeHtml(rule.pattern)}<br><strong>headers:</strong> ${escapeHtml(headersStr)}</div><div class="blacklist-actions"><button class="edit-btn" data-index="${index}">✏️</button><button class="delete-btn" data-index="${index}">🗑️</button></div>`;
            container.appendChild(item);
        });
        container.querySelectorAll('.edit-btn').forEach(btn => btn.addEventListener('click', e => editHeaderRule(parseInt(e.target.dataset.index))));
        container.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', e => {
                if (confirm('确定删除这条 Header 规则吗？')) {
                    currentConfig.headerRules.splice(parseInt(e.target.dataset.index), 1);
                    renderHeaderRules();
                    showMessage('规则已删除');
                }
            });
        });
    }
    // 添加关键词
    function addKeyword() {
        if (!blacklistInput) return;
        const keyword = blacklistInput.value.trim();
        if (!keyword) { alert('请输入关键词'); return; }
        if (currentConfig.blacklist.includes(keyword)) { alert('该关键词已存在'); return; }
        currentConfig.blacklist.push(keyword);
        blacklistInput.value = '';
        renderBlacklist();
        showMessage('关键词已添加');
    }
    function editKeyword(index) {
        const oldKeyword = currentConfig.blacklist[index];
        const newKeyword = prompt('编辑关键词:', oldKeyword);
        if (newKeyword !== null) {
            const trimmedKeyword = newKeyword.trim();
            if (trimmedKeyword && !currentConfig.blacklist.includes(trimmedKeyword)) {
                currentConfig.blacklist[index] = trimmedKeyword;
                renderBlacklist();
                showMessage('关键词已更新');
            } else if (!trimmedKeyword) alert('关键词不能为空');
            else alert('该关键词已存在');
        }
    }
    function deleteKeyword(index) {
        if (confirm('确定要删除这个关键词吗？')) {
            currentConfig.blacklist.splice(index, 1);
            renderBlacklist();
            showMessage('关键词已删除');
        }
    }
    // 解析 headers
    function parseHeaders(str) {
        const headers = {};
        let i = 0, len = str.length;
        while (i < len) {
            while (i < len && /\s/.test(str[i])) i++;
            if (i >= len) break;
            let keyStart = i;
            while (i < len && str[i] !== ':') i++;
            let key = str.substring(keyStart, i).trim();
            if (i < len) i++;
            while (i < len && /\s/.test(str[i])) i++;
            let value = '';
            if (i < len && (str[i] === '"' || str[i] === "'")) {
                const quote = str[i]; i++;
                let escapedValue = '';
                while (i < len) {
                    if (str[i] === '\\') { i++; if (i < len) escapedValue += str[i++]; continue; }
                    if (str[i] === quote) { value = escapedValue; i++; break; }
                    escapedValue += str[i++];
                }
            } else {
                let start = i;
                while (i < len && str[i] !== ';') i++;
                value = str.substring(start, i).trim();
            }
            if (key) headers[key] = value;
            while (i < len && (str[i] === ';' || /\s/.test(str[i]))) i++;
        }
        return headers;
    }
    function addHeaderRule() {
        const patternInput = document.getElementById('rulePatternInput');
        const headersInput = document.getElementById('ruleHeadersInput');
        if (!patternInput || !headersInput) return;
        const pattern = patternInput.value.trim();
        const headersStr = headersInput.value.trim();
        if (!pattern) { alert('请输入 pattern'); return; }
        if (!headersStr) { alert('请输入 headers（格式：Key1: value1; Key2: value2）'); return; }
        const headers = parseHeaders(headersStr);
        if (Object.keys(headers).length === 0) { alert('没有解析到有效的 header 键值对'); return; }
        currentConfig.headerRules.push({ pattern, headers });
        patternInput.value = '';
        headersInput.value = '';
        renderHeaderRules();
        showMessage('Header 规则已添加');
    }
    function editHeaderRule(index) {
        const rule = currentConfig.headerRules[index];
        if (!rule) return;
        const headersStr = Object.entries(rule.headers).map(([k, v]) => `${k}: ${v}`).join('; ');
        const newInput = prompt('编辑规则（格式：pattern | headers）', `${rule.pattern} | ${headersStr}`);
        if (newInput === null) return;
        const [newPatternPart, newHeadersPart] = newInput.split('|').map(s => s.trim());
        if (!newPatternPart || !newHeadersPart) { alert('格式错误，应为：pattern | key1: val1; key2: val2'); return; }
        const newHeaders = parseHeaders(newHeadersPart);
        if (Object.keys(newHeaders).length === 0) { alert('没有有效的 header'); return; }
        currentConfig.headerRules[index] = { pattern: newPatternPart, headers: newHeaders };
        renderHeaderRules();
        showMessage('规则已更新');
    }
    // 测试EPG数据源（保持完整）
    function testEpgDataSource() {
        const epgUrlInput = document.getElementById('epgUrl');
        const epgTestResult = document.getElementById('epgTestResult');
        const epgPreview = document.getElementById('epgPreview');
        if (!epgUrlInput || !epgUrlInput.value.trim()) {
            showMessage('请输入EPG数据源URL', false);
            return;
        }
        const url = epgUrlInput.value.trim();
        epgTestResult.textContent = '正在测试EPG数据源...';
        epgTestResult.style.color = '#2196F3';
        epgPreview.innerHTML = `<div class="empty-state"><div>⏳</div><p>正在加载EPG数据...</p><p class="tip">请稍候</p></div>`;
        chrome.runtime.sendMessage({ action: 'testEpgUrl', url: url }, function(response) {
            if (chrome.runtime.lastError) {
                epgTestResult.textContent = '测试失败：' + chrome.runtime.lastError.message;
                epgTestResult.style.color = '#f44336';
                showMessage('EPG测试失败', false);
                return;
            }
            if (response && response.success) {
                epgTestResult.textContent = 'EPG数据源测试成功！';
                epgTestResult.style.color = '#4CAF50';
                showMessage('EPG数据源测试成功');
                if (response.data && response.data.length > 0) {
                    let previewHTML = `<div style="margin-bottom: 10px; color: #666; font-size: 12px;">已加载 ${response.data.length} 个节目</div>`;
                    response.data.slice(0, 5).forEach(item => {
                        const startTime = item.start ? new Date(item.start).toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'}) : '--:--';
                        const endTime = item.stop ? new Date(item.stop).toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'}) : '--:--';
                        previewHTML += `<div class="epg-preview-item"><div class="epg-preview-time">${startTime} - ${endTime}</div><div class="epg-preview-title">${escapeHtml(item.title || '未知节目')}</div></div>`;
                    });
                    epgPreview.innerHTML = previewHTML;
                }
            } else {
                const errorMsg = response && response.error ? response.error : '未知错误';
                epgTestResult.textContent = 'EPG数据源测试失败：' + errorMsg;
                epgTestResult.style.color = '#f44336';
                showMessage('EPG测试失败: ' + errorMsg, false);
            }
        });
    }
    // 保存设置（完整）
    function saveSettings() {
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        const epgEnabledInput = document.getElementById('epgEnabled');
        const epgUrlInput = document.getElementById('epgUrl');
        const marqueeSpeedInput = document.getElementById('marqueeSpeed');
        const marqueeColorInput = document.getElementById('marqueeColor');
        const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
        const loadTimeout = parseInt(loadTimeoutInput.value);
        const stallTimeout = parseInt(stallTimeoutInput.value);
        const maxRetryRounds = parseInt(maxRetryRoundsInput.value);
        const searchDebounce = parseInt(searchDebounceInput.value);
        const playlistRefreshInterval = parseInt(playlistRefreshIntervalInput.value);
        const autoRefreshEnabled = autoRefreshEnabledInput.checked;
        const epgEnabled = epgEnabledInput.checked;
        const epgUrl = epgUrlInput.value.trim();
        const marqueeSpeed = parseFloat(marqueeSpeedInput.value);
        const marqueeColor = marqueeColorInput.value.trim();
        const marqueeFontSize = marqueeFontSizeInput.value.trim();
        // 验证（与原代码一致）
        if (isNaN(loadTimeout) || loadTimeout < 1) { alert('加载超时时间必须大于等于1秒'); return; }
        if (isNaN(stallTimeout) || stallTimeout < 1) { alert('卡顿检测时间必须大于等于1秒'); return; }
        if (isNaN(maxRetryRounds) || maxRetryRounds < 1) { alert('最大重试轮次必须大于等于1'); return; }
        if (isNaN(searchDebounce) || searchDebounce < 100) { alert('搜索防抖延迟必须大于等于100毫秒'); return; }
        if (isNaN(playlistRefreshInterval) || playlistRefreshInterval < 5) { alert('频道列表刷新间隔必须大于等于5分钟'); return; }
        if (epgEnabled && !epgUrl) { alert('启用EPG功能必须设置EPG数据源URL'); return; }
        if (marqueeSpeed < 50 || marqueeSpeed > 500) { alert('跑马灯速度必须在50-500像素/秒之间'); return; }
        if (!/^#[0-9A-F]{6}$/i.test(marqueeColor)) { alert('请选择有效的颜色值'); return; }
        if (!/^\d+$/.test(marqueeFontSize)) { alert('请输入有效的字体大小数字'); return; }
        const configToSave = {
            loadTimeout: loadTimeout * 1000,
            stallTimeout: stallTimeout * 1000,
            maxRetryRounds,
            searchDebounce,
            playlistRefreshInterval: playlistRefreshInterval * 60000,
            autoRefreshEnabled,
            epgEnabled,
            epgUrl,
            marqueeSpeed,
            marqueeColor,
            marqueeFontSize,
            blacklist: [...currentConfig.blacklist],
            headerRules: currentConfig.headerRules.map(r => ({ ...r, headers: { ...r.headers } }))
        };
        chrome.storage.local.set(configToSave, function() {
            showMessage('设置已保存！', true);
            currentConfig.loadTimeout = loadTimeout;
            currentConfig.stallTimeout = stallTimeout;
            currentConfig.maxRetryRounds = maxRetryRounds;
            currentConfig.searchDebounce = searchDebounce;
            currentConfig.playlistRefreshInterval = playlistRefreshInterval;
            currentConfig.autoRefreshEnabled = autoRefreshEnabled;
            currentConfig.epgEnabled = epgEnabled;
            currentConfig.epgUrl = epgUrl;
            currentConfig.marqueeSpeed = marqueeSpeed;
            currentConfig.marqueeColor = marqueeColor;
            currentConfig.marqueeFontSize = marqueeFontSize;
            chrome.runtime.sendMessage({ action: 'settingsUpdated', config: configToSave });
            chrome.runtime.sendMessage({ action: 'updateHeaderRules' });
        });
    }
    // 恢复默认设置
    function resetSettings() {
        if (!confirm('确定要恢复默认设置吗？这将清除所有自定义设置。')) return;
        document.getElementById('loadTimeout').value = DEFAULT_CONFIG.loadTimeout;
        document.getElementById('stallTimeout').value = DEFAULT_CONFIG.stallTimeout;
        document.getElementById('maxRetryRounds').value = DEFAULT_CONFIG.maxRetryRounds;
        document.getElementById('searchDebounce').value = DEFAULT_CONFIG.searchDebounce;
        document.getElementById('playlistRefreshInterval').value = DEFAULT_CONFIG.playlistRefreshInterval;
        document.getElementById('autoRefreshEnabled').checked = DEFAULT_CONFIG.autoRefreshEnabled;
        document.getElementById('epgEnabled').checked = DEFAULT_CONFIG.epgEnabled;
        document.getElementById('epgUrl').value = DEFAULT_CONFIG.epgUrl;
        document.getElementById('marqueeSpeed').value = DEFAULT_CONFIG.marqueeSpeed;
        document.getElementById('marqueeColor').value = DEFAULT_CONFIG.marqueeColor;
        document.getElementById('marqueeColorText').value = DEFAULT_CONFIG.marqueeColor;
        document.getElementById('marqueeFontSize').value = DEFAULT_CONFIG.marqueeFontSize;
        currentConfig = { ...DEFAULT_CONFIG };
        renderBlacklist();
        renderHeaderRules();
        updateEpgUIState();
        updateAutoRefreshUIState();   // 新增
        chrome.storage.local.clear(function() {
            showMessage('已恢复默认设置');
        });
    }
    function showMessage(message, isSuccess = true) {
        const existing = document.querySelector('.message-toast');
        if (existing) existing.remove();
        const div = document.createElement('div');
        div.className = `message-toast ${isSuccess ? 'success' : 'info'}`;
        div.textContent = message;
        div.style.cssText = `position:fixed;top:20px;right:20px;padding:12px 24px;background:${isSuccess?'#4CAF50':'#FF9800'};color:white;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);z-index:1000;animation:slideIn 0.3s ease;`;
        document.body.appendChild(div);
        setTimeout(() => { if (div.parentNode) div.remove(); }, 3000);
    }
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    function addInputValidation() {
        document.querySelectorAll('input[type="number"]').forEach(input => {
            input.addEventListener('change', function() {
                const min = parseFloat(this.min) || 1;
                const max = parseFloat(this.max) || 9999;
                let value = parseFloat(this.value);
                if (isNaN(value)) this.value = min;
                else if (value < min) this.value = min;
                else if (value > max) this.value = max;
            });
        });
    }
    function exportSettings() {
        const data = JSON.stringify(currentConfig);
        const blob = new Blob([data], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.download = 'fmplayer_settings.json';
        a.href = url;
        a.click();
        URL.revokeObjectURL(url);
        showMessage('设置已导出');
    }
    function importSettings() {
        const file = document.getElementById('importSettingsInput').files[0];
        if (!file) { showMessage('请先选择文件', false); return; }
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedConfig = JSON.parse(e.target.result);
                currentConfig = { ...DEFAULT_CONFIG, ...importedConfig };
                document.getElementById('loadTimeout').value = currentConfig.loadTimeout;
                document.getElementById('stallTimeout').value = currentConfig.stallTimeout;
                document.getElementById('maxRetryRounds').value = currentConfig.maxRetryRounds;
                document.getElementById('searchDebounce').value = currentConfig.searchDebounce;
                document.getElementById('playlistRefreshInterval').value = currentConfig.playlistRefreshInterval;
                document.getElementById('autoRefreshEnabled').checked = currentConfig.autoRefreshEnabled;
                document.getElementById('epgEnabled').checked = currentConfig.epgEnabled;
                document.getElementById('epgUrl').value = currentConfig.epgUrl;
                document.getElementById('marqueeSpeed').value = currentConfig.marqueeSpeed;
                document.getElementById('marqueeColor').value = currentConfig.marqueeColor;
                document.getElementById('marqueeColorText').value = currentConfig.marqueeColor;
                document.getElementById('marqueeFontSize').value = currentConfig.marqueeFontSize;
                renderBlacklist();
                renderHeaderRules();
                updateEpgUIState();
                updateAutoRefreshUIState();
                showMessage('设置已导入，请点击"保存设置"以保存并使生效');
            } catch (err) {
                showMessage('导入失败: 无效的JSON文件', false);
            }
        };
        reader.readAsText(file);
    }
    // 初始化
    function init() {
        initTabs();
        initColorPicker();
        addInputValidation();
        loadSettings();
        if (backBtn) backBtn.addEventListener('click', () => window.close());
        if (saveBtn) saveBtn.addEventListener('click', saveSettings);
        if (resetBtn) resetBtn.addEventListener('click', resetSettings);
        if (addKeywordBtn) addKeywordBtn.addEventListener('click', addKeyword);
        if (testEpgBtn) testEpgBtn.addEventListener('click', testEpgDataSource);
        const addRuleBtn = document.getElementById('addRuleBtn');
        if (addRuleBtn) addRuleBtn.addEventListener('click', addHeaderRule);
        const epgEnabledInput = document.getElementById('epgEnabled');
        if (epgEnabledInput) epgEnabledInput.addEventListener('change', updateEpgUIState);
        // 新增：自动刷新监听
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        if (autoRefreshEnabledInput) autoRefreshEnabledInput.addEventListener('change', updateAutoRefreshUIState);
        document.getElementById('exportSettingsBtn')?.addEventListener('click', exportSettings);
        document.getElementById('importSettingsBtn')?.addEventListener('click', importSettings);
        if (blacklistInput) {
            blacklistInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') addKeyword(); });
        }
        chrome.runtime.onMessage.addListener((message) => {
            if (message.action === 'updateBlacklist') {
                currentConfig.blacklist = message.blacklist || [];
                renderBlacklist();
                showMessage('黑名单已更新');
            }
            if (message.action === 'settingsUpdated') {
                loadSettings();
                showMessage('设置已更新');
            }
        });
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
});