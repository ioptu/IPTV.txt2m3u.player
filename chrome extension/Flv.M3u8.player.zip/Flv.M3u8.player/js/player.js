document.addEventListener("DOMContentLoaded", function() {
    let videoUrl = "";
    const urlParams = new URLSearchParams(window.location.search);
    const queryUrl = urlParams.get("url");
    const hashUrl = window.location.hash.substring(1);
    videoUrl = queryUrl || hashUrl;

    // --- 核心配置变量 ---
    const LOAD_TIMEOUT_MS = 3000;      // 加载超时 3s   
    const STALL_TIMEOUT_MS = 5000;     // 卡顿超时 5s
    const MAX_RETRY_CYCLES = 3;        // 最大重试轮数
    // ------------------

    const videoPlayer = document.getElementById("videoPlayer");
    const videoInfo = document.getElementById("videoInfo");
    const backBtn = document.getElementById("backBtn");
    const playPauseBtn = document.getElementById("playPauseBtn");
    const progress = document.getElementById("progress");
    const progressBar = document.getElementById("progressBar");
    const timeDisplay = document.getElementById("time");
    const volumeBtn = document.getElementById("volumeBtn");
    const volumeSlider = document.getElementById("volumeSlider");
    const volumeProgress = document.getElementById("volumeProgress");
    const fullscreenBtn = document.getElementById("fullscreenBtn");
    const loading = document.getElementById("loading");
    const errorMessage = document.getElementById("errorMessage");
    const controls = document.getElementById("controls");
    const playlistBtn = document.getElementById("playlistBtn");
    const playlistContainer = document.getElementById("playlist-container");
    const closePlaylistBtn = document.getElementById("closePlaylistBtn");
    const playlistItems = document.getElementById("playlist-items");
    const playlistSearchInput = document.getElementById("playlist-search-input");
    const clearSearchBtn = document.getElementById("clearSearchBtn");

    let player = null;
    let isPlaying = false;
    let controlsTimeout;
    let videoContainer = document.querySelector(".video-container");
    let loadTimeoutTimer = null;
    let stallTimeoutTimer = null;
    let hidePlaylistTimeout; 

    let currentPlaylist = [];
    let currentPlaylistIndex = -1;
    let isM3UPlaylist = false;
    let baseUrl = "";
    let streamInfo = { resolution: "未知", type: "未知" };

    // --- 信息面板逻辑 ---
    const infoBtn = document.createElement("button");
    infoBtn.className = "info-btn";
    infoBtn.innerHTML = "ℹ";
    infoBtn.style.cssText = "background:none; border:none; color:white; cursor:pointer; margin-left:10px;";
    const volumeContainer = document.querySelector(".volume-container");
    if(volumeContainer) volumeContainer.insertAdjacentElement("afterend", infoBtn);

    const infoPanel = document.createElement("div");
    infoPanel.className = "info-panel";
    infoPanel.style.cssText = "display:none; position:absolute; bottom:60px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px; z-index:100; color:white; line-height:1.6;";
    videoContainer.appendChild(infoPanel);

    function updateInfoPanel() {
        const info = [`类型: ${streamInfo.type}`, `分辨率: ${streamInfo.resolution}`];
        if (isM3UPlaylist && currentPlaylistIndex >= 0) {
            const item = currentPlaylist[currentPlaylistIndex];
            info.push(`频道: ${currentPlaylistIndex + 1}/${currentPlaylist.length}`);
            if (item.urls && item.urls.length > 0) {
                const cycleDisplay = item.isTotallyFailed ? "已停止" : `${(item.retryCycle || 0) + 1}/${MAX_RETRY_CYCLES}`;
                info.push(`线路: ${(item.currentUrlIndex || 0) + 1}/${item.urls.length} (轮次: ${cycleDisplay})`);
            }
        }
        infoPanel.innerHTML = info.join("<br>");
    }

    // 辅助函数：从视频元素直接更新分辨率
    function updateVideoInfoFromElement() {
        if (videoPlayer.videoWidth && videoPlayer.videoHeight) {
            streamInfo.resolution = `${videoPlayer.videoWidth}x${videoPlayer.videoHeight}`;
            updateInfoPanel();
        }
    }

    // --- 核心入口函数 ---
    function initPlayer() {
        if (!videoUrl) {
            showError("无效的视频链接");
            return;
        }
        videoInfo.textContent = decodeURIComponent(videoUrl);
        showLoading(true);
        try {
            const url = new URL(videoUrl);
            baseUrl = url.href.substring(0, url.href.lastIndexOf("/") + 1);
        } catch (e) {
            baseUrl = "";
        }
        checkAndInitPlayer(videoUrl);
    }

    // --- 播放控制与重试机制 ---
    function tryNextRedundantUrl() {
        if (currentPlaylistIndex === -1) return;
        const item = currentPlaylist[currentPlaylistIndex];
        if (!item || !item.urls || item.urls.length === 0 || item.isTotallyFailed) return;

        if (item.retryCycle === undefined) item.retryCycle = 0;
        let nextIndex = item.currentUrlIndex + 1;

        if (nextIndex >= item.urls.length) {
            if (item.retryCycle < MAX_RETRY_CYCLES - 1) {
                nextIndex = 0;
                item.retryCycle++;
            } else {
                item.isTotallyFailed = true; 
                showError(`播放失败或太过卡顿，请更换频道。`);
                updateInfoPanel();
                return; 
            }
        }

        item.currentUrlIndex = nextIndex;
        const nextUrl = item.urls[nextIndex];
        
        if (player && player.destroy) player.destroy();
        player = null;
        videoPlayer.removeAttribute("src");
        showLoading(true);
        errorMessage.style.display = "none";
        checkAndInitPlayer(nextUrl);
        updateInfoPanel();

        clearTimeout(loadTimeoutTimer);
        loadTimeoutTimer = setTimeout(() => {
            if (!item.isTotallyFailed) tryNextRedundantUrl();
        }, LOAD_TIMEOUT_MS);
    }

    function playPlaylistItem(index) {
        if (index < 0 || index >= currentPlaylist.length) return;
        currentPlaylistIndex = index;
        const item = currentPlaylist[index];
        item.currentUrlIndex = 0;
        item.retryCycle = 0; 
        item.isTotallyFailed = false; 

        document.querySelectorAll(".playlist-item").forEach((el, i) => el.classList.toggle("active", i === index));
        
        if (player && player.destroy) player.destroy();
        player = null;
        videoPlayer.removeAttribute("src");
        
        clearTimeout(loadTimeoutTimer);
        clearTimeout(stallTimeoutTimer);
        
        streamInfo = { resolution: "未知", type: "未知" };
        videoInfo.textContent = item.title || "加载中...";
        showLoading(true);
        errorMessage.style.display = "none";
        
        checkAndInitPlayer(item.urls[0] || item.url);
        updateInfoPanel();

        if (isM3UPlaylist) {
            loadTimeoutTimer = setTimeout(() => {
                if (!item.isTotallyFailed) tryNextRedundantUrl();
            }, LOAD_TIMEOUT_MS);
        }
    }

    function checkAndInitPlayer(url) {
        const lowerUrl = url.toLowerCase();
        if (/(?:\.(flv|m3u8|m3u)|#m3u8|#m3u)([?#].*)?$/.test(lowerUrl)) {
            initPlayerWithUrl(url);
        } else {
            chrome.runtime.sendMessage({ action: "checkRedirect", url: url }, response => {
                initPlayerWithUrl(response?.finalUrl || url, response?.contentType?.toLowerCase() || "");
            });
        }
    }

    function initPlayerWithUrl(url, contentType = "") {
        const lowerUrl = url.toLowerCase();
        if (contentType.includes("mpegurl") || contentType.includes("hls") || /(?:[.]m3u8|#m3u8)([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "HLS";
            initHlsPlayer(url);
        } else if (/\.flv([?#].*)?$/.test(lowerUrl)) {
            streamInfo.type = "FLV";
            initFlvPlayer(url);
        } else if (/(?:[.]m3u|#m3u)([?#].*)?$/.test(lowerUrl)) {
            initM3UPlaylist(url);
        } else {
            streamInfo.type = "原生";
            initNativePlayer(url);
        }
        updateInfoPanel();
    }

    function initFlvPlayer(url) {
        if (flvjs.isSupported()) {
            player = flvjs.createPlayer({ type: "flv", url: url });
            player.attachMediaElement(videoPlayer);
            player.load();

            player.on(flvjs.Events.METADATA_ARRIVED, (metadata) => {
                const meta = metadata?.onMetaData || metadata;
                if (meta && meta.width) {
                    streamInfo.resolution = `${meta.width}x${meta.height}`;
                    updateInfoPanel();
                }
            });
            player.on(flvjs.Events.ERROR, () => isM3UPlaylist && tryNextRedundantUrl());

            const onMeta = () => {
                clearTimeout(loadTimeoutTimer);
                showLoading(false);
                updateVideoInfoFromElement();
                play();
                videoPlayer.removeEventListener("loadedmetadata", onMeta);
            };
            videoPlayer.addEventListener("loadedmetadata", onMeta);
        }
    }

    function initHlsPlayer(url) {
        if (Hls.isSupported()) {
            player = new Hls({ fragLoadingMaxRetry: 1 });
            player.loadSource(url);
            player.attachMedia(videoPlayer);

            player.on(Hls.Events.LEVEL_SWITCHED, (event, data) => {
                const level = player.levels[data.level];
                if (level && level.width) {
                    streamInfo.resolution = `${level.width}x${level.height}`;
                    updateInfoPanel();
                }
            });
            player.on(Hls.Events.MANIFEST_PARSED, (e, data) => {
                clearTimeout(loadTimeoutTimer);
                showLoading(false);
                if (data.levels?.[0]) {
                    streamInfo.resolution = `${data.levels[0].width}x${data.levels[0].height}`;
                }
                updateInfoPanel();
                play();
            });
            player.on(Hls.Events.ERROR, (e, data) => { if (data.fatal && isM3UPlaylist) tryNextRedundantUrl(); });
        }
    }

    function initNativePlayer(url) {
        videoPlayer.src = url;
        const onNativeMeta = () => { 
            clearTimeout(loadTimeoutTimer); 
            showLoading(false); 
            updateVideoInfoFromElement();
            play(); 
            videoPlayer.removeEventListener("loadedmetadata", onNativeMeta);
        };
        videoPlayer.addEventListener("loadedmetadata", onNativeMeta);
        videoPlayer.onerror = () => isM3UPlaylist && tryNextRedundantUrl();
    }

    function initM3UPlaylist(url) {
        isM3UPlaylist = true;
        const parser = new M3UParser;
        parser.parseFromUrl(url).then(playlist => {
            currentPlaylist = playlist.map(item => {
                const urls = item.urls?.length ? item.urls : [item.url].filter(u=>u);
                item.urls = urls.map(u => u.startsWith("http") ? u : M3UParser.resolveUrl(baseUrl, u));
                return item;
            }).filter(item => item.urls.length > 0);
            renderPlaylist();
            playPlaylistItem(0);
            togglePlaylist(true);
        });
    }

    function renderPlaylist(searchTerm = "") {
        playlistItems.innerHTML = "";
        const lowerSearch = searchTerm.toLowerCase();
        currentPlaylist.forEach((item, index) => {
            const name = item.title || `项目 ${index + 1}`;
            if (searchTerm && !name.toLowerCase().includes(lowerSearch)) return;
            const div = document.createElement("div");
            div.className = `playlist-item ${index === currentPlaylistIndex ? 'active' : ''}`;
            div.textContent = name;
            div.onclick = () => playPlaylistItem(index);
            playlistItems.appendChild(div);
        });
        clearSearchBtn.classList.toggle("visible", !!searchTerm);
    }

    // --- UI 逻辑与辅助 ---
    function formatTime(s) {
        if (isNaN(s) || s === Infinity) return "00:00";
        const m = Math.floor(s/60);
        const sec = Math.floor(s%60);
        return `${m.toString().padStart(2,"0")}:${sec.toString().padStart(2,"0")}`;
    }

    function updateProgress() {
        const percent = (videoPlayer.currentTime / videoPlayer.duration) * 100 || 0;
        progressBar.style.width = percent + "%";
        timeDisplay.textContent = `${formatTime(videoPlayer.currentTime)} / ${videoPlayer.duration === Infinity ? "Live" : formatTime(videoPlayer.duration)}`;
    }

    function showLoading(s) { loading.style.display = s ? "block" : "none"; }
    function showError(m) { showLoading(false); errorMessage.textContent = m; errorMessage.style.display = "block"; }
    function play() { videoPlayer.play().then(() => { isPlaying = true; playPauseBtn.textContent = "❚❚"; }).catch(()=>{}); }
    function togglePlaylist(s) { playlistContainer.classList.toggle("hidden", s !== undefined ? !s : undefined); }
    function updateVolumeIcon() { volumeBtn.textContent = videoPlayer.muted || videoPlayer.volume === 0 ? "🔇" : (videoPlayer.volume < .5 ? "🔉" : "🔊"); }

    // 事件绑定
    playlistContainer.onmouseleave = () => { if (document.activeElement !== playlistSearchInput) hidePlaylistTimeout = setTimeout(() => togglePlaylist(false), 300); };
    playlistContainer.onmouseenter = () => clearTimeout(hidePlaylistTimeout);
    infoBtn.onclick = (e) => { e.stopPropagation(); updateInfoPanel(); infoPanel.style.display = infoPanel.style.display === "none" ? "block" : "none"; };
    playPauseBtn.onclick = () => videoPlayer.paused ? play() : (videoPlayer.pause(), isPlaying = false, playPauseBtn.textContent = "▶");
    volumeBtn.onclick = () => { videoPlayer.muted = !videoPlayer.muted; updateVolumeIcon(); };
    fullscreenBtn.onclick = () => document.fullscreenElement ? document.exitFullscreen() : videoContainer.requestFullscreen();
    backBtn.onclick = () => window.close();
    playlistBtn.onclick = () => togglePlaylist();
    closePlaylistBtn.onclick = () => togglePlaylist(false);
    playlistSearchInput.oninput = (e) => renderPlaylist(e.target.value);
    clearSearchBtn.onclick = () => { playlistSearchInput.value = ""; renderPlaylist(""); };
    videoPlayer.ontimeupdate = updateProgress;

    videoPlayer.addEventListener("resize", updateVideoInfoFromElement);

    videoPlayer.addEventListener("waiting", () => {
        if (isM3UPlaylist && isPlaying) {
            clearTimeout(stallTimeoutTimer);
            stallTimeoutTimer = setTimeout(() => {
                if (!currentPlaylist[currentPlaylistIndex]?.isTotallyFailed) tryNextRedundantUrl();
            }, STALL_TIMEOUT_MS);
        }
    });
    videoPlayer.addEventListener("playing", () => clearTimeout(stallTimeoutTimer));

    document.onmousemove = () => {
        controls.classList.remove("hidden");
        clearTimeout(controlsTimeout);
        if (isPlaying) controlsTimeout = setTimeout(() => controls.classList.add("hidden"), 3000);
    };

    chrome.storage.local.get(["volume"], (r) => {
        if (r.volume !== undefined) {
            videoPlayer.volume = r.volume;
            volumeProgress.style.width = r.volume * 100 + "%";
            updateVolumeIcon();
        }
    });

    initPlayer();
});