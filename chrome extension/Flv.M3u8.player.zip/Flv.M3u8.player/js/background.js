const setupNetworkRules = () => {
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [ 1, 2 ],
        addRules: [ {
            id: 1,
            priority: 1,
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
                redirect: {
                    regexSubstitution: `${chrome.runtime.getURL("player.html")}#\\0`
                }
            },
            condition: {
                regexFilter: "^.*\\.flv(?:\\?|$)",
                resourceTypes: [ chrome.declarativeNetRequest.ResourceType.MAIN_FRAME ]
            }
        }, {
            id: 2,
            priority: 2,
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
                redirect: {
                    regexSubstitution: `${chrome.runtime.getURL("player.html")}#\\0`
                }
            },
            condition: {
                regexFilter: "^.*(?:\\.m3u8(?:\\?|$)|#m3u8$)",
                resourceTypes: [ chrome.declarativeNetRequest.ResourceType.MAIN_FRAME ]
            }
        } ]
    });
};

chrome.runtime.onInstalled.addListener(() => {
    console.log("Video Stream Player extension installed");
    setupNetworkRules();
});

chrome.runtime.onStartup.addListener(() => {
    console.log("Video Stream Player extension started");
    setupNetworkRules();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "checkRedirect") {
        console.log("检测URL重定向:", request.url);
        const controller = new AbortController;
        const signal = controller.signal;
        fetch(request.url, {
            method: "get",
            redirect: "follow",
            headers: {
                Range: "bytes=0-1"
            },
            signal: signal
        }).then(response => {
            console.log("重定向后的URL:", response.url);
            const contentType = response.headers.get("Content-Type");
            console.log("Content-Type:", contentType);
            console.warn("已获取重定向URL和Content-Type，中止请求。");
            controller.abort();
            sendResponse({
                success: true,
                finalUrl: response.url,
                contentType: contentType
            });
        }).catch(error => {
            if (error.name === "AbortError") {
                console.log("Fetch 请求已中止。");
            } else {
                console.error("重定向检测失败:", error);
            }
            sendResponse({
                success: false,
                error: error.message
            });
        });
        return true;
    }
});